/****************************************************************************
 * [S]imulated [M]edieval [A]dventure multi[U]ser [G]ame      |   \\._.//   *
 * -----------------------------------------------------------|   (0...0)   *
 * SMAUG 1.4 (C) 1994, 1995, 1996, 1998  by Derek Snider      |    ).:.(    *
 * -----------------------------------------------------------|    {o o}    *
 * SMAUG code team: Thoric, Altrag, Blodkai, Narn, Haus,      |   / ' ' \   *
 * Scryn, Rennard, Swordbearer, Gorog, Grishnakh, Nivek,      |~'~.VxvxV.~'~*
 * Tricops and Fireblade                                      |             *
 * ------------------------------------------------------------------------ *
 * Merc 2.1 Diku Mud improvments copyright (C) 1992, 1993 by Michael        *
 * Chastain, Michael Quan, and Mitchell Tse.                                *
 * Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,          *
 * Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.     *
 * ------------------------------------------------------------------------ *
 *			     Informational module			    *
 ****************************************************************************/


#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include "mud.h"

/* Had to add unknowns because someone added new positions and didn't
 * update them.  Just a band-aid till I have time to fix it right.
 * This was found thanks to mud@mini.axcomp.com pointing it out :)
 * --Shaddai
 */

char *	const	where_name	[] =
{
    "&x&w<Como luz>&w         ",
    "&x&w<Dedo izquierdo>&w   ",
    "&x&w<Dedo derecho>&w     ",
    "&x&w<En el cuello>&w     ",
    "&x&w<En el cuello>&w     ",
    "&x&w<En el torso>&w      ",
    "&x&w<En la cabeza>&w     ",
    "&x&w<En las piernas>&w   ",
    "&x&w<En los pies>&w      ",
    "&x&w<En las manos>&w     ",
    "&x&w<En los brazos>&w    ",
    "&x&w<Como escudo>&w      ",
    "&x&w<Por encima>&w       ",
    "&x&w<En la cintura>&w    ",
    "&x&w<Munyeca izquier>&w  ",
    "&x&w<Munyeca derecha>&w  ",
    "&x&w<Blandiendo>&w       ",
    "&x&w<Cogido>&w           ",
    "&x&w<Blandiendo sec>&w   ",
    "&x&w<En las orejas>&w    ",
    "&x&w<En los ojos>&w      ",
    "&x&w<Como proyectil>&w   ",
    "&x&w<En la Espalda>&w    ",
    "&x&w<Sobre la cara>&w    ",
    "&x&w<Tobillo izquier>&w  ",
    "&x&w<Tobillo derecho>&w  ",
    "&x&w<Flotando al lado>&w ",
    "&x&w<Ni puta idea>&w     ",
    "&x&w<Ni puta idea>&w     "
};


/*
 * Local functions.
 */
void	show_char_to_char_0	args( ( CHAR_DATA *victim, CHAR_DATA *ch ) );
void	show_char_to_char_1	args( ( CHAR_DATA *victim, CHAR_DATA *ch ) );
void	show_char_to_char_2	args( ( CHAR_DATA *victim, CHAR_DATA *ch ) );
void	show_char_to_char	args( ( CHAR_DATA *list, CHAR_DATA *ch ) );
bool	check_blind		args( ( CHAR_DATA *ch ) );
void    show_condition          args( ( CHAR_DATA *ch, CHAR_DATA *victim ) );
void    do_camuflaje            args( ( CHAR_DATA *ch, char *argumento ) );


char *format_obj_to_char( OBJ_DATA *obj, CHAR_DATA *ch, bool fShort )
{
    static char buf[MAX_STRING_LENGTH];
    bool glowsee = FALSE;

    /* can see glowing invis items in the dark */
    if ( IS_OBJ_STAT(obj, ITEM_GLOW) && IS_OBJ_STAT(obj, ITEM_INVIS)
    &&  IS_AFFECTED(ch, AFF_TRUESIGHT) && IS_AFFECTED(ch, AFF_DETECT_INVIS) )
	glowsee = TRUE;

    buf[0] = '\0';
    if ( !IS_NPC(ch) && ch->pcdata->questobj > 0 && obj->pIndexData->vnum == ch->pcdata->questobj)
     strcat( buf, "&g[&cOBJETIVO&g]&w"     );

    if ( IS_OBJ_STAT(obj, ITEM_INVIS)     )   strcat( buf, "&p(&x&wInvis&p)&x&w "     );
    if ( IS_OBJ_STAT(obj, ITEM_CASUAL)       )   strcat( buf, "&w(&cCasual&w)&w "   );
    if (  (IS_AFFECTED(ch, AFF_DETECT_EVIL) || ch->class==CLASS_PALADIN)
	 && IS_OBJ_STAT(obj, ITEM_EVIL)   )   strcat( buf, "&p(&x&rAura Roja&p)&&xw "  );

    if ( ch->class==CLASS_PALADIN
	 && ( IS_OBJ_STAT(obj, ITEM_ANTI_EVIL) && !IS_OBJ_STAT(obj, ITEM_ANTI_NEUTRAL) && !IS_OBJ_STAT(obj, ITEM_ANTI_GOOD))   )
          strcat( buf, "(Brillo Rojo) "  );
    if ( ch->class==CLASS_PALADIN
	 && ( !IS_OBJ_STAT(obj, ITEM_ANTI_EVIL) && IS_OBJ_STAT(obj, ITEM_ANTI_NEUTRAL) && !IS_OBJ_STAT(obj, ITEM_ANTI_GOOD))   )
          strcat( buf, "(Brillo Gris) "  );
    if ( ch->class==CLASS_PALADIN
	 && (!IS_OBJ_STAT(obj, ITEM_ANTI_EVIL) && !IS_OBJ_STAT(obj, ITEM_ANTI_NEUTRAL) && IS_OBJ_STAT(obj, ITEM_ANTI_GOOD))   )
          strcat( buf, "(Brillo Blanco) "  );


    if ( ch->class==CLASS_PALADIN
	 && ( IS_OBJ_STAT(obj, ITEM_ANTI_EVIL) && IS_OBJ_STAT(obj, ITEM_ANTI_NEUTRAL) && !IS_OBJ_STAT(obj, ITEM_ANTI_GOOD))   )
          strcat( buf, "(Brillo Rojo-Gris) "  );
    if ( ch->class==CLASS_PALADIN
	 && ( IS_OBJ_STAT(obj, ITEM_ANTI_EVIL) && !IS_OBJ_STAT(obj, ITEM_ANTI_NEUTRAL) && IS_OBJ_STAT(obj, ITEM_ANTI_GOOD))   )
          strcat( buf, "(Brillo Rojo-Blanco) "  );
    if ( ch->class==CLASS_PALADIN
	 && ( !IS_OBJ_STAT(obj, ITEM_ANTI_EVIL) && IS_OBJ_STAT(obj, ITEM_ANTI_NEUTRAL) && IS_OBJ_STAT(obj, ITEM_ANTI_GOOD))   )
          strcat( buf, "(Brillo Gris-Blanco) "  );

    if ( IS_AFFECTED(ch, AFF_DETECT_MAGIC)
	 && IS_OBJ_STAT(obj, ITEM_MAGIC)  )   strcat( buf, "(Magico) "   );
    if ( !glowsee && IS_OBJ_STAT(obj, ITEM_GLOW) )   strcat( buf, "(Brillante) "   );
    if ( IS_OBJ_STAT(obj, ITEM_HUM)       )   strcat( buf, "(Humeante) "   );
    if ( IS_OBJ_STAT(obj, ITEM_HIDDEN)	  )   strcat( buf, "(Oculto) "	  );
    if ( IS_OBJ_STAT(obj, ITEM_BURIED)	  )   strcat( buf, "(Enterrado) "	  );
    if ( IS_IMMORTAL(ch)
	 && IS_OBJ_STAT(obj, ITEM_PROTOTYPE) ) strcat( buf, "(PROTO) "	  );
    if ( IS_AFFECTED(ch, AFF_DETECTTRAPS)
	 && is_trapped(obj)   )   strcat( buf, "(Trampa) "  );

    if ( fShort )
    {
	if ( glowsee && !IS_IMMORTAL(ch) )
	    strcat( buf, "el brillo de algo" );
	else
	if ( obj->short_descr )
	    strcat( buf, obj->short_descr );
    }
    else
    {
	if ( glowsee )
	    strcat( buf, "Puedes ver el aura brillante de algo." );
	if ( obj->description )
	    strcat( buf, obj->description );
    }

    return buf;
}


/*
 * Some increasingly freaky hallucinated objects		-Thoric
 * (Hats off to Albert Hoffman's "problem child")
 */
char *hallucinated_object( int ms, bool fShort )
{
    int sms = URANGE( 1, (ms+10)/5, 20 );

    if ( fShort )
    switch( number_range( 6-URANGE(1,sms/2,5), sms ) )
    {
	case  1: return "una espada";
	case  2: return "una daga";
	case  3: return "algo brillante";
	case  4: return "algo";
	case  5: return "algo interesante";
	case  6: return "algo colorido";
	case  7: return "algo muy bonito";
	case  8: return "una cosa importante";
	case  9: return "una capa de muchos colores";
	case 10: return "una mistica espada llameante";
	case 11: return "un enjambre de insectos";
	case 12: return "un hipopotamo rosa";
	case 13: return "una ovejita beeeeeeee";
	case 14: return "tu tumba";
	case 15: return "Los condones que usa tu viejo!";
	case 16: return "un tomo de magia";
	case 17: return "un secreto muy bien guardado";
	case 18: return "el significado de todo";
	case 19: return "la respuesta";
	case 20: return "la llave de la vida, del universo y de todo";
    }
    switch( number_range( 6-URANGE(1,sms/2,5), sms ) )
    {
	case  1: return "Una bonita espada cautiva tu mirada.";
	case  2: return "Una daga esta en el suelo.";
	case  3: return "Algo que brilla atrae tu mirada.";
	case  4: return "Algo atrae tu atencion.";
	case  5: return "Algo interesante atrae tu mirada.";
	case  6: return "Algo colorido esta aqui.";
	case  7: return "Algo muy bonito parece llamarte.";
	case  8: return "Una cosa muy importante esta aqui.";
	case  9: return "Una capa de muchos colores parece llamarte.";
	case 10: return "Una mistica espada llameante te aguarda en el suelo.";
	case 11: return "Un enjambre de insectos delante de tu cara!";
	case 12: return "Hay un hipopotamo rosa a tus pies.";
	case 13: return "Si faltasen mujeres... ovejaaaas!";
	case 14: return "Miras la tumba... si, pone tu nombre.";
	case 15: return "Las botas de Thoric estan aqui olvidadas.";
	case 16: return "Que secretos escondera este tomo de magia?";
	case 17: return "Un secreto muy bien guardado... seguira bien guardado :P.";
	case 18: return "El significado de todo... asi de simple, asi de claro.";
	case 19: return "La respuesta. Una. Siempre ha sido solo una.";
	case 20: return "La llave de la vida, del unievrso y de todo aguarda aqui mismo.";
    }
    return "Whoa!!!";
}


/* This is the punct snippet from Desden el Chaman Tibetano - Nov 1998
   Email: jlalbatros@mx2.redestb.es
*/
char *num_punct(int foo)
{
    int index, index_new, rest;
    char buf[16];
    static char buf_new[16];

    sprintf(buf,"%d",foo);
    rest = strlen(buf)%3;

    for (index=index_new=0;index<strlen(buf);index++,index_new++)
    {
	if (index!=0 && (index-rest)%3==0 )
	{
	    buf_new[index_new]=',';
	    index_new++;
	    buf_new[index_new]=buf[index];
        }
        else
	    buf_new[index_new] = buf[index];
    }
    buf_new[index_new]='\0';
    return strdup(buf_new);
}


/*
 * Show a list to a character.
 * Can coalesce duplicated items.
 */
void show_list_to_char( OBJ_DATA *list, CHAR_DATA *ch, bool fShort, bool fShowNothing )
{
    char **prgpstrShow;
    int *prgnShow;
    int *pitShow;
    char *pstrShow;
    OBJ_DATA *obj;
    int nShow;
    int iShow;
    int count, offcount, tmp, ms, cnt;
    bool fCombine;

    if ( !ch->desc )
	return;

    /*
     * if there's no list... then don't do all this crap!  -Thoric
     */
    if ( !list )
    {
    	if ( fShowNothing )
    	{
	   if ( IS_NPC(ch) || xIS_SET(ch->act, PLR_COMBINE) )
	      send_to_char( "     ", ch );
	   set_char_color( AT_OBJECT, ch );
	   send_to_char( "Nada.\n\r", ch );
	}
	return;
    }
    /*
     * Alloc space for output lines.
     */
    count = 0;
    for ( obj = list; obj; obj = obj->next_content )
	count++;

    ms  = (ch->mental_state ? ch->mental_state : 1)
	* (IS_NPC(ch) ? 1 : (ch->pcdata->condition[COND_DRUNK] ? (ch->pcdata->condition[COND_DRUNK]/12) : 1));

    /*
     * If not mentally stable...
     */
    if ( abs(ms) > 40 )
    {
	offcount = URANGE( -(count), (count * ms) / 100, count*2 );
	if ( offcount < 0 )
	  offcount += number_range(0, abs(offcount));
	else
	if ( offcount > 0 )
	  offcount -= number_range(0, offcount);
    }
    else
	offcount = 0;

    if ( count + offcount <= 0 )
    {
    	if ( fShowNothing )
    	{
	   if ( IS_NPC(ch) || xIS_SET(ch->act, PLR_COMBINE) )
	      send_to_char( "     ", ch );
	   set_char_color( AT_OBJECT, ch );
	   send_to_char( "Nada.\n\r", ch );
	}
	return;
    }

    CREATE( prgpstrShow,	char*,	count + ((offcount > 0) ? offcount : 0) );
    CREATE( prgnShow,		int,	count + ((offcount > 0) ? offcount : 0) );
    CREATE( pitShow,		int,	count + ((offcount > 0) ? offcount : 0) );
    nShow	= 0;
    tmp		= (offcount > 0) ? offcount : 0;
    cnt		= 0;

    /*
     * Format the list of objects.
     */
    for ( obj = list; obj; obj = obj->next_content )
    {
	if ( offcount < 0 && ++cnt > (count + offcount) )
	    break;
	if ( tmp > 0 && number_bits(1) == 0 )
	{
	    prgpstrShow [nShow] = str_dup( hallucinated_object(ms, fShort) );
	    prgnShow	[nShow] = 1;
	    pitShow	[nShow] = number_range( ITEM_LIGHT, ITEM_BOOK );
	    nShow++;
	    --tmp;
	}
	if ( obj->wear_loc == WEAR_NONE
	&& can_see_obj( ch, obj )
	&& (obj->item_type != ITEM_TRAP || IS_AFFECTED(ch, AFF_DETECTTRAPS) ) )
	{
	    pstrShow = format_obj_to_char( obj, ch, fShort );
	    fCombine = FALSE;

	    if ( IS_NPC(ch) || xIS_SET(ch->act, PLR_COMBINE) )
	    {
		/*
		 * Look for duplicates, case sensitive.
		 * Matches tend to be near end so run loop backwords.
		 */
		for ( iShow = nShow - 1; iShow >= 0; iShow-- )
		{
		    if ( !strcmp( prgpstrShow[iShow], pstrShow ) )
		    {
			prgnShow[iShow] += obj->count;
			fCombine = TRUE;
			break;
		    }
		}
	    }

	    pitShow[nShow] = obj->item_type;
	    /*
	     * Couldn't combine, or didn't want to.
	     */
	    if ( !fCombine )
	    {
		prgpstrShow [nShow] = str_dup( pstrShow );
		prgnShow    [nShow] = obj->count;
		nShow++;
	    }
	}
    }
    if ( tmp > 0 )
    {
	int x;
	for ( x = 0; x < tmp; x++ )
	{
	    prgpstrShow [nShow] = str_dup( hallucinated_object(ms, fShort) );
	    prgnShow	[nShow] = 1;
	    pitShow	[nShow] = number_range( ITEM_LIGHT, ITEM_BOOK );
	    nShow++;
	}
    }

    /*
     * Output the formatted list.		-Color support by Thoric
     */
    for ( iShow = 0; iShow < nShow; iShow++ )
    {
	switch(pitShow[iShow]) {
	default:
	  set_char_color( AT_OBJECT, ch );
	  break;
	case ITEM_BLOOD:
	  set_char_color( AT_BLOOD, ch );
	  break;
	case ITEM_MONEY:
	case ITEM_TREASURE:
	  set_char_color( AT_YELLOW, ch );
	  break;
	case ITEM_COOK:
	case ITEM_FOOD:
	  set_char_color( AT_HUNGRY, ch );
	  break;
	case ITEM_DRINK_CON:
	case ITEM_FOUNTAIN:
	  set_char_color( AT_THIRSTY, ch );
	  break;
	case ITEM_FIRE:
	  set_char_color( AT_FIRE, ch );
	  break;
	case ITEM_SCROLL:
	case ITEM_WAND:
	case ITEM_STAFF:
	  set_char_color( AT_MAGIC, ch );
	  break;
	}
	if ( fShowNothing )
	    send_to_char( "     ", ch );
	send_to_char( prgpstrShow[iShow], ch );
/*	if ( IS_NPC(ch) || xIS_SET(ch->act, PLR_COMBINE) ) */
	{
	    if ( prgnShow[iShow] != 1 )
		ch_printf( ch, " (%d)", prgnShow[iShow] );
	}

	send_to_char( "\n\r", ch );
	DISPOSE( prgpstrShow[iShow] );
    }

    if ( fShowNothing && nShow == 0 )
    {
	if ( IS_NPC(ch) || xIS_SET(ch->act, PLR_COMBINE) )
	    send_to_char( "     ", ch );
	set_char_color( AT_OBJECT, ch );
	send_to_char( "Nada.\n\r", ch );
    }

    /*
     * Clean up.
     */
    DISPOSE( prgpstrShow );
    DISPOSE( prgnShow	 );
    DISPOSE( pitShow	 );
    return;
}


/*
 * Show fancy descriptions for certain spell affects		-Thoric
 */
void show_visible_affects_to_char( CHAR_DATA *victim, CHAR_DATA *ch )
{
    char buf[MAX_STRING_LENGTH];
    char name[MAX_STRING_LENGTH];

    if ( IS_NPC( victim ) )

      strcpy( name, victim->short_descr );

    if ( !IS_NPC( victim ) )

      strcpy( name, victim->name);
    name[0] = toupper(name[0]);

    if ( IS_AFFECTED(victim, AFF_SANCTUARY) )
    {
   /*set_char_color( AT_WHITE, ch );*/
        if ( IS_GOOD(victim) )
            ch_printf( ch, "&B(&wSantuario&B)&w", name );
        else if ( IS_EVIL(victim) )
            ch_printf( ch, "&R(&wSantuario&R)&w", name );
        else
            ch_printf( ch, "&z(&WSantuario&z)&w", name );
    }
    if ( IS_AFFECTED(victim, AFF_FIRESHIELD) )
    {
        /*set_char_color( AT_FIRE, ch );*/
        ch_printf( ch, "&W(&rllameante&W)&w", name );
    }
    if ( IS_AFFECTED(victim, AFF_SHOCKSHIELD) )
    {
        /*set_char_color( AT_BLUE, ch );*/
   ch_printf( ch, "&W(&OEnergia&W)&w", name );
    }
    if ( IS_AFFECTED(victim, AFF_ACIDMIST) )
    {
   /*set_char_color( AT_GREEN, ch );         */
   ch_printf( ch, "&W(&gAcidoso&w)&w", name );
    }
/*Scryn 8/13*/
    if ( IS_AFFECTED(victim, AFF_ICESHIELD) )
    {
     /*   set_char_color( AT_LBLUE, ch );*/
        ch_printf( ch, "&W(&cHelado&W)&w", name );
    }
    if ( IS_AFFECTED(victim, AFF_CHARM)       )
    {
   /*set_char_color( AT_MAGIC, ch );    */
   ch_printf( ch, "&w(&zAtontado&w)&w", name );
    }
    if(xIS_SET(victim->act, PLR_DOMINADO))
    {
    ch_printf( ch, "&w(&zDominado&w)&w", name );
    }
    if(xIS_SET(victim->afectado_por, DAF_CELERIDAD)
    || xIS_SET(victim->act, PLR_TEMPORIS))
    ch_printf( ch, "&w(&gVeloz&w)&w", name );
    if(xIS_SET(victim->afectado_por, DAF_POTENCIA))
    ch_printf( ch, "&w(&cPotente&w)&w", name );

    if ( !IS_NPC(victim) && !victim->desc
    &&    victim->switched && IS_AFFECTED(victim->switched, AFF_POSSESS) )
    {
   /*set_char_color( AT_MAGIC, ch );*/
   strcpy( buf, PERS( victim, ch ) );
   strcat( buf, " &w(&pEn trance&w)&w" );
    }
}

void show_char_to_char_0( CHAR_DATA *victim, CHAR_DATA *ch )
{
    char buf[MAX_STRING_LENGTH];
    char buf1[MAX_STRING_LENGTH];

    buf[0] = '\0';

    set_char_color( AT_PERSON, ch );

    if ( !IS_NPC(victim) && !victim->desc )
    {
	if ( !victim->switched )         send_to_char_color( "&z[&w(&gSin Link&w)&z]&w", ch );
	else if ( !IS_AFFECTED(victim, AFF_POSSESS) )
						strcat( buf, "(Switcheado)" );
    }
    if ( IS_NPC(victim) && IS_AFFECTED(victim, AFF_POSSESS) && IS_IMMORTAL(ch)
	 && victim->desc )
    {
			sprintf( buf1, "(%s)",victim->desc->original->name );
			strcat( buf, buf1 );

    }
    if (IS_NPC(victim) && !IS_NPC(ch) && ch->pcdata->questmob > 0 && victim->pIndexData->vnum == ch->pcdata->questmob)
        strcat( buf, "&g[&YOBJETIVO&g]&w");

    if ( !IS_NPC(victim)
    &&   xIS_SET(victim->act, PLR_AFK) )	strcat( buf, "[EMPANAO]");

    if ( (!IS_NPC(victim) && xIS_SET(victim->act, PLR_WIZINVIS))
      || (IS_NPC(victim) && xIS_SET(victim->act, ACT_MOBINVIS)) )
    {
        if (!IS_NPC(victim))
	sprintf( buf1,"(Invis %d)", victim->pcdata->wizinvis );
        else sprintf( buf1,"(Mobinvis %d)", victim->mobinvis);
	strcat( buf, buf1 );
    }

/*
    if ( !IS_NPC( victim) )
    {
	if ( IS_IMMORTAL( victim ) && victim->level > 83 )
	  send_to_char_color( "&B(&WImmortal&B)&w", ch );
	if ( victim->pcdata->clan
        &&   IS_SET( victim->pcdata->flags, PCFLAG_DEADLY )
	&&   victim->pcdata->clan->badge
	&& ( victim->pcdata->clan->clan_type != CLAN_ORDER
	&&   victim->pcdata->clan->clan_type != CLAN_GUILD ) )
                                        ch_printf_color( ch, "%s ", victim->pcdata->clan->badge );
	else if ( CAN_PKILL( victim ) && victim->level < 81 )
                           send_to_char_color( "&P(&wSolitario&P)", ch );
                   else if ( CAN_PKILL( victim ) && victim->level < 15 )
                           send_to_char_color( "&P(&oPrincipiante&P)", ch );
    }
*/
    set_char_color( AT_PERSON, ch );

    if ( IS_AFFECTED(victim, AFF_INVISIBLE)   ) strcat( buf, "&W(&wInvis&W)&w"      );
    if ( IS_AFFECTED(victim, AFF_HIDE)        ) strcat( buf, "&W(&rOculto&W)&w"       );
    if ( IS_AFFECTED(victim, AFF_PASS_DOOR)   ) strcat( buf, "&W(&wTransluciente&W)&w");
    if (xIS_SET(victim->afectado_por, DAF_INCORPOREO)) 
	 strcat( buf, "&W(&cIncorporeo&W)&w" );
    if ( IS_AFFECTED(victim, AFF_FAERIE_FIRE) ) strcat( buf, "&W(&pAura rosa&W)&w"  );
      if ( IS_GOOD(victim) )
    if ( IS_EVIL(victim)
    &&   (  IS_AFFECTED(ch, AFF_DETECT_EVIL) || ch->class==CLASS_PALADIN)     ) strcat( buf, "&R(&rAura roja&R)&w"   );
    if ( IS_NEUTRAL(victim)
    &&   ch->class==CLASS_PALADIN  ) strcat( buf, "&W(&zAura gris&W)&w"   );
    if ( IS_GOOD(victim)
    &&   ch->class==CLASS_PALADIN  ) strcat( buf, "&W(&wAura Blanca&w)&w"   );


    if ( IS_AFFECTED(victim, AFF_BERSERK)     ) strcat( buf, "&W(&RRabioso&W)&w"  );
    if ( !IS_NPC(victim) && xIS_SET(victim->act, PLR_ATTACKER ) )
						strcat( buf, "&W(&RATACANTE&W)&w"   );
    if ( !IS_NPC(victim) && xIS_SET(victim->act, PLR_KILLER ) )
						strcat( buf, "&W(&rASESINO&W)&w"     );
    if ( !IS_NPC(victim) && xIS_SET(victim->act, PLR_THIEF  ) )
						strcat( buf, "&W(&cLADRON&W)&w"      );
    if ( !IS_NPC(victim) && xIS_SET(victim->act, PLR_LITTERBUG  ) )
						strcat( buf, "&W(&pLITTERBUG&W)&w"  );
    if ( IS_NPC(victim) && IS_IMMORTAL(ch)
	 && xIS_SET(victim->act, ACT_PROTOTYPE) )strcat( buf, "&W(&YPROTO&W)&w"      );
    if ( IS_NPC(victim) && ch->mount && ch->mount == victim
         && ch->in_room == ch->mount->in_room ) strcat( buf, "&W(&wMontado&W)&w"      );
    if ( victim->desc && victim->desc->connected == CON_EDITING )
      strcat( buf, "&W(&gEscribiendo&W)&w"    );

    if ( victim->morph != NULL )
      strcat (buf, "&W(&wTransformado&W)&w");
    if( xIS_SET(ch->act, PLR_DOMINADO))
      strcat (buf, "&w(&rDominado&w)" );

    set_char_color( AT_PERSON, ch );
  if ((victim->position == victim->defposition && victim->long_descr[0] != '\0')
      || ( victim->morph && victim->morph->morph &&
           victim->morph->morph->defpos == victim->position ) )
    {
      if ( victim->morph != NULL )
      {
        if ( !IS_IMMORTAL(ch) )
        {
          if ( victim->morph->morph != NULL)
                strcat ( buf, victim->morph->morph->long_desc );
          else
                strcat ( buf, victim->long_descr );
        }
        else
	{
           /*strcat (buf, PERS(victim, ch) );*/
    	   if ( !IS_NPC(victim) && !xIS_SET(ch->act, PLR_BRIEF) )
		strcat( buf, victim->long_descr );
	   strcat( buf, ".\n\r" );
	}
      }
      else
           strcat (buf, victim->long_descr);


   show_visible_affects_to_char( victim, ch );
   send_to_char( buf, ch );

	return;
    }
    else {
    if ( victim->morph != NULL && victim->morph->morph != NULL &&
	 !IS_IMMORTAL( ch ) )
	strcat( buf, MORPHPERS( victim, ch ) );
    else
    	strcat( buf, PERS( victim, ch ) );
    }
    if ( !IS_NPC(victim) && !xIS_SET(ch->act, PLR_BRIEF) )
	strcat( buf, victim->long_descr );

    switch ( victim->position )
    {
    /*
     * Posicion en la que el jugador puede ser decapitado o
     * diablerizado por otros u otros jugadores.
     * SiGo email to sigo@vampiromud.com
     * Colikotron Code Team 199x -200x
     */
     case POS_PREDECAP:
     if( IS_VAMPIRE(victim)
     && IS_VAMPIRE(ch))
     	strcat( buf, " esta indefenso en el suelo esperando ser diablerizado..." );
     if( IS_VAMPIRE(victim)
     && !IS_VAMPIRE(ch)
     || !IS_VAMPIRE(victim)
     && IS_VAMPIRE(ch)
     || !IS_VAMPIRE(victim)
     && !IS_VAMPIRE(ch))
     	strcat( buf, " esta indefenso en el suelo esperando ser decapitado..." );
	break;

    case POS_DEAD:     strcat( buf, " esta MUERTO!!" );			break;
    case POS_MORTAL:   strcat( buf, " esta mortalmente herido." );		break;
    case POS_INCAP:    strcat( buf, " esta incapacitado." );		break;
    case POS_STUNNED:  strcat( buf, " esta aturdido en el suelo." );	break;
    case POS_SLEEPING:
        if (ch->position == POS_SITTING
        ||  ch->position == POS_RESTING )
            strcat( buf, " esta durmiendo aqui." );
	else
            strcat( buf, " esta durmiendo aqui." );
        break;
    case POS_RESTING:
        if (ch->position == POS_RESTING)
            strcat ( buf, " esta descansando aqui a tus pies." );
        else
	if (ch->position == POS_MOUNTED)
	    strcat ( buf, " esta descansado a los pies de tu montura." );
	else
            strcat (buf, " esta descansando aqui." );
        break;
    case POS_SITTING:
        if (ch->position == POS_SITTING)
            strcat( buf, " se sienta aqui contigo." );
        else
        if (ch->position == POS_RESTING)
            strcat( buf, " se sienta cerca de donde estas descansando." );
        else
            strcat( buf, " se sienta por aqui." );
        break;
    case POS_STANDING:
	if ( IS_IMMORTAL(victim) )
            strcat( buf, " se alza majestuosamente ante ti." );
	else
        if ( ( victim->in_room->sector_type == SECT_UNDERWATER )
        && !IS_AFFECTED(victim, AFF_AQUA_BREATH) && !IS_NPC(victim) )
            strcat( buf, " esta flotando por aqui." );
	else
	if ( victim->in_room->sector_type == SECT_UNDERWATER )
            strcat( buf, " esta aqui en el agua." );
	else
	if ( ( victim->in_room->sector_type == SECT_OCEANFLOOR )
	&& !IS_AFFECTED(victim, AFF_AQUA_BREATH) && !IS_NPC(victim) )
       strcat( buf, " esta flotando por aqui." );
	else
	if ( victim->in_room->sector_type == SECT_OCEANFLOOR )
       strcat( buf, " esta aqui en el agua." );
	else
	if ( IS_AFFECTED(victim, AFF_FLOATING)
        || IS_AFFECTED(victim, AFF_FLYING) )
          strcat( buf, " esta flotando por aqui.&g" );
        else
          strcat( buf, " esta aqui.&g" );
        break;
    case POS_SHOVE:    strcat( buf, " esta siendo colocado por aqui.&g" );   break;
    case POS_DRAG:     strcat( buf, " esta siendo empujado.&g" );   break;
    case POS_MOUNTED:
   strcat( buf, " esta aqui, sobre&O " );
	if ( !victim->mount )
       strcat( buf, "el aire???&g" );
	else
	if ( victim->mount == ch )
       strcat( buf, "tu espalda.&g" );
	else
	if ( victim->in_room == victim->mount->in_room )
	{
	    strcat( buf, PERS( victim->mount, ch ) );
	    strcat( buf, "." );
	}
	else
       strcat( buf, "alguien que se ha ido??&g" );
	break;
    case POS_FIGHTING:
    case POS_EVASIVE:
    case POS_DEFENSIVE:
    case POS_AGGRESSIVE:
    case POS_BERSERK:
	strcat( buf, " esta aqui, luchando con" );
	if ( !victim->fighting )
        {
	    strcat( buf, " el aire???" );

            /* some bug somewhere.... kinda hackey fix -h */
            if(! victim->mount)
               victim->position = POS_STANDING;
            else
               victim->position = POS_MOUNTED;
        }
	else if ( who_fighting( victim ) == ch )
	    strcat( buf, "tigo!" );
	else if ( victim->in_room == victim->fighting->who->in_room )
	{
	    strcat( buf, PERS( victim->fighting->who, ch ) );
	    strcat( buf, "." );
	}
	else
	    strcat( buf, " alguien que se ha ido??" );
	break;
    }

    strcat( buf, "\n\r" );
    buf[0] = UPPER(buf[0]);
    show_visible_affects_to_char( victim, ch );
    send_to_char( buf, ch );


    return;
}



void show_char_to_char_1( CHAR_DATA *victim, CHAR_DATA *ch )
{
    OBJ_DATA *obj;
    int iWear;
    bool found;

    if ( can_see( victim, ch ) && !IS_NPC( ch ) && !xIS_SET( ch->act, PLR_WIZINVIS ) )
    {
      act( AT_ACTION, "$n te mira... es eso una provocacion?.", ch, NULL, victim, TO_VICT    );
      if ( victim != ch )
	act( AT_ACTION, "$n mira a $N... lo estara provocando?.",  ch,
NULL, victim, TO_NOTVICT );
      else
        act( AT_ACTION, "$n se mira. Aparte de pijo vanidoso anda Adonis.", ch, NULL, victim, TO_NOTVICT );
    }

    if ( victim->description[0] != '\0' )
    {
      if ( victim->morph != NULL && victim->morph->morph != NULL)
        send_to_char ( victim->morph->morph->description , ch );
      else
        send_to_char (victim->description, ch);
    }
    else
    {
        if ( victim->morph != NULL && victim->morph->morph != NULL)
           send_to_char ( victim->morph->morph->description , ch );
	else if ( IS_NPC( victim ) )
	  act( AT_PLAIN, "No ves nada especial en $M.", ch, NULL, victim, TO_CHAR );
	else if ( ch != victim )
	  act( AT_PLAIN, "$El no tiene mucho que mirar...", ch, NULL, victim, TO_CHAR );
	else
	  act( AT_PLAIN, "No tienes mucho que mirar...", ch, NULL, NULL, TO_CHAR );
    }

    show_race_line( ch, victim );
    show_condition( ch, victim );

    found = FALSE;
    for ( iWear = 0; iWear < MAX_WEAR; iWear++ )
    {
	if ( ( obj = get_eq_char( victim, iWear ) ) != NULL
	&&   can_see_obj( ch, obj ) )
	{
	    if ( !found )
	    {
		send_to_char( "\n\r", ch );
		if ( victim != ch )
        act( AT_PLAIN, "$N esta usando:&x", ch, NULL, victim, TO_CHAR );
		else
		  act( AT_PLAIN, "Estas usando:&x", ch, NULL, NULL,
TO_CHAR );
		found = TRUE;
	    }
            if( (!IS_NPC(victim)) && (victim->race>0) && (victim->race<MAX_PC_RACE))
		send_to_char(race_table[victim->race]->where_name[iWear], ch);
	    else
	        send_to_char( where_name[iWear], ch );
	    send_to_char( format_obj_to_char( obj, ch, TRUE ), ch );
	    send_to_char( "\n\r", ch );
	}
    }

    /*
     * Crash fix here by Thoric
     */
    if ( IS_NPC(ch) || victim == ch )
      return;

    if ( IS_IMMORTAL( ch ) )
    {
      if ( IS_NPC( victim ) )
	ch_printf( ch, "\n\rMob #%d '%s' ",
	    victim->pIndexData->vnum,
	    victim->name );
	else
	  ch_printf( ch, "\n\r%s ", victim->name );
      ch_printf( ch, "es nivel %d %s %s.\n\r",
	victim->level,
	IS_NPC(victim)?victim->race<MAX_NPC_RACE&&victim->race>=0?
	npc_race[victim->race]:"desconocida":victim->race<MAX_PC_RACE&&
	race_table[victim->race]->race_name&&
	race_table[victim->race]->race_name[0] != '\0'?
	race_table[victim->race]->race_name:"desconocida",
	IS_NPC(victim)?victim->class<MAX_NPC_CLASS&&victim->class>=0?
	npc_class[victim->class] : "desconocida":victim->class<40&&
	class_table[victim->class]->who_name&&
	class_table[victim->class]->who_name[0] != '\0'?
	class_table[victim->class]->who_name:"deconocida");
/* Fix so it shows what is in class table
	victim->race<MAX_NPC_RACE&&victim->race>=0?npc_race[victim->race] : "unknown",
	victim->class<MAX_NPC_CLASS&&victim->class>=0?npc_class[victim->class] : "unknown" );
*/
    }

    if ( number_percent( ) < LEARNED(ch, gsn_peek) )
    {
	ch_printf( ch, "\n\rInvestigas en %s inventario:\n\r",
	  victim->sex == 1 ? "su" : victim->sex == 2 ? "su" : "su" );
	show_list_to_char( victim->first_carrying, ch, TRUE, TRUE );
	learn_from_success( ch, gsn_peek );
    }
    else
      if ( ch->pcdata->learned[gsn_peek] > 0 )
        learn_from_failure( ch, gsn_peek );

    return;
}


void show_char_to_char_2( CHAR_DATA *victim, CHAR_DATA *ch )
{
    char buf[MAX_STRING_LENGTH];
    char buf1[MAX_STRING_LENGTH];
    char buf2[MAX_STRING_LENGTH];

    buf[0] = '\0';

    set_char_color( AT_PERSON, ch );

    if ( !IS_NPC(victim) && !victim->desc )
    {
	if ( !victim->switched )         send_to_char_color( "&z[&w(&gSin Link&w)&z]&w", ch );
	else if ( !IS_AFFECTED(victim, AFF_POSSESS) )
						strcat( buf, "(Switcheado)" );
    }
    if ( IS_NPC(victim) && IS_AFFECTED(victim, AFF_POSSESS) && IS_IMMORTAL(ch)
	 && victim->desc )
    {
			sprintf( buf1, "(%s)",victim->desc->original->name );
			strcat( buf, buf1 );

    }
    if (IS_NPC(victim) && !IS_NPC(ch) && ch->pcdata->questmob > 0 && victim->pIndexData->vnum == ch->pcdata->questmob)
        strcat( buf, "&g[&YOBJETIVO&g]&w");

    if ( !IS_NPC(victim)
    &&   xIS_SET(victim->act, PLR_AFK) )	strcat( buf, "[EMPANAO]");

    if ( (!IS_NPC(victim) && xIS_SET(victim->act, PLR_WIZINVIS))
      || (IS_NPC(victim) && xIS_SET(victim->act, ACT_MOBINVIS)) )
    {
        if (!IS_NPC(victim))
	sprintf( buf1,"(Invis %d)", victim->pcdata->wizinvis );
        else sprintf( buf1,"(Mobinvis %d)", victim->mobinvis);
	strcat( buf, buf1 );
    }


    if ( !IS_NPC( victim) )
    {
	if ( IS_IMMORTAL( victim ) && victim->level > 83 )
	  send_to_char_color( "&B(&WImmortal&B)&w", ch );
	if ( victim->pcdata->clan
        &&   IS_SET( victim->pcdata->flags, PCFLAG_DEADLY )
	&&   victim->pcdata->clan->badge
	&& ( victim->pcdata->clan->clan_type != CLAN_ORDER
	&&   victim->pcdata->clan->clan_type != CLAN_GUILD ) )
                                        ch_printf_color( ch, "%s ", victim->pcdata->clan->badge );
	else if ( CAN_PKILL( victim ) && victim->level < 81 )
                           send_to_char_color( "&P(&wSolitario&P)", ch );
                   else if ( CAN_PKILL( victim ) && victim->level < 15 )
                           send_to_char_color( "&P(&oPrincipiante&P)", ch );
    }

    set_char_color( AT_PERSON, ch );

    if ( IS_AFFECTED(victim, AFF_INVISIBLE)   ) strcat( buf, "&W(&wInvis&W)&w"      );
    if ( IS_AFFECTED(victim, AFF_HIDE)        ) strcat( buf, "&W(&rOculto&W)&w"       );
    if ( IS_AFFECTED(victim, AFF_PASS_DOOR)   ) strcat( buf, "&W(&wTransluciente&W)&w");
    if ( xIS_SET(victim->afectado_por, DAF_INCORPOREO ))
	  strcat( buf, "&W(&cIncorporeo&W)&w" );
    if ( IS_AFFECTED(victim, AFF_FAERIE_FIRE) ) strcat( buf, "&W(&pAura rosa&W)&w"  );
      if ( IS_GOOD(victim) )
    if ( IS_EVIL(victim)
    &&   (  IS_AFFECTED(ch, AFF_DETECT_EVIL) || ch->class==CLASS_PALADIN)     ) strcat( buf, "&R(&rAura roja&R)&w"   );
    if ( IS_NEUTRAL(victim)
    &&   ch->class==CLASS_PALADIN  ) strcat( buf, "&W(&zAura gris&W)&w"   );
    if ( IS_GOOD(victim)
    &&   ch->class==CLASS_PALADIN  ) strcat( buf, "&W(&wAura Blanca&w)&w"   );


    if ( IS_AFFECTED(victim, AFF_BERSERK)     ) strcat( buf, "&W(&RRabioso&W)&w"  );
    if ( !IS_NPC(victim) && xIS_SET(victim->act, PLR_ATTACKER ) )
						strcat( buf, "&W(&RATACANTE&W)&w"   );
    if ( !IS_NPC(victim) && xIS_SET(victim->act, PLR_KILLER ) )
						strcat( buf, "&W(&rASESINO&W)&w"     );
    if ( !IS_NPC(victim) && xIS_SET(victim->act, PLR_THIEF  ) )
						strcat( buf, "&W(&cLADRON&W)&w"      );
    if ( !IS_NPC(victim) && xIS_SET(victim->act, PLR_LITTERBUG  ) )
						strcat( buf, "&W(&pLITTERBUG&W)&w"  );
    if ( IS_NPC(victim) && IS_IMMORTAL(ch)
	 && xIS_SET(victim->act, ACT_PROTOTYPE) )strcat( buf, "&W(&YPROTO&W)&w"      );
    if ( IS_NPC(victim) && ch->mount && ch->mount == victim
         && ch->in_room == ch->mount->in_room ) strcat( buf, "&W(&wMontado&W)&w"      );
    if ( victim->desc && victim->desc->connected == CON_EDITING )
						strcat( buf, "&W(&gEscribiendo&W)&w"    );
    if ( victim->morph != NULL )
      strcat (buf, "&W(&wTransformado&W)&w");



   if ( victim->camuflaje == NULL )
   {
   show_visible_affects_to_char( victim, ch );
   send_to_char( buf, ch);
   sprintf( buf, "%s esta aqui observando.\n\r",victim->name );
   send_to_char(buf,ch);
   return;
   }
    show_visible_affects_to_char( victim, ch );
    send_to_char( buf, ch);
    sprintf( buf, "%s\n\r", victim->camuflaje );
    send_to_char(buf,ch);
    return;
}



void show_char_to_char( CHAR_DATA *list, CHAR_DATA *ch )
{
    CHAR_DATA *rch;

    for ( rch = list; rch; rch = rch->next_in_room )
    {
	if ( rch == ch )
	    continue;

	if ( can_see( ch, rch ) )
	{
          if( xIS_SET(rch->act, PLR_CAMUFLAJE)
           || xIS_SET(rch->act, PLR_PRESENCIA))
           show_char_to_char_2( rch, ch ); /* SiGo */


           else
	    show_char_to_char_0( rch, ch );
	}
	else if ( room_is_dark( ch->in_room )
	&&        IS_AFFECTED(rch, AFF_INFRARED )
        &&        xIS_SET(rch->afectado_por, DAF_TESTIGO )
        && !(!IS_NPC(rch) && IS_IMMORTAL(rch)) )
	{
	    set_char_color( AT_BLOOD, ch );
	    send_to_char( "Sientes la mirada de alguien atravesandote la nuca.\n\r", ch );
	}
    }

    return;
}


void do_camuflaje( CHAR_DATA *ch, char *argumento )
{
        char buf[MAX_STRING_LENGTH];

        if(IS_NPC(ch))
        {
                send_to_char( "&wLos Mobs no pueden usar camuflaje\n\r", ch);
                return;
        }

        if ( argumento[0] =='\0')
        {
          if(!xIS_SET(ch->act, PLR_CAMUFLAJE))
          {
                xSET_BIT(ch->act, PLR_CAMUFLAJE);
                send_to_char( "&wCamuflaje ACTIVADO.\n\r", ch);

                if( ch->camuflaje == NULL)
                {
                send_to_char( "Tu camuflaje actual es Nulo saliste del juego con el camuflaje desactivado.\n\r", ch);
                send_to_char( "Vuelve a introducir tu camuflaje para que quede grabado.\n\r", ch);
                }
                return;
          }

         if(xIS_SET(ch->act, PLR_CAMUFLAJE))
         {
                xREMOVE_BIT(ch->act, PLR_CAMUFLAJE);
                send_to_char( "&wCamuflaje DESACTIVADO.\n\r", ch);
                return;
         }
         if (!ch)
         bug( "Do_Camuflaje ch Nulo", 0);
         return;
       }

        if( xIS_SET(ch->act, PLR_CAMUFLAJE) )
        {
        xREMOVE_BIT( ch->act, PLR_CAMUFLAJE );
        ch->camuflaje = STRALLOC( argumento );
        sprintf(buf, "Tu nuevo camuflaje es: %s\n\r", ch->camuflaje);
        send_to_char( buf, ch );
        xSET_BIT(ch->act, PLR_CAMUFLAJE);
        send_to_char( "&wCamuflaje ACTIVADO.\n\r", ch);
        }
        else
        {
        ch->camuflaje = STRALLOC( argumento );
        sprintf(buf, "Tu nuevo camuflaje es: %s\n\r", ch->camuflaje);
        send_to_char( buf, ch );
        send_to_char( "&wTu camuflaje esta actualmente DESACTIVADO.\n\r", ch );
        }

        return;
}



bool check_blind( CHAR_DATA *ch )
{
    if ( !IS_NPC(ch) && xIS_SET(ch->act, PLR_HOLYLIGHT) )
	return TRUE;

    if ( IS_AFFECTED(ch, AFF_TRUESIGHT) )
      return TRUE;

    if ( IS_AFFECTED(ch, AFF_BLIND) )
    {
	send_to_char( "No puedes ver nada!\n\r", ch );
	return FALSE;
    }

    return TRUE;
}

/*
 * Returns classical DIKU door direction based on text in arg	-Thoric
 */
int get_door( char *arg )
{
    int door;

	 if ( !str_cmp( arg, "n"  ) || !str_cmp( arg, "norte"	  ) ) door = 0;
    else if ( !str_cmp( arg, "e"  ) || !str_cmp( arg, "este"	  ) ) door = 1;
    else if ( !str_cmp( arg, "s"  ) || !str_cmp( arg, "sur"	  ) ) door = 2;
    else if ( !str_cmp( arg, "o"  ) || !str_cmp( arg, "oeste"	  ) ) door = 3;
    else if ( !str_cmp( arg, "a"  ) || !str_cmp( arg, "arriba"	  ) ) door = 4;
    else if ( !str_cmp( arg, "b"  ) || !str_cmp( arg, "abajo"	  ) ) door = 5;
    else if ( !str_cmp( arg, "ne" ) || !str_cmp( arg, "noreste" ) ) door = 6;
    else if ( !str_cmp( arg, "no" ) || !str_cmp( arg, "noroeste" ) ) door = 7;
    else if ( !str_cmp( arg, "se" ) || !str_cmp( arg, "sureste" ) ) door = 8;
    else if ( !str_cmp( arg, "so" ) || !str_cmp( arg, "suroeste" ) ) door = 9;
    else door = -1;
    return door;
}

void do_look( CHAR_DATA *ch, char *argument )
{
    char arg  [MAX_INPUT_LENGTH];
    char arg1 [MAX_INPUT_LENGTH];
    char arg2 [MAX_INPUT_LENGTH];
    char arg3 [MAX_INPUT_LENGTH];
    char *kwd; /* cronel hiscore */
    EXIT_DATA *pexit;
    CHAR_DATA *victim;
    OBJ_DATA *obj;
    ROOM_INDEX_DATA *original;
    char *pdesc;
    bool doexaprog;
    sh_int door;
    int number, cnt;

    if ( !ch->desc )
	return;

    if ( ch->position < POS_SLEEPING )
    {
	send_to_char( "No puedes ver nada.\n\r", ch );
	return;
    }

    if ( ch->position == POS_SLEEPING )
    {
	send_to_char( "No puedes ver nada, estas durmiendo!\n\r", ch );
	return;
    }

    if ( !check_blind( ch ) )
	return;

    if ( !IS_NPC(ch)
    &&   !xIS_SET(ch->act, PLR_HOLYLIGHT)
    &&   !IS_AFFECTED(ch, AFF_TRUESIGHT)
    &&   !xIS_SET(ch->afectado_por, DAF_TESTIGO)
    &&   room_is_dark( ch->in_room ) )
    {
	set_char_color( AT_DGREY, ch );
	send_to_char( "Esta muy oscuro... \n\r", ch );
	show_char_to_char( ch->in_room->first_person, ch );
	return;
    }

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    argument = one_argument( argument, arg3 );

    doexaprog = str_cmp( "noprog", arg2 ) && str_cmp( "noprog", arg3 );

    if ( arg1[0] == '\0' || !str_cmp( arg1, "auto" ) )
    {
	switch ( ch->inter_page )    /* rmenu */
	{
	   case ROOM_PAGE_A : do_rmenu(ch,"a");
			      break;
	   case ROOM_PAGE_B : do_rmenu(ch,"b");
			      break;
	   case ROOM_PAGE_C : do_rmenu(ch,"c");
			      break;
        }
	/* 'look' or 'look auto' */
	set_char_color( AT_DGREEN, ch );
	send_to_char( ch->in_room->name, ch );
	send_to_char( "\n\r", ch );
	set_char_color( AT_GREY, ch );

	if ( arg1[0] == '\0'
	|| ( !IS_NPC(ch) && !xIS_SET(ch->act, PLR_BRIEF) ) )
	    send_to_char( ch->in_room->description, ch );

	if ( !IS_NPC(ch) && xIS_SET(ch->act, PLR_AUTOMAP) )   /* maps */
	{
	    if(ch->in_room->map != NULL)
	    {
	       do_lookmap(ch, NULL);
	    }
	}

	if ( !IS_NPC(ch) && xIS_SET(ch->act, PLR_AUTOEXIT) )
	    do_exits( ch, "auto" );


	show_list_to_char( ch->in_room->first_content, ch, FALSE, FALSE );
	show_char_to_char( ch->in_room->first_person,  ch );
	return;
    }

    if ( !str_cmp( arg1, "debajo" ) )
    {
	int count;

	/* 'look under' */
	if ( arg2[0] == '\0' )
	{
	    send_to_char( "Mirar debajo de que?\n\r", ch );
	    return;
	}

	if ( ( obj = get_obj_here( ch, arg2 ) ) == NULL )
	{
	    send_to_char( "No ves nada de eso aqui.\n\r", ch );
	    return;
	}
	if ( !CAN_WEAR( obj, ITEM_TAKE ) && ch->level < sysdata.level_getobjnotake )
	{
	    send_to_char( "No parece que puedas hacerlo.\n\r", ch );
	    return;
	}
	if ( ch->carry_weight + obj->weight > can_carry_w( ch ) )
	{
	    send_to_char( "Es demasiado pesado para poder mirar debajo.\n\r", ch );
	    return;
	}
	count = obj->count;
	obj->count = 1;
	act( AT_PLAIN, "Levantas $p y miras debajo:", ch, obj, NULL, TO_CHAR );
	act( AT_PLAIN, "$n levanta $p y mira debajo:", ch, obj, NULL, TO_ROOM );
	obj->count = count;
	if ( IS_OBJ_STAT( obj, ITEM_COVERING ) )
	   show_list_to_char( obj->first_content, ch, TRUE, TRUE );
	else
	   send_to_char( "Nada.\n\r", ch );
	if ( doexaprog ) oprog_examine_trigger( ch, obj );
	return;
    }

    if ( !str_cmp( arg1, "i" ) || !str_cmp( arg1, "in" ) )
    {
	int count;

	/* 'look in' */
	if ( arg2[0] == '\0' )
	{
	    send_to_char( "Mirar dentro de que?\n\r", ch );
	    return;
	}

	if ( ( obj = get_obj_here( ch, arg2 ) ) == NULL )
	{
	    send_to_char( "No ves eso aqui.\n\r", ch );
	    return;
	}

	switch ( obj->item_type )
	{
	default:
	    send_to_char( "Eso no es un container.\n\r", ch );
	    break;

	case ITEM_DRINK_CON:
	    if ( obj->value[1] <= 0 )
	    {
		send_to_char( "Esta vacio.\n\r", ch );
	        if ( doexaprog ) oprog_examine_trigger( ch, obj );
		break;
	    }

	    ch_printf( ch, "Esta %s lleno de un liquido %s.\n\r",
		obj->value[1] <     obj->value[0] / 4
		    ? "menos" :
		obj->value[1] < 3 * obj->value[0] / 4
		    ? "igual"     : "mas",
		liq_table[obj->value[2]].liq_color
		);

	    if ( doexaprog ) oprog_examine_trigger( ch, obj );
	    break;

	case ITEM_PORTAL:
	    for ( pexit = ch->in_room->first_exit; pexit; pexit = pexit->next )
	    {
		if ( pexit->vdir == DIR_PORTAL
		&&   IS_SET(pexit->exit_info, EX_PORTAL) )
		{
		    if ( room_is_private( pexit->to_room )
		    &&   get_trust(ch) < sysdata.level_override_private )
		    {
			set_char_color( AT_WHITE, ch );
			send_to_char( "Esa habitacion es privada ahora!\n\r", ch );
			return;
		    }
		    original = ch->in_room;
		    char_from_room( ch );
		    char_to_room( ch, pexit->to_room );
		    do_look( ch, "auto" );
		    char_from_room( ch );
		    char_to_room( ch, original );
		    return;
		}
	    }
	    send_to_char( "Ves el caos...\n\r", ch );
	    break;
	case ITEM_CONTAINER:
	case ITEM_QUIVER:
	case ITEM_CORPSE_NPC:
	case ITEM_CORPSE_PC:
	    if ( IS_SET(obj->value[1], CONT_CLOSED) )
	    {
		send_to_char( "Esta cerrado.\n\r", ch );
		break;
	    }

	case ITEM_KEYRING:
	    count = obj->count;
	    obj->count = 1;
	    if ( obj->item_type == ITEM_CONTAINER )
		act( AT_PLAIN, "$p contiene:", ch, obj, NULL, TO_CHAR );
	    else
		act( AT_PLAIN, "$p tiene:", ch, obj, NULL, TO_CHAR );
	    obj->count = count;
	    show_list_to_char( obj->first_content, ch, TRUE, TRUE );
	    if ( doexaprog ) oprog_examine_trigger( ch, obj );
	    break;
	}
	return;
    }

    if ( (pdesc=get_extra_descr(arg1, ch->in_room->first_extradesc)) != NULL )
    {
	send_to_char_color( pdesc, ch );
	return;
    }

    door = get_door(arg1);
    if ( (pexit=find_door(ch, arg1, TRUE)) != NULL )
    {
	if ( IS_SET(pexit->exit_info, EX_CLOSED)
	&&  !IS_SET(pexit->exit_info, EX_WINDOW) )
	{
	    if ( (IS_SET(pexit->exit_info, EX_SECRET)
	    ||    IS_SET(pexit->exit_info, EX_DIG)) && door != -1 )
		send_to_char( "Nada en especial.\n\r", ch );
	    else
		act( AT_PLAIN, "El $d esta cerrado.", ch, NULL, pexit->keyword, TO_CHAR );
	    return;
	}
	if ( IS_SET( pexit->exit_info, EX_BASHED ) )
	    act(AT_RED, "El $d ha sido arrancado de sus goznes!",ch, NULL, pexit->keyword, TO_CHAR);

	if ( pexit->description && pexit->description[0] != '\0' )
	    send_to_char( pexit->description, ch );
	else
	    send_to_char( "Nada en especial.\n\r", ch );

	/*
	 * Ability to look into the next room			-Thoric
	 */
	if ( pexit->to_room
	&& ( IS_AFFECTED( ch, AFF_SCRYING )
	||   ch->class == CLASS_THIEF
	||   IS_SET( pexit->exit_info, EX_xLOOK )
	||   get_trust(ch) >= LEVEL_IMMORTAL ) )
	{
	    if ( !IS_SET( pexit->exit_info, EX_xLOOK )
	    &&    get_trust( ch ) < LEVEL_IMMORTAL )
	    {
		set_char_color( AT_MAGIC, ch );
		send_to_char( "Lo intetas...\n\r", ch );
		/*
		 * Change by Narn, Sept 96 to allow characters who don't have the
		 * scry spell to benefit from objects that are affected by scry.
		 */

		if (!IS_NPC(ch) )
		{
		    int percent = LEARNED(ch, skill_lookup("scry") );
		    if ( !percent )
		    {
			if ( ch->class == CLASS_THIEF )
			    percent = 95;
			else
			    percent = 55;
		    }

		    if ( number_percent( ) > percent )
		    {
			send_to_char( "Fallaste.\n\r", ch );
			return;
		    }
		}
	    }
	    if ( room_is_private( pexit->to_room )
	    &&   get_trust(ch) < sysdata.level_override_private )
	    {
		set_char_color( AT_WHITE, ch );
		send_to_char( "La habitacion es privada!\n\r", ch );
		return;
	    }
	    original = ch->in_room;
	    char_from_room( ch );
	    char_to_room( ch, pexit->to_room );
	    do_look( ch, "auto" );
	    char_from_room( ch );
	    char_to_room( ch, original );
	}
	return;
    }
    else
    if ( door != -1 )
    {
	send_to_char( "Nada en especial.\n\r", ch );
	return;
    }

    if ( (victim = get_char_room(ch, arg1)) != NULL )
    {
	show_char_to_char_1( victim, ch );
	return;
    }


    /* finally fixed the annoying look 2.obj desc bug	-Thoric */
    number = number_argument( arg1, arg );
    for ( cnt = 0, obj = ch->last_carrying; obj; obj = obj->prev_content )
    {

    /* cronel hiscore */
       kwd = is_hiscore_obj( obj );
       if( kwd )
       {
               show_hiscore( kwd, ch );
               return;
       }
	if ( can_see_obj( ch, obj ) )
	{
	    if ( (pdesc=get_extra_descr(arg, obj->first_extradesc)) != NULL )
	    {
		if ( (cnt += obj->count) < number )
		  continue;
		send_to_char_color( pdesc, ch );
	        if ( doexaprog ) oprog_examine_trigger( ch, obj );
		return;
	    }

	    if ( (pdesc=get_extra_descr(arg, obj->pIndexData->first_extradesc)) != NULL )
	    {
		if ( (cnt += obj->count) < number )
		  continue;
		send_to_char_color( pdesc, ch );
	        if ( doexaprog ) oprog_examine_trigger( ch, obj );
		return;
	    }
	    if ( nifty_is_name_prefix( arg, obj->name ) )
	    {
		if ( (cnt += obj->count) < number )
		  continue;
		pdesc = get_extra_descr( obj->name, obj->pIndexData->first_extradesc );
		if ( !pdesc )
		  pdesc = get_extra_descr( obj->name, obj->first_extradesc );
		if ( !pdesc )
		  send_to_char_color( "No ves nada en especial.\r\n", ch );
		else
		  send_to_char_color( pdesc, ch );
		if ( doexaprog ) oprog_examine_trigger( ch, obj );
		  return;
	    }
	}
    }

    for ( obj = ch->in_room->last_content; obj; obj = obj->prev_content )
    {

    /* cronel hiscore */
       kwd = is_hiscore_obj( obj );
       if( kwd )
       {
               show_hiscore( kwd, ch );
               return;
       }

	if ( can_see_obj( ch, obj ) )
	{
	    if ( (pdesc=get_extra_descr(arg, obj->first_extradesc)) != NULL )
	    {
		if ( (cnt += obj->count) < number )
		  continue;
		send_to_char_color( pdesc, ch );
	        if ( doexaprog ) oprog_examine_trigger( ch, obj );
		return;
	    }

	    if ( (pdesc=get_extra_descr(arg, obj->pIndexData->first_extradesc)) != NULL )
	    {
		if ( (cnt += obj->count) < number )
		  continue;
		send_to_char_color( pdesc, ch );
	        if ( doexaprog ) oprog_examine_trigger( ch, obj );
		return;
	    }
	    if ( nifty_is_name_prefix( arg, obj->name ) )
	    {
		if ( (cnt += obj->count) < number )
		  continue;
		pdesc = get_extra_descr( obj->name, obj->pIndexData->first_extradesc );
		if ( !pdesc )
		  pdesc = get_extra_descr( obj->name, obj->first_extradesc );
		if ( !pdesc )
		  send_to_char( "No ves nada en especial.\r\n", ch );
		else
		  send_to_char_color( pdesc, ch );
		if ( doexaprog ) oprog_examine_trigger( ch, obj );
		  return;
	    }
	}
    }

    send_to_char( "No ves eso aqui.\n\r", ch );
    return;
}

void show_race_line( CHAR_DATA *ch, CHAR_DATA *victim )
{
    char buf[MAX_STRING_LENGTH];
    int feet, inches;


	if ( !IS_NPC(victim) && (victim != ch) )
	{
		feet =  victim->height / 12;
		inches = victim->height % 12;
		sprintf( buf, "%s es %d'%d\" y pesa %d libras.\n\r", PERS(victim, ch), feet, inches, (victim->weight/2) );
		send_to_char( buf, ch);
                return;
        }
	if ( !IS_NPC(victim) && (victim == ch) )
	{
		feet =  victim->height / 12;
		inches = victim->height % 12;
		sprintf( buf, "Eres %d'%d\" y pesas %d libras.\n\r",  feet, inches, victim->weight );
		send_to_char( buf, ch);
                return;
        }

}


void show_condition( CHAR_DATA *ch, CHAR_DATA *victim )
{
    char buf[MAX_STRING_LENGTH];
    int percent;

    if ( victim->max_hit > 0 )
        percent = ( 100 * victim->hit ) / victim->max_hit;
    else
        percent = -1;


    if ( victim != ch )
    {
	strcpy( buf, PERS(victim, ch) );
             if ( percent >= 100 ) strcat( buf, " esta en perfecta forma.\n\r" );
	else if ( percent >=  90 ) strcat( buf, " tiene algun aranyazo.\n\r" );
        else if ( percent >=  80 ) strcat( buf, " tiene algunas heridas.\n\r"     );
	else if ( percent >=  70 ) strcat( buf, " tiene algunas heridas.\n\r"         );
	else if ( percent >=  60 ) strcat( buf, " esta herido de consideracion.\n\r"    );
	else if ( percent >=  50 ) strcat( buf, " esta herido de consideracion.\n\r" );
        else if ( percent >=  40 ) strcat( buf, " esta sangrando a borbotones.\n\r"    );
	else if ( percent >=  30 ) strcat( buf, " esta cubierto de sangre.\n\r"   );
	else if ( percent >=  20 ) strcat( buf, " esta palideciendo al ver que la muerte se le acerca.\n\r"       );
	else if ( percent >=  10 ) strcat( buf, " esta entre la vida y la muerte.\n\r"        );
	else                       strcat( buf, " esta entre la vida y la muerte.\n\r"              );
    }
    else
    {
	strcpy( buf, "Tu" );
	     if ( percent >= 100 ) strcat( buf, " estas en perfecta forma.\n\r" );
	else if ( percent >=  90 ) strcat( buf, " tienes algun aranyazo.\n\r");
        else if ( percent >=  80 ) strcat( buf, " tienes algunas heridas.\n\r"    );
        else if ( percent >=  70 ) strcat( buf, " tienes algunas heridas.\n\r"        );
        else if ( percent >=  60 ) strcat( buf, " estas herido de consideracion.\n\r"   );
        else if ( percent >=  50 ) strcat( buf, " estas herido de consideracion.\n\r");
	else if ( percent >=  40 ) strcat( buf, " estas sangrando a borbotones.\n\r"   );
	else if ( percent >=  30 ) strcat( buf, " estas cubierto de sangre.\n\r"  );
	else if ( percent >=  20 ) strcat( buf, " estas palideciendo al ver que la muerte se te acerca.\n\r"      );
	else if ( percent >=  10 ) strcat( buf, " estas entre la vida y la muerte.\n\r"       );
	else                       strcat( buf, " estas entre la vida y la muerte.\n\r"             );
    }

    buf[0] = UPPER(buf[0]);
    send_to_char( buf, ch );
    return;
}

/* A much simpler version of look, this function will show you only
the condition of a mob or pc, or if used without an argument, the
same you would see if you enter the room and have config +brief.
-- Narn, winter '96
*/
void do_glance( CHAR_DATA *ch, char *argument )
{
  char arg1 [MAX_INPUT_LENGTH];
  CHAR_DATA *victim;
  bool brief;

  if ( !ch->desc )
    return;

  if ( ch->position < POS_SLEEPING )
  {
    send_to_char( "No puedes ver nada.\n\r", ch );
    return;
  }

  if ( ch->position == POS_SLEEPING )
  {
    send_to_char( "No puedes ver nada, estas durmiendo!\n\r", ch );
    return;
  }

  if ( !check_blind( ch ) )
    return;

  set_char_color( AT_ACTION, ch );
  argument = one_argument( argument, arg1 );

  if ( arg1[0] == '\0' )
  {
    if ( xIS_SET(ch->act, PLR_BRIEF) )
	brief = TRUE;
    else
	brief = FALSE;
    xSET_BIT( ch->act, PLR_BRIEF );
    do_look( ch, "auto" );
    if ( !brief )
	xREMOVE_BIT(ch->act, PLR_BRIEF);
    return;
  }

  if ( ( victim = get_char_room( ch, arg1 ) ) == NULL )
  {
    send_to_char( "No esta aqui.\n\r", ch );
    return;
  }
  else
  {
    if ( can_see( victim, ch ) )
    {
	act( AT_ACTION, "$n te echa un vistazo.", ch, NULL, victim, TO_VICT );
	act( AT_ACTION, "$n echa un vistazo a $N.",  ch, NULL, victim, TO_NOTVICT );
    }
    if ( IS_IMMORTAL( ch ) && victim != ch )
    {
	if ( IS_NPC( victim ) )
	    ch_printf( ch, "Mob #%d '%s' ",
		victim->pIndexData->vnum, victim->name );
	else
	    ch_printf( ch, "%s ", victim->name );
	ch_printf( ch, "es nivel %d %s %s.\n\r",
	    victim->level,
	    IS_NPC(victim)?victim->race<MAX_NPC_RACE&&victim->race>=0?
            npc_race[victim->race] : "desconocida":victim->race<MAX_PC_RACE&&
            race_table[victim->race]->race_name&&
            race_table[victim->race]->race_name[0] != '\0'?
            race_table[victim->race]->race_name:"desconocida",
            IS_NPC(victim)?victim->class<MAX_NPC_CLASS&&victim->class>=0?
            npc_class[victim->class] : "desconocida":victim->class<40&&
            class_table[victim->class]->who_name&&
            class_table[victim->class]->who_name[0] != '\0'?
            class_table[victim->class]->who_name:"desconocida");
/* New Change
	    victim->race<MAX_NPC_RACE&&victim->race>=0?npc_race[victim->race] : "unknown",
	    victim->class<MAX_NPC_CLASS&&victim->class>=0?npc_class[victim->class] : "unknown" );
*/
    }
    show_condition( ch, victim );

    return;
  }

  return;
}


void do_examine( CHAR_DATA *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    OBJ_DATA *obj;
    CMDTYPE *comando;
  /*  BOARD_DATA *board;  */
    sh_int dam;

    if ( !argument )
    {
	bug( "do_examine: null argument.", 0);
	return;
    }

    if ( !ch )
    {
	bug( "do_examine: null ch.", 0);
	return;
    }

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Examinar el que?\n\r", ch );
	return;
    }

    sprintf( buf, "%s noprog", arg );
    do_look( ch, buf );

    /*
     * Support for looking at boards, checking equipment conditions,
     * and support for trigger positions by Thoric
     */
    if ( (obj = get_obj_here(ch, arg)) != NULL )
    {
/*   if ( (board = get_board(obj)) != NULL )
	{
	    if ( board->num_posts )
		ch_printf( ch, "Tienes %d notas aqui. Prueba 'nota list' para ver el listado.\n\r", board->num_posts );
	    else
		send_to_char( "No tienes ninguna nota aqui.\n\r", ch );
	}
  */
	switch ( obj->item_type )
	{
	default:
	    break;

   case ITEM_ARMOR:
	    if ( obj->value[1] == 0 )
	      obj->value[1] = obj->value[0];
	    if ( obj->value[1] == 0 )
	      obj->value[1] = 1;
	    dam = (sh_int) ((obj->value[0] * 10) / obj->value[1]);
	    strcpy( buf, "Cuando lo examinas mas atentamente, te percibes de que esta ");
	    if (dam >= 10) strcat( buf, "en excelentes condiciones.");
       else if (dam ==  9) strcat( buf, "en muy buenas condiciones.");
       else if (dam ==  8) strcat( buf, "en buenas condiciones.");
       else if (dam ==  7) strcat( buf, "un poco gastado.");
       else if (dam ==  6) strcat( buf, "algo estropeado.");
       else if (dam ==  5) strcat( buf, "necesitando ser reparado.");
       else if (dam ==  4) strcat( buf, "necesitando ser reparado.");
       else if (dam ==  3) strcat( buf, "necesitando ser REPARADO.");
       else if (dam ==  2) strcat( buf, "muy danyado.");
       else if (dam ==  1) strcat( buf, "practicamente inservible.");
       else if (dam <=  0) strcat( buf, "roto.");
	    strcat( buf, "\n\r" );
	    send_to_char( buf, ch );
	    break;

	case ITEM_WEAPON:
	    dam = INIT_WEAPON_CONDITION - obj->value[0];
	    strcpy( buf, "Cuando lo examinas mas atentamente, te percibes de que esta ");
	    if (dam ==  0) strcat( buf, "en excelentes condiciones.");
       else if (dam ==  1) strcat( buf, "en muy buenas condiciones.");
       else if (dam ==  2) strcat( buf, "en buenas condiciones.");
       else if (dam ==  3) strcat( buf, "en buenas condiciones.");
       else if (dam ==  4) strcat( buf, "un poco gastado.");
       else if (dam ==  5) strcat( buf, "algo estropeado.");
       else if (dam ==  6) strcat( buf, "necesitando ser reparado.");
       else if (dam ==  7) strcat( buf, "necesitando ser reparado.");
       else if (dam ==  8) strcat( buf, "necesitando ser REPARADO.");
       else if (dam ==  9) strcat( buf, "muy danyado.");
       else if (dam == 10) strcat( buf, "practicamente inservible.");
       else if (dam == 11) strcat( buf, "casi roto.");
       else if (dam == 12) strcat( buf, "roto.");
	    strcat( buf, "\n\r" );
	    send_to_char( buf, ch );
	    break;

	case ITEM_COOK:
	    strcpy( buf, "Cuando lo examinas mas atentamente, te percibes de que " );
	    dam = obj->value[2];
	     if (dam >= 3) strcat( buf, "esta quemado.");
	else if (dam == 1) strcat( buf, "esta demasiado hecho.");
	else if (dam == 1) strcat( buf, "esta en su punto.");
	else		   strcat( buf, "esta crudo.");
	    strcat( buf, "\n\r" );
	    send_to_char( buf, ch );
	case ITEM_FOOD:
	    if ( obj->timer > 0 && obj->value[1] > 0 )
	      dam = (obj->timer * 10) / obj->value[1];
	    else
	      dam = 10;
	    if ( obj->item_type == ITEM_FOOD )
	      strcpy( buf, "Cuando lo examinas mas atentamente, te percibes de que " );
	    else
	      strcpy( buf, "Tambien eso " );
	    if (dam >= 10) strcat( buf, "es fresco.");
       else if (dam ==  9) strcat( buf, "es fresco.");
       else if (dam ==  8) strcat( buf, "tiene muy buena pinta.");
       else if (dam ==  7) strcat( buf, "tiene buena pinta.");
       else if (dam ==  6) strcat( buf, "parece bueno.");
       else if (dam ==  5) strcat( buf, "parece comestible.");
       else if (dam ==  4) strcat( buf, "parece algo rancio.");
       else if (dam ==  3) strcat( buf, "parece muy rancio.");
       else if (dam ==  2) strcat( buf, "huele algo mal.");
       else if (dam ==  1) strcat( buf, "huele muy mal!");
       else if (dam <=  0) strcat( buf, "esta cubierto de gusanos!");
	    strcat( buf, "\n\r" );
	    send_to_char( buf, ch );
	    break;


	case ITEM_SWITCH:
	case ITEM_LEVER:
	case ITEM_PULLCHAIN:
	    if ( IS_SET( obj->value[0], TRIG_UP ) )
		send_to_char( "Ves que esta hacia arriba.\n\r", ch );
	    else
		send_to_char( "Ves que esta hacia abajo.\n\r", ch );
	    break;
	case ITEM_BUTTON:
	    if ( IS_SET( obj->value[0], TRIG_UP ) )
		send_to_char( "Ves que esta pulsado.\n\r", ch );
	    else
		send_to_char( "Ves que no esta pulsado.\n\r", ch );
	    break;

/* Not needed due to check in do_look already
	case ITEM_PORTAL:
	    sprintf( buf, "en %s noprog", arg );
	    do_look( ch, buf );
	    break;
*/

   case ITEM_CORPSE_PC:
	case ITEM_CORPSE_NPC:
            {
		sh_int timerfrac = obj->timer;
		if ( obj->item_type == ITEM_CORPSE_PC )
		timerfrac = (int)obj->timer / 8 + 1;

		switch (timerfrac)
		{
		    default:
			send_to_char( "Esta pobre alma ha sido llevada a los Infiernos con SiGo hace poco.\n\r", ch );
			break;
		    case 4:
			send_to_char( "Ves como la sangre en coagulacion forma grandes costras sobre este cuerpo.\n\r", ch );
			break;
		    case 3:
			send_to_char( "Este cuerpo esta en pleno estado de putrefaccion.\n\r", ch );
			break;
		    case 2:
			send_to_char( "Esto ya empieza a apestar... basurerooooooooo!!.\n\r", ch );
			break;
		    case 1:
		    case 0:
			send_to_char( "Poco mas que huesos es lo unico que queda de este cuerpo.\n\r", ch );
			break;
		}
            }
	case ITEM_CONTAINER:
	    if ( IS_OBJ_STAT( obj, ITEM_COVERING ) )
		break;
	case ITEM_DRINK_CON:
	case ITEM_QUIVER:
	    send_to_char( "Cuando miras dentro, puedes ver:\n\r", ch );
	case ITEM_KEYRING:
	    sprintf( buf, "in %s noprog", arg );
	    do_look( ch, buf );
	    break;
	}
	if ( IS_OBJ_STAT( obj, ITEM_COVERING ) )
	{
	    sprintf( buf, "bajo %s noprog", arg );
	    do_look( ch, buf );
	}
	oprog_examine_trigger( ch, obj );
	if ( char_died(ch) || obj_extracted(obj) )
	    return;

	check_for_trap( ch, obj, TRAP_EXAMINE );
    }
    return;
}


void do_exits( CHAR_DATA *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    EXIT_DATA *pexit;
    bool found;
    bool fAuto;

    set_char_color( AT_EXITS, ch );
    buf[0] = '\0';
    fAuto  = !str_cmp( argument, "auto" );

    if ( !check_blind(ch) )
	return;

    strcpy( buf, fAuto ? "[Salidas:]" : "[Salidas obvias:]\n\r" );

    found = FALSE;
    for ( pexit = ch->in_room->first_exit; pexit; pexit = pexit->next )
    {
	if ( pexit->to_room
	&&  !IS_SET(pexit->exit_info, EX_CLOSED)
	&& (!IS_SET(pexit->exit_info, EX_WINDOW)
	||   IS_SET(pexit->exit_info, EX_ISDOOR))
	&&  !IS_SET(pexit->exit_info, EX_HIDDEN) )
	{
	    found = TRUE;
	    if ( fAuto )
	    {
		strcat( buf, " " );
		strcat( buf, dir_name[pexit->vdir] );
	    }
	    else
	    {
		sprintf( buf + strlen(buf), "%-5s - %s\n\r",
		    capitalize( dir_name[pexit->vdir] ),
		    room_is_dark( pexit->to_room )
			?  "Demasiado oscuro"
			: pexit->to_room->name
		    );
	    }
	}
    }

    if ( !found )
	strcat( buf, fAuto ? " ninguna.\n\r" : "Ninguna.\n\r" );
    else
      if ( fAuto )
	strcat( buf, ".\n\r" );
    send_to_char( buf, ch );
    return;
}

char *	const	day_name	[] =
{
    "Lunes", "Martes", "Miercoles", "Jueves", "Viernes",
    "Sabado(la juerga padre)", "Domingo(el bajon o el descanso)"
};

char *	const	month_name	[] =
{
    "Invierno", "el Lobo Blanco", "el Gigante de Hielo", "Sanguinari",
    "Sigo", "la Primavera", "la Naturaleza", "la Fertilidad", "el Dragon",
    "el Sol", "Kayser", "la Soberbia", "la Oscuridad", "las Sombras",
    "el Gran Mal", "Baali", "Kurt Cobain"
};

/***************************************************************************
*   Muestra el mana o sangre (si vampiro) requerido para hacer un conjuro  *
*          Creado por Desden, el Chaman Tibetano - Jun 1999                *
*     Snippets : http://personal2.redestb.es/jlalbatros/smaug_snippets.htm *
*                Email: jlalbatros@mx2.redestb.es                          *
***************************************************************************/
void do_mana( CHAR_DATA *ch, char *argument)
{
SKILLTYPE *skill=NULL;
CMDTYPE *comando;
char arg1[MAX_INPUT_LENGTH];
int sn;
int col = 0;

argument=one_argument(argument, arg1);

if (IS_NPC(ch))
   {
   send_to_char("Los mobs no pueden usar este comando.\n\r", ch);
  return;
    }

if (ch->class==CLASS_WARRIOR)
 {
 send_to_char("Los guerreros no usan mana para conjurar.\n\r",ch);
 return;
 }

if (arg1[0]=='\0')
 {
  if(IS_VAMPIRE(ch))
  send_to_char("Sintaxis: sangre todo\n\r       sangre <conjuro>\n\r",ch);
  else
  send_to_char("Sintaxis: mana todo\n\r       mana <conjuro>\n\r",ch);
  return;
 }

if(!strcmp(arg1,"todo"))
 {
  set_pager_color(AT_YELLOW,ch);

 if(IS_VAMPIRE(ch))
 send_to_pager("                      SANGRE MINIMA PARA CONJURAR\n\r", ch);
 else
 send_to_pager("                     MANA MINIMO PARA CONJURAR\n\r", ch);

 send_to_pager("                      -------------------------\n\r", ch);

for ( sn = 0; sn < top_sn ; sn++ )
       	{
 	  skill=get_skilltype(sn);
          if(ch->pcdata->learned[sn] < 1 ||
           !skill->name || !skill->min_mana )
         continue;

      if(ch->level>=skill->skill_level[ch->class]  )
       {
          if(IS_VAMPIRE(ch))
           {
            if(ch->pcdata->condition[COND_BLOODTHIRST] >= BLOOD)
        	pager_printf_color(ch, "&Y%-12.12s:%4d   ",
                  skill->name, BLOOD);
            else
	     pager_printf_color(ch, "&R%-12.12s:%4d   ",
                skill->name, BLOOD);
           }
       else
           {
          if(ch->mana >= MANA)
        	pager_printf_color(ch, "&Y%-12.12s:%4d   ",
                  skill->name, MANA );
           else
	     pager_printf_color(ch, "&R%-12.12s:%4d   ",
                skill->name, MANA );
           }

          if(++col % 4 == 0)

          pager_printf(ch,"\n\r");

        }
     }

         pager_printf(ch,"\n\r");
   }

   else

   {
    if((sn =skill_lookup( arg1)) > 0)
     {
     skill=get_skilltype(sn);

     if(!skill->min_mana)
     {
      ch_printf(ch, "%s, '%s' no necesita puntos de %s.\n\r", ch->name, skill->name, IS_VAMPIRE(ch)?"sangre":"mana");
    return;
     }

 if(ch->pcdata->learned[sn] < 1)
       {
         if (  ch->level < skill->skill_level[ch->class]  )
         {
         send_to_char( "No tienes suficiente nivel para conjurar eso.\n\r", ch );
         return;
         }
       else
        {
       send_to_char("Debes practicar un conjuro antes de poder usarlo.\n\r",ch);
       return;
       }
      }

  pager_printf(ch,"Necesitas %d puntos de %s para conjurar '%s' con exito.\n\r",IS_VAMPIRE(ch)?BLOOD:MANA,IS_VAMPIRE(ch)?"sangre":"mana", skill->name);
    }
else
    ch_printf(ch, "Eso no es un conjuro o habilidad.\n\r");
   }
return;
}
void do_time( CHAR_DATA *ch, char *argument )
{
    extern char str_boot_time[];
    extern char reboot_time[];
    char *suf;
    int day;

    day     = time_info.day + 1;

	 if ( day > 4 && day <  20 ) suf = "th";
    else if ( day % 10 ==  1       ) suf = "st";
    else if ( day % 10 ==  2       ) suf = "nd";
    else if ( day % 10 ==  3       ) suf = "rd";
    else                             suf = "th";

    set_char_color( AT_YELLOW, ch );
    ch_printf( ch,
	"Son las %d en punto %s, Dia:  %s, %d%s del Mes de %s.\n\r"
        "El mud empezo a:    %s\r"
        "La hora del sistema es: %s\r"
        "El proximo Reboot sera:   %s\r",

	(time_info.hour % 12 == 0) ? 12 : time_info.hour % 12,
	time_info.hour >= 12 ? "pm" : "am",
	day_name[day % 7],
	day, suf,
	month_name[time_info.month],
	str_boot_time,
	(char *) ctime( &current_time ),
	reboot_time
	);

    return;
}

/*
void do_weather( CHAR_DATA *ch, char *argument )
{
    static char * const sky_look[4] =
    {
	"despejado",
	"nublado",
	"lluvioso",
	"de perros, el cielo esta iluminado por rayos y truenos"
    };

    if ( !IS_OUTSIDE(ch) )
    {
	send_to_char( "No puedes ver el cielo desde aqui.\n\r", ch );
	return;
    }

    set_char_color( AT_BLUE, ch );
    ch_printf( ch, "El dia esta %s y %s.\n\r",
	sky_look[weather_info.sky],
	weather_info.change >= 0
	? "una calida brisa sopla desde el sur"
	: "un frio viento soplca desde el norte"
	);
    return;
}
*/

/*
 * Produce a description of the weather based on area weather using
 * the following sentence format:
 *		<combo-phrase> and <single-phrase>.
 * Where the combo-phrase describes either the precipitation and
 * temperature or the wind and temperature. The single-phrase
 * describes either the wind or precipitation depending upon the
 * combo-phrase.
 * Last Modified: July 31, 1997
 * Fireblade - Under Construction
 */
void do_weather(CHAR_DATA *ch, char *argument)
{
        CMDTYPE *comando;
	char *combo, *single;
	char buf[MAX_INPUT_LENGTH];
	int temp, precip, wind;

        if ( !IS_OUTSIDE(ch) )
	{
	    ch_printf(ch, "No puedes ver el cielo desde aqui.\n\r");
	    return;
	}

	temp = (ch->in_room->area->weather->temp + 3*weath_unit - 1)/
		weath_unit;
	precip = (ch->in_room->area->weather->precip + 3*weath_unit - 1)/
		weath_unit;
	wind = (ch->in_room->area->weather->wind + 3*weath_unit - 1)/
		weath_unit;

	if ( precip >= 3 )
	{
	    combo = preciptemp_msg[precip][temp];
	    single = wind_msg[wind];
	}
	else
	{
	    combo = windtemp_msg[wind][temp];
	    single = precip_msg[precip];
	}

	sprintf(buf, "%s y %s.\n\r", combo, single);

	set_char_color(AT_BLUE, ch);

	ch_printf(ch, buf);
}

/*
 * Moved into a separate function so it can be used for other things
 * ie: online help editing				-Thoric
 */
HELP_DATA *get_help( CHAR_DATA *ch, char *argument )
{
    char argall[MAX_INPUT_LENGTH];
    char argone[MAX_INPUT_LENGTH];
    char argnew[MAX_INPUT_LENGTH];
    HELP_DATA *pHelp;
    int lev;

    if ( argument[0] == '\0' )
	argument = "summary";

    if ( isdigit(argument[0]) )
    {
	lev = number_argument( argument, argnew );
	argument = argnew;
    }
    else
	lev = -2;
    /*
     * Tricky argument handling so 'help a b' doesn't match a.
     */
    argall[0] = '\0';
    while ( argument[0] != '\0' )
    {
	argument = one_argument( argument, argone );
	if ( argall[0] != '\0' )
	    strcat( argall, " " );
	strcat( argall, argone );
    }

    for ( pHelp = first_help; pHelp; pHelp = pHelp->next )
    {
	if ( pHelp->level > get_trust( ch ) )
	    continue;
	if ( lev != -2 && pHelp->level != lev )
	    continue;

	if ( is_name( argall, pHelp->keyword ) )
	    return pHelp;
    }

    return NULL;
}

/*
 * LAWS command
 */
void do_laws( CHAR_DATA *ch, char *argument )
{
    char buf[1024];

    if ( argument == NULL)
	do_help( ch, "laws" );
    else
    {
	sprintf( buf, "law %s", argument );
	do_help( ch, buf );
    }
}

/*
 * Now this is cleaner
 */
void do_help( CHAR_DATA *ch, char *argument )
{
    HELP_DATA *pHelp;

    if ( (pHelp = get_help( ch, argument )) == NULL )
    {
	send_to_char( "No hay ayuda sobre esa palabra.\n\r", ch );
	return;
    }

    /* Make newbies do a help start. --Shaddai */
    if ( !IS_NPC(ch) && !str_cmp( argument, "start" ) )
	SET_BIT(ch->pcdata->flags, PCFLAG_HELPSTART);

    if ( pHelp->level >= 0 && str_cmp( argument, "imotd" ) )
    {
	send_to_pager( pHelp->keyword, ch );
	send_to_pager( "\n\r", ch );
    }

    /*
     * Strip leading '.' to allow initial blanks.
     */
    if ( pHelp->text[0] == '.' )
	send_to_pager_color( pHelp->text+1, ch );
    else
	send_to_pager_color( pHelp->text  , ch );
    return;
}

void do_news( CHAR_DATA *ch, char *argument )
{
    set_pager_color( AT_NOTE, ch );
    do_help( ch, "news" );
}

extern char * help_greeting;	/* so we can edit the greeting online */

/*
 * Help editor							-Thoric
 */
void do_hedit( CHAR_DATA *ch, char *argument )
{
    HELP_DATA *pHelp;

    if ( !ch->desc )
    {
	send_to_char( "No tienes descriptor.\n\r", ch );
	return;
    }

    switch( ch->substate )
    {
	default:
	  break;
	case SUB_HELP_EDIT:
	  if ( (pHelp = ch->dest_buf) == NULL )
	  {
		bug( "hedit: sub_help_edit: NULL ch->dest_buf", 0 );
		stop_editing( ch );
		return;
	  }
	  if ( help_greeting == pHelp->text )
		help_greeting = NULL;
	  STRFREE( pHelp->text );
	  pHelp->text = copy_buffer( ch );
	  if ( !help_greeting )
		help_greeting = pHelp->text;
	  stop_editing( ch );
	  return;
    }
    if ( (pHelp = get_help(ch, argument)) == NULL )     /* new help */
    {
        HELP_DATA *tHelp;
        char argnew[MAX_INPUT_LENGTH];
        int lev;
        bool new_help = TRUE;

        for ( tHelp=first_help; tHelp; tHelp = tHelp->next )
           if ( !str_cmp( argument, tHelp->keyword) )
           {
                pHelp = tHelp;
                new_help = FALSE;
                break;
           }
        if ( new_help ) {
        if ( isdigit(argument[0]) )
        {
            lev = number_argument( argument, argnew );
            argument = argnew;
        }
        else
            lev = get_trust(ch);
        CREATE( pHelp, HELP_DATA, 1 );
        pHelp->keyword = STRALLOC( strupper(argument) );
        pHelp->text    = STRALLOC( "" );
        pHelp->level   = lev;
        add_help( pHelp );
        }
    }

    ch->substate = SUB_HELP_EDIT;
    ch->dest_buf = pHelp;
    start_editing( ch, pHelp->text );
}

/*
 * Stupid leading space muncher fix				-Thoric
 */
char *help_fix( char *text )
{
    char *fixed;

    if ( !text )
	return "";
    fixed = strip_cr(text);
    if ( fixed[0] == ' ' )
	fixed[0] = '.';
    return fixed;
}

void do_hset( CHAR_DATA *ch, char *argument )
{
    HELP_DATA *pHelp;
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];

    smash_tilde( argument );
    argument = one_argument( argument, arg1 );
    if ( arg1[0] == '\0' )
    {
	send_to_char( "Sintaxisx: hset <field> [value] [help page]\n\r",	ch );
	send_to_char( "\n\r",						ch );
	send_to_char( "El Field (campo) tiene que ser uno de estos:\n\r",			ch );
	send_to_char( "  level keyword remove save\n\r",		ch );
	return;
    }

    if ( !str_cmp( arg1, "save" ) )
    {
	FILE *fpout;

	log_string_plus( "Salvando help.are...", LOG_NORMAL, LEVEL_GREATER );

	rename( "help.are", "help.are.bak" );
	fclose( fpReserve );
	if ( ( fpout = fopen( "help.are", "w" ) ) == NULL )
	{
	   bug( "hset save: fopen", 0 );
	   perror( "help.are" );
	   fpReserve = fopen( NULL_FILE, "r" );
	   return;
	}

	fprintf( fpout, "#HELPS\n\n" );
	for ( pHelp = first_help; pHelp; pHelp = pHelp->next )
	    fprintf( fpout, "%d %s~\n%s~\n\n",
		pHelp->level, pHelp->keyword, help_fix(pHelp->text) );

	fprintf( fpout, "0 $~\n\n\n#$\n" );
	fclose( fpout );
	fpReserve = fopen( NULL_FILE, "r" );
	send_to_char( "Salvado.\n\r", ch );
	return;
    }
    if ( str_cmp( arg1, "remove" ) )
	argument = one_argument( argument, arg2 );

    if ( (pHelp = get_help(ch, argument)) == NULL )
    {
	send_to_char( "No se puede encontrar ayuda sobre eso.\n\r", ch );
	return;
    }
    if ( !str_cmp( arg1, "remove" ) )
    {
	UNLINK( pHelp, first_help, last_help, next, prev );
	STRFREE( pHelp->text );
	STRFREE( pHelp->keyword );
	DISPOSE( pHelp );
	send_to_char( "borrado.\n\r", ch );
	return;
    }
    if ( !str_cmp( arg1, "level" ) )
    {
	pHelp->level = atoi( arg2 );
	send_to_char( "Hecho.\n\r", ch );
	return;
    }
    if ( !str_cmp( arg1, "keyword" ) )
    {
	STRFREE( pHelp->keyword );
	pHelp->keyword = STRALLOC( strupper(arg2) );
	send_to_char( "Hecho.\n\r", ch );
	return;
    }

    do_hset( ch, "" );
}

void do_hl( CHAR_DATA *ch, char *argument )
{
    send_to_char( "Si quieres usar el HLIST, escribelo entero.\n\r", ch );
    return;
}

/*
 * Show help topics in a level range				-Thoric
 * Idea suggested by Gorog
 * prefix keyword indexing added by Fireblade
 */
void do_hlist( CHAR_DATA *ch, char *argument )
{
    int min, max, minlimit, maxlimit, cnt;
    char arg[MAX_INPUT_LENGTH];
    HELP_DATA *help;
    bool minfound, maxfound;
    char *idx;

    maxlimit = get_trust(ch);
    minlimit = maxlimit >= LEVEL_GREATER ? -1 : 0;

    min = minlimit;
    max  = maxlimit;

    idx = NULL;
    minfound = FALSE;
    maxfound = FALSE;

    for ( argument = one_argument(argument, arg); arg[0] != '\0';
	  argument = one_argument(argument, arg))
    {
	if( !isdigit(arg[0]) )
	{
 	    if ( idx )
	    {
		set_char_color(AT_GREEN, ch);
		ch_printf(ch, "Debes usar una sola palabra clave (keyword) como indice de la lista.\n\r");
		return;
	    }
	    idx = STRALLOC(arg);
    	}
	else
	{
	    if ( !minfound )
	    {
		min = URANGE(minlimit, atoi(arg), maxlimit);
		minfound = TRUE;
	    }
	    else
	    if ( !maxfound )
	    {
		max = URANGE(minlimit, atoi(arg), maxlimit);
		maxfound = TRUE;
	    }
	    else
	    {
		set_char_color(AT_GREEN, ch);
		ch_printf(ch, "Debes usar solo 2 limites de nivel.\n\r");
		return;
	    }
	}
    }

    if ( min > max )
    {
	int temp = min;

	min = max;
	max = temp;
    }

    set_pager_color( AT_GREEN, ch );
    pager_printf( ch, "Ayuda en el rango de niveles de %d a %d:\n\r\n\r", min, max );
    for ( cnt = 0, help = first_help; help; help = help->next )
	if ( help->level >= min && help->level <= max
	&&  (!idx || nifty_is_name_prefix(idx, help->keyword)) )
	{
	    pager_printf( ch, "  %3d %s\n\r", help->level, help->keyword );
	    ++cnt;
	}
    if ( cnt )
	pager_printf( ch, "\n\r%d paginas encontradas.\n\r", cnt );
    else
	send_to_char( "No encontradas.\n\r", ch );

    if ( idx )
    	STRFREE(idx);

    return;
}


/*
 * New do_who with WHO REQUEST, clan, race and homepage support.  -Thoric
 *
 * Latest version of do_who eliminates redundant code by using linked lists.
 * Shows imms separately, indicates guest and retired immortals.
 * Narn, Oct/96
 *
 * Who group by Altrag, Feb 28/97
 */
struct whogr_s
{
  struct whogr_s *next;
  struct whogr_s *follower;
  struct whogr_s *l_follow;
  DESCRIPTOR_DATA *d;
  int indent;
} *first_whogr, *last_whogr;

struct whogr_s *find_whogr(DESCRIPTOR_DATA *d, struct whogr_s *first)
{
  struct whogr_s *whogr, *whogr_t;

  for (whogr = first; whogr; whogr = whogr->next)
    if (whogr->d == d)
      return whogr;
    else if (whogr->follower && (whogr_t = find_whogr(d, whogr->follower)))
      return whogr_t;
  return NULL;
}

void indent_whogr(CHAR_DATA *looker, struct whogr_s *whogr, int ilev)
{
  for ( ; whogr; whogr = whogr->next )
  {
    if (whogr->follower)
    {
      int nlev = ilev;
      CHAR_DATA *wch =
          (whogr->d->original ? whogr->d->original : whogr->d->character);

      if (can_see(looker, wch) && !IS_IMMORTAL(wch))
        nlev += 3;
      indent_whogr(looker, whogr->follower, nlev);
    }
    whogr->indent = ilev;
  }
}

/* This a great big mess to backwards-structure the ->leader character
   fields */
void create_whogr(CHAR_DATA *looker)
{
  DESCRIPTOR_DATA *d;
  CHAR_DATA *wch;
  struct whogr_s *whogr, *whogr_t;
  int dc = 0, wc = 0;

  while ((whogr = first_whogr) != NULL)
  {
    first_whogr = whogr->next;
    DISPOSE(whogr);
  }
  first_whogr = last_whogr = NULL;
  /* Link in the ones without leaders first */
  for (d = last_descriptor; d; d = d->prev)
  {
    if (d->connected != CON_PLAYING && d->connected != CON_EDITING)
      continue;
    ++dc;
    wch = (d->original ? d->original : d->character);
    if (!wch->leader || wch->leader == wch || !wch->leader->desc ||
         IS_NPC(wch->leader) || IS_IMMORTAL(wch) || IS_IMMORTAL(wch->leader))
    {
      CREATE(whogr, struct whogr_s, 1);
      if (!last_whogr)
        first_whogr = last_whogr = whogr;
      else
      {
        last_whogr->next = whogr;
        last_whogr = whogr;
      }
      whogr->next = NULL;
      whogr->follower = whogr->l_follow = NULL;
      whogr->d = d;
      whogr->indent = 0;
      ++wc;
    }
  }
  /* Now for those who have leaders.. */
  while (wc < dc)
    for (d = last_descriptor; d; d = d->prev)
    {
      if (d->connected != CON_PLAYING && d->connected != CON_EDITING)
        continue;
      if (find_whogr(d, first_whogr))
        continue;
      wch = (d->original ? d->original : d->character);
      if (wch->leader && wch->leader != wch && wch->leader->desc &&
         !IS_NPC(wch->leader) && !IS_IMMORTAL(wch) &&
         !IS_IMMORTAL(wch->leader) &&
         (whogr_t = find_whogr(wch->leader->desc, first_whogr)))
      {
        CREATE(whogr, struct whogr_s, 1);
        if (!whogr_t->l_follow)
          whogr_t->follower = whogr_t->l_follow = whogr;
        else
        {
          whogr_t->l_follow->next = whogr;
          whogr_t->l_follow = whogr;
        }
        whogr->next = NULL;
        whogr->follower = whogr->l_follow = NULL;
        whogr->d = d;
        whogr->indent = 0;
        ++wc;
      }
    }
  /* Set up indentation levels */
  indent_whogr(looker, first_whogr, 0);

  /* And now to linear link them.. */
  for (whogr_t = NULL, whogr = first_whogr; whogr; )
    if (whogr->l_follow)
    {
      whogr->l_follow->next = whogr;
      whogr->l_follow = NULL;
      if (whogr_t)
        whogr_t->next = whogr = whogr->follower;
      else
        first_whogr = whogr = whogr->follower;
    }
    else
    {
      whogr_t = whogr;
      whogr = whogr->next;
    }
}

extern int total_clases;

void do_who( CHAR_DATA *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char clan_name[MAX_INPUT_LENGTH];
    char invis_str[MAX_INPUT_LENGTH];
    char pktotal[MAX_INPUT_LENGTH];
    char char_name[MAX_INPUT_LENGTH];
    char class_text[MAX_INPUT_LENGTH];
    struct whogr_s *whogr, *whogr_p;
    DESCRIPTOR_DATA *d;
    int iClass, iRace;
    int i;
    int iLevelLower;
    int iLevelUpper;
    int nNumber;
    int nMatch;
    int cnt; /* Contador estandard */
    int col; /* Contador de Columnas estandard */
    bool rgfClass[MAX_CLASS];
    bool rgfRace[MAX_RACE];
    bool fClassRestrict;
    bool fRaceRestrict;
    bool fImmortalOnly;
    bool fPkill;
    bool fClanMatch; /* SB who clan */
    bool hecho; /* Para los for del quien */
    bool hecho1; /* Lo mismo*/
    CLAN_DATA *pClan = NULL;
	FAMILIA_DATOS *fam = NULL;
    FILE *whoout = NULL;
    int jugadores = 0;
    int inmortal = 0;
    int heroes = 0;
    int novatos = 0;
    char *display_clases = "&c%-3.3s[&w%-2.2d&c]  ";
    char *display_clases1 = " &c%-3.3s[&w%-2.2d&c]\n\r";
    char *display_heroes = "&cHeroes      [&w%-2.2d&c]  ";
    char *display_mortales = "&wMortales    &c [&w%-2.2d&c] \n\r";
    char *display_gentuza = "&BNovatos    &c [&w%-2.2d&c]  ";
    char *display_inmortales = "&rInmortales  &c[&w%-2.2d&c]  ";
    WHO_DATA *cur_who = NULL;
    WHO_DATA *next_who = NULL;
    WHO_DATA *list = NULL;
    WHO_DATA *aux = NULL;

    iLevelLower    = 0;
    iLevelUpper    = MAX_LEVEL;
    fClassRestrict = FALSE;
    fRaceRestrict  = FALSE;
    fImmortalOnly  = FALSE;
    fPkill         = FALSE;
    fClanMatch	   = FALSE; /* SB who clan (order), who guild, who council */
    for ( iClass = 0; iClass < MAX_CLASS; iClass++ )
	rgfClass[iClass] = FALSE;
    for ( iRace = 0; iRace < MAX_RACE; iRace++ )
	rgfRace[iRace] = FALSE;

                nNumber = 0;
    for ( ;; )
    {
	char arg[MAX_STRING_LENGTH];

	argument = one_argument( argument, arg );
	if ( arg[0] == '\0' )
	    break;

	if ( is_number( arg ) )
	{
	    switch ( ++nNumber )
	    {
	    case 1: iLevelLower = atoi( arg ); break;
	    case 2: iLevelUpper = atoi( arg ); break;
	    default:
		send_to_char( "Solo son permitidos dos niveles.\n\r", ch );
		return;
	    }
	}
	else
	{
	    if ( strlen(arg) < 2 )
	    {
		send_to_char( "Los argumentos deben ser mas largos que eso.\n\r", ch );
		return;
	    }
                if ( !str_cmp( arg, "pk" ) )
              fPkill = TRUE;
            else
	    if ( !str_cmp( arg, "imm" ) || !str_cmp( arg, "dios" ) )
		fImmortalOnly = TRUE;
            else		 /* SB who clan (order), guild, council */
             if  ( ( pClan = get_clan (arg) ) )
	   	fClanMatch = TRUE;
	    else
	    {
		for ( iClass = 0; iClass < MAX_CLASS; iClass++ )
		{
		    if ( !str_cmp( arg, class_table[iClass]->who_name ) )
		    {
			rgfClass[iClass] = TRUE;
			break;
		    }
		}
		if ( iClass != MAX_CLASS )
		  fClassRestrict = TRUE;

		for ( iRace = 0; iRace < MAX_RACE; iRace++ )
		{
		    if ( !str_cmp( arg, race_table[iRace]->race_name ) )
		    {
			rgfRace[iRace] = TRUE;
			break;
		    }
		}
		if ( iRace != MAX_RACE )
		  fRaceRestrict = TRUE;

		if ( iClass == MAX_CLASS && iRace == MAX_RACE
 		 && fClanMatch == FALSE )
		{
		 send_to_char( "Eso no es una clase, raza o clan.\n\r", ch );
		 return;
		}
	    }
	}
    }

    /*
     * Now find matching chars.
     */
    nMatch = 0;
    buf[0] = '\0';
    if ( ch )
	set_pager_color( AT_RED, ch );
    else
    {
	  whoout = fopen( WHO_FILE, "w" );
	if ( !whoout )
	{
	  bug( "do_who: cannot open who file!" );
	  return;
	}
    }

         whogr = NULL;
    d = last_descriptor;
    whogr_p = NULL;
    for ( ; d; whogr_p = whogr, whogr = NULL, d = d->prev )
    {
	CHAR_DATA *wch;
	char const *class;
	char const *nivel_pk;

	if ( (d->connected != CON_PLAYING && d->connected != CON_EDITING)
	||   !can_see( ch, d->character ) || d->original)
	    continue;

	wch = d->original ? d->original : d->character;
	if ( wch->level < iLevelLower
	||   wch->level > iLevelUpper
	|| ( fPkill && !CAN_PKILL( wch ) )
	|| ( fImmortalOnly  && wch->level < LEVEL_IMMORTAL )
	|| ( fClassRestrict && !rgfClass[wch->class] )
	|| ( fRaceRestrict && !rgfRace[wch->race] )
	|| ( fClanMatch && ( pClan != wch->pcdata->clan )) ) /* SB */
	    continue;

	nMatch++;

	strcpy( char_name, wch->name );

	/* Nivel PK */

                /* Si es Vampiro */
                if ( IS_VAMPIRE(wch) )
	{
		switch ( wch->generacion  )
		{
		case 13: nivel_pk = "&yNeon";	break;
		case 12: nivel_pk = "&yDoce";	break;
		case 11: nivel_pk = "&OOnce";	break;
		case 10: nivel_pk = "&ODezi";	break;
		case 9: nivel_pk = "&ONove";	break;
                                     case 8: nivel_pk = "&cOcta";       break;
                                     case 7: nivel_pk = "&rSept";       break;
                                     case 6: nivel_pk = "&rSext";       break;
                                     case 5: nivel_pk = "&rQuin";       break;
                                     case 4: nivel_pk = "&RMatu";       break;
                                     case 3: nivel_pk = "&RAnte";       break;
                                     case 2: nivel_pk = "&RSegu";       break;
                                     case 1: nivel_pk = "&BCaIn";       break;
		default: nivel_pk = "    ";	break;
		}
	}
	else
		nivel_pk = "    ";


                   /* Si no es Vampiro */
                   if (!IS_VAMPIRE(wch) )
                   {
		switch ( wch->generacion )
		{
		case 13: nivel_pk = "&yNova";	break;
		case 12: nivel_pk = "&yApre";	break;
		case 11: nivel_pk = "&OEstu";	break;
		case 10: nivel_pk = "&Oilum";	break;
		case 9: nivel_pk = "&OSabi";	break;
                                     case 8: nivel_pk = "&OMaes";       break;
                                     case 7: nivel_pk = "&rExpe";       break;
                                     case 6: nivel_pk = "&rInhu";       break;
                                     case 5: nivel_pk = "&rCele";       break;
                                     case 4: nivel_pk = "&RDest";       break;
                                     case 3: nivel_pk = "&RDivi";       break;
                                     case 2: nivel_pk = "&RLege";       break;
                                     case 1: nivel_pk = "&BHeRa";       break;
		default: nivel_pk = "    ";	break;
		}
                }

	/* class = Nivel+Clase+Raza */

        if( wch->level < wch->pcdata->max_level )
        sprintf( class_text, "&Y%3d &z", wch->level); /* Nivel */
        else
	sprintf( class_text, "&w%3d &z", wch->level); /* Nivel */
	strncat( class_text, class_table[wch->class]->who_name, 3 );/* Clase */
	strcat( class_text, " ");
	strncat( class_text, race_table[wch->race]->race_name, 4 ); /* Raza */
	class = class_text;
        class_table[wch->class]->njugadores++;
        if ((wch->level >= LEVEL_HERO ) && (wch->level <= LEVEL_SUPERAVATAR ))
        heroes++;
        if (IS_IMMORTAL(wch) )
        inmortal++;
        if (wch->level < 15)
        novatos++;
        if (wch->level > 15 && wch->level < LEVEL_HERO)
        jugadores++;

	switch ( wch->level )
	{
	default: break;
	case MAX_LEVEL -  0: class = "Implement ";	break;
	case MAX_LEVEL -  1: class = "Infinito  ";	break;
	case MAX_LEVEL -  2: class = "Eterno    ";	break;
	case MAX_LEVEL -  3: class = "Ancestro  ";	break;
	case MAX_LEVEL -  4: class = "Divino    ";	break;
	case MAX_LEVEL -  5: class = "Gran Dios ";	break;
	case MAX_LEVEL -  6: class = "Dios Mayor";	break;
	case MAX_LEVEL -  7: class = "Dios      ";	break;
	case MAX_LEVEL -  8: class = "Dios Menor";	break;
	case MAX_LEVEL -  9: class = "Inmortal  ";	break;
	case MAX_LEVEL - 10: class = "Semi Dios ";	break;
	case MAX_LEVEL - 11: class = "Vigilante ";	break;
	case MAX_LEVEL - 12: class = "Creador   ";	break;
	case MAX_LEVEL - 13: class = "Demonio   ";	break;
	case MAX_LEVEL - 14: class = "Angel     "; 	break;
        case MAX_LEVEL - 15: class = "Engendro  "; 	break;
        case MAX_LEVEL - 16: class = "240 Avatar"; 	break;
	case MAX_LEVEL - 17: class = "239 Heroe ";	break;
	}

	if ( wch->pcdata->clan
             &&  !str_cmp( wch->name, wch->pcdata->clan->leader )
             &&   wch->pcdata->clan->leadrank[0] != '\0' )
                {
                sprintf( class_text, "&z%2d &z", wch->level); /* Nivel */
                strncat( class_text, wch->pcdata->clan->leadrank, 10);       /* Esto es pa que ponga el nivel*/
                class = class_text;                                       /*   con el rango de su casa    */
                }                                                                   /*SaNgUi*/

        else if ( wch->pcdata->clan
	     &&  !str_cmp( wch->name, wch->pcdata->clan->number1 )
             &&   wch->pcdata->clan->onerank[0] != '\0' )
                {
                sprintf( class_text, "&z%2d &z", wch->level); /* Nivel */
                strncat( class_text, wch->pcdata->clan->onerank, 10);
                class = class_text;
                }
	else if ( wch->pcdata->clan
             &&  !str_cmp( wch->name, wch->pcdata->clan->number2 )
             &&   wch->pcdata->clan->tworank[0] != '\0' )
                {
                sprintf( class_text, "&z%2d &z", wch->level); /* Nivel */
                strncat( class_text, wch->pcdata->clan->tworank, 10);
                class = class_text;
                }
  	else if ( wch->pcdata->rank && wch->pcdata->rank[0] != '\0' )
	  class = wch->pcdata->rank;

	if ( wch->familia )
	{
		  FAMILIA_DATOS *fam = wch->familia;
	      strcpy( clan_name, "");

	  /*if ( !str_cmp( wch->name, pclan->deity ) )
	      strcat( clan_name,"P " );
	  else
	  if ( !str_cmp( wch->name, pclan->leader ) )
	      strcat( clan_name,"L " );
	  else
	  if ( !str_cmp( wch->name, pclan->number1 ) )
	      strcat( clan_name,"H " );
	  else
	  if ( !str_cmp( wch->name, pclan->number2 ) )
	      strcat( clan_name,"C " );
	  else*/
	     strcat( clan_name,"  " );

	  strncat( clan_name, fam->alias, 12 );
	}
	else
	  clan_name[0] = '\0';

	if ( xIS_SET(wch->act, PLR_WIZINVIS) )
	  sprintf( invis_str, "&O(&wWiz&O)&w");
        else
	  invis_str[0] = '\0';
        if( xIS_SET(wch->act, PLR_PKTOTAL) )
          sprintf( pktotal, "&w(&rPkTotal&w)");
        else
	  pktotal[0] ='\0';
          if ( IS_IMMORTAL(wch))
          {
	  sprintf( buf, "&w[&c%-12s&w] [%4s&w] [&c%-14s&w] [%s%s%s%s&x&w] &x&w%s&w%s&R%s %s&x&w%s^x^x\n\r",
	  class,
	  nivel_pk,
	  clan_name,
	  xIS_SET(wch->act, PLR_ATTACKER) ? "&pA&x" : "-",
	  xIS_SET(wch->act, PLR_KILLER) ? "&pK&x" : "-",
	  xIS_SET(wch->act, PLR_THIEF)  ? "&pL&x"  : "-",
	  xIS_SET(wch->act, PLR_QUESTOR) ? "&pQ&x" : "-",
	  invis_str,
          pktotal,
	  xIS_SET(wch->act, PLR_AFK) ? "&w(&gEmpanao&w)&r" : "",
	  /*xIS_SET(wch->act, PLR_CONSEJO) ? "&c" : "&W",*/
	  char_name,
	  wch->pcdata->title );
          }

          if ( !IS_IMMORTAL(wch) )
          {
          if ( wch->level >= LEVEL_HERO )
          {
          sprintf( buf, "&w[&c%-12s&w] [%4s&w] [&c%-14s&w] [%s%s%s%s&x&w] &x&w%s&w%s&c%s %s&w%s^x^x\n\r",
	  class,
	  nivel_pk,
	  clan_name,
	  xIS_SET(wch->act, PLR_ATTACKER) ? "&pA&x" : "-",
	  xIS_SET(wch->act, PLR_KILLER) ? "&pK&x" : "-",
	  xIS_SET(wch->act, PLR_THIEF)  ? "&pL&x"  : "-",
	  xIS_SET(wch->act, PLR_QUESTOR) ? "&pQ&x" : "-",
	  invis_str,
          pktotal,
	  xIS_SET(wch->act, PLR_AFK) ? "&w(&gEmpanao&w)&c" : "",
	  /*xIS_SET(wch->act, PLR_CONSEJO) ? "&c" : "&W",*/
	  char_name,
	  wch->pcdata->title );
          }

          if ( wch->level <= (LEVEL_HERO -1) || !str_cmp(wch->name, "aRCHeR") )
          {
          sprintf( buf, "&w[&c%-12s&w] [%4s&w] [&c%-14s&w] [%s%s%s%s&w] &w%s&w%s&w%s %s&w%s^x^x\n\r",
	  class,
	  nivel_pk,
	  clan_name,
	  xIS_SET(wch->act, PLR_ATTACKER) ? "&pA&x" : "-",
	  xIS_SET(wch->act, PLR_KILLER) ? "&pK&x" : "-",
	  xIS_SET(wch->act, PLR_THIEF)  ? "&pL&x"  : "-",
	  xIS_SET(wch->act, PLR_QUESTOR) ? "&pQ&x" : "-",
	  invis_str,
          pktotal,
	  xIS_SET(wch->act, PLR_AFK) ? "&w(&gEmpanao&w)" : "",
	  /*xIS_SET(wch->act, PLR_CONSEJO) ? "&c" : "&W",*/
	  char_name,
	  wch->pcdata->title );
          }
          }

              CREATE( cur_who, WHO_DATA, 1 );
          cur_who->text = str_dup( buf );
          cur_who->orden = wch->level;
          cur_who->next = NULL;
          cur_who->prev = NULL;
/* (KAYSER) - MODIFICO EL QUIEN!!!*/
/*	i = MAX_LEVEL;
	for (i=MAX_LEVEL ; i>0 ; i--)
	{
		i = wch->level;
	        if (!get_char_world(wch, wch->level) == NULL)
			list = cur_who;

	}
*/
              if (list == NULL)
              	list = cur_who;
              else
              {
                aux = list;
                        while ( (cur_who->orden < aux->orden) && (aux->next != NULL) ) aux = aux->next;

                if ( (aux->next == NULL) && (cur_who->orden < aux->orden) )
                {
                  aux->next = cur_who;
                  cur_who->prev = aux;
                }
                else
                {
                 cur_who->next = aux;
                 if ( aux->prev != NULL )
                 {
                   cur_who->prev = aux->prev;
                   (aux->prev)->next = cur_who;
                 }
                 aux->prev = cur_who;
                }
                while (aux->prev != NULL) aux = aux->prev;
                list = aux;
              }
/**/

    }

send_to_pager_color("\n\n&W&w[&cNv Cls  Pert&w] [&cGene&w] [  &cFamilia     &w] [&cFlag&w] &w[&cNombre                           &w]",ch);
    send_to_pager_color("\n&z--------------------------------------------------------------------------------\n",ch);

    for ( cur_who = list; cur_who; cur_who = next_who )
    {
      if ( !ch )
        fprintf( whoout, cur_who->text );
      else
        send_to_pager_color( cur_who->text, ch );
        next_who = cur_who->next;
        DISPOSE( cur_who->text );
        DISPOSE( cur_who );
    }

    col = 0;
    send_to_pager_color("&z--------------------------------------------------------------------------------\n",ch);

    for ( cnt = 0; cnt < total_clases; cnt++)
    {
        switch( col )
        {
                case 0:
                pager_printf( ch, display_clases, class_table[cnt]->who_name, class_table[cnt]->njugadores);
                class_table[cnt]->njugadores = 0;
                hecho = TRUE;
                col= 1;
                break;

                case 1:
                pager_printf( ch, display_clases, class_table[cnt]->who_name, class_table[cnt]->njugadores);
                class_table[cnt]->njugadores = 0;
                hecho1 = TRUE;
                col= 2;
                break;

                case 2:
                pager_printf( ch, display_clases, class_table[cnt]->who_name, class_table[cnt]->njugadores);
                class_table[cnt]->njugadores = 0;
                hecho = TRUE;
                col= 3;
                break;

                case 3:
                pager_printf( ch, display_clases, class_table[cnt]->who_name, class_table[cnt]->njugadores);
                class_table[cnt]->njugadores = 0;
                hecho1 = TRUE;
                col= 4;
                break;

                case 4:
                pager_printf( ch, display_clases, class_table[cnt]->who_name, class_table[cnt]->njugadores);
                class_table[cnt]->njugadores = 0;
                hecho = TRUE;
                col= 5;
                break;

                case 5:
                pager_printf( ch, display_clases, class_table[cnt]->who_name, class_table[cnt]->njugadores);
                class_table[cnt]->njugadores = 0;
                hecho1 = TRUE;
                col= 6;
                break;

                case 6:
                pager_printf( ch, display_clases, class_table[cnt]->who_name, class_table[cnt]->njugadores);
                class_table[cnt]->njugadores = 0;
                hecho1 = TRUE;
                col= 7;
                break;


                case 7 :
                pager_printf( ch, display_clases1, class_table[cnt]->who_name, class_table[cnt]->njugadores);
                class_table[cnt]->njugadores = 0;
                col = 0;
                break;
          }
     }

    if ( !ch )
    {
	fprintf( whoout, "%d Jugador%s.\n\r", nMatch, nMatch == 1 ? "" : "es" );
	fclose( whoout );
	return;
    }

    send_to_pager_color("\n&z--------------------------------------------------------------------------------\n",ch);
    set_char_color( AT_CYAN, ch );
    col= 0;
     for (cnt = 0; cnt < 4; cnt++)
     {
        switch( col )
        {
                case 0:
                if (heroes == 0)
                {
                 col=1;
                 break;
                }
                pager_printf( ch, display_heroes, heroes);
                heroes = 0;
                hecho = TRUE;
                col= 1;
                break;

                case 1:
                if (inmortal == 0)
                {
                 col=2;
                 break;
                }
                pager_printf( ch, display_inmortales, inmortal);
                inmortal = 0;
                hecho1 = TRUE;
                col= 2;
                break;

                case 2:
                if (novatos == 0)
                {
                 col=3;
                 break;
                }
                pager_printf( ch, display_gentuza, novatos);
                novatos = 0;
                hecho = TRUE;
                col= 3;
                break;

                case 3:
                if (jugadores == 0)
                {
                 col=0;
                 break;
                }
                pager_printf( ch, display_mortales, jugadores);
                jugadores = 0;
                hecho = TRUE;
                col= 0;
                break;
        }

      }

    ch_printf( ch, "\n\r&w%d &cJugador%s.\n\r", nMatch, nMatch == 1 ? "" : "es" );

    return;
}



void do_compare( CHAR_DATA *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    OBJ_DATA *obj1;
    OBJ_DATA *obj2;
    int value1;
    int value2;
    char *msg;

    argument = one_argument( argument, arg1 );
    argument = one_argument( argument, arg2 );
    if ( arg1[0] == '\0' )
    {
	send_to_char( "Comparar que con que?\n\r", ch );
	return;
    }

    if ( ( obj1 = get_obj_carry( ch, arg1 ) ) == NULL )
    {
	send_to_char( "No tienes eso.\n\r", ch );
	return;
    }

    if ( arg2[0] == '\0' )
    {
	for ( obj2 = ch->first_carrying; obj2; obj2 = obj2->next_content )
	{
	    if ( obj2->wear_loc != WEAR_NONE
	    &&   can_see_obj( ch, obj2 )
	    &&   obj1->item_type == obj2->item_type
	    && ( obj1->wear_flags & obj2->wear_flags & ~ITEM_TAKE) != 0 )
		break;
	}

	if ( !obj2 )
	{
	    send_to_char( "No estas llevando nada para compararlo.\n\r", ch );
	    return;
	}
    }
    else
    {
	if ( ( obj2 = get_obj_carry( ch, arg2 ) ) == NULL )
	{
	    send_to_char( "No tienes eso.\n\r", ch );
	    return;
	}
    }

    msg		= NULL;
    value1	= 0;
    value2	= 0;

    if ( obj1 == obj2 )
    {
	msg = "Comparas $p consigo mismo. Parece igual...no?";
    }
    else if ( obj1->item_type != obj2->item_type )
    {
	msg = "No puedes comparar $p y $P.";
    }
    else
    {
	switch ( obj1->item_type )
	{
	default:
	    msg = "No puedes comparar $p y $P.";
	    break;

	case ITEM_ARMOR:
	    value1 = obj1->value[0];
	    value2 = obj2->value[0];
	    break;

	case ITEM_WEAPON:
	    value1 = obj1->value[1] + obj1->value[2];
	    value2 = obj2->value[1] + obj2->value[2];
	    break;
	}
    }

    if ( !msg )
    {
	     if ( value1 == value2 ) msg = "$p y $P parecen iguales.";
	else if ( value1  > value2 ) msg = "$p parece mejor que $P.";
	else                         msg = "$p parece peor que $P.";
    }

    act( AT_PLAIN, msg, ch, obj1, obj2, TO_CHAR );
    return;
}

void do_where( CHAR_DATA *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    CHAR_DATA *victim;
    DESCRIPTOR_DATA *d;
    bool found;

    one_argument( argument, arg );

    if ( arg[0]!='\0'
    &&   (victim=get_char_world(ch, arg)) && !IS_NPC(victim)
    &&   IS_SET(victim->pcdata->flags, PCFLAG_DND)
    &&   get_trust(ch) < get_trust(victim) )
    {
         act( AT_PLAIN, "No encuentras ningun $T.", ch, NULL, arg, TO_CHAR );
         return;
   }

    set_pager_color( AT_ORANGE, ch );
    if ( arg[0] == '\0' )
    {
        pager_printf( ch, "\n\rJugadores cerca tuyo en %s:\n\r", ch->in_room->area->name );
	found = FALSE;
	for ( d = first_descriptor; d; d = d->next )
	    if ( (d->connected == CON_PLAYING || d->connected == CON_EDITING )
	    && ( victim = d->character ) != NULL
	    &&   !IS_NPC(victim)
	    &&   victim->in_room
	    &&   victim->in_room->area == ch->in_room->area
	    &&   can_see( ch, victim )
            && ( get_trust(ch) >= get_trust(victim)
            ||   !IS_SET(victim->pcdata->flags, PCFLAG_DND) )
               ) /* if victim has the DND flag ch must outrank them */

	    {
		found = TRUE;
		pager_printf_color( ch, "&P%-13s  ", victim->name );
		if ( IS_IMMORTAL( victim ) && victim->level > 50 )
		  send_to_pager_color( "&P(&WInmortal&P)\t", ch );
		else if ( CAN_PKILL( victim ) && victim->pcdata->clan
    		&& victim->pcdata->clan->clan_type != CLAN_ORDER
		&& victim->pcdata->clan->clan_type != CLAN_GUILD )
		  pager_printf_color( ch, "%-18s\t", victim->pcdata->clan->badge );
		else if ( CAN_PKILL( victim ) )
		  send_to_pager_color( "(&wSin clan&P)\t", ch );
		else
		  send_to_pager( "\t\t\t", ch );
		pager_printf_color( ch, "&P%s\n\r", victim->in_room->name );
	    }
	if ( !found )
	    send_to_char( "Nadie\n\r", ch );
    }
    else
    {
	found = FALSE;
	for ( victim = first_char; victim; victim = victim->next )
	    if ( victim->in_room
	    &&   victim->in_room->area == ch->in_room->area
	    &&   !IS_AFFECTED(victim, AFF_HIDE)
	    &&   !IS_AFFECTED(victim, AFF_SNEAK)
            &&   !xIS_SET(victim->afectado_por, DAF_SILENCIO_MORTAL)
	    &&   can_see( ch, victim )
	    &&   is_name( arg, victim->name ) )
	    {
		found = TRUE;
		pager_printf( ch, "%-28s %s\n\r",
		    PERS(victim, ch), victim->in_room->name );
		break;
	    }
	if ( !found )
	    act( AT_PLAIN, "No encuentras ningun $T.", ch, NULL, arg, TO_CHAR );
    }

    return;
}




void do_consider( CHAR_DATA *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    CHAR_DATA *victim;
    char *msg;
    int diff;

    one_argument( argument, arg );

    if ( arg[0] == '\0' )
    {
	send_to_char( "Considerar matar a quien?\n\r", ch );
	return;
    }

    if ( ( victim = get_char_room( ch, arg ) ) == NULL )
    {
	send_to_char( "No esta aqui.\n\r", ch );
	return;
    }
    if ( victim == ch )
    {
	send_to_char( "Considerar luchar contigo?\n\r", ch );
	return;
    }

    if (( IS_NPC(victim) && xIS_SET(victim->act, ACT_AUTOMOB)))
    diff = victim->level;
    else
    diff = victim->level - ch->level;

    if ( diff <= -10 ) msg = "&RPodrias matar a $N desnudo y desarmado.";
    else if ( diff <=  -5 ) msg = "$N no se puede comparar contigo.";
    else if ( diff <=  -2 ) msg = "$N parece una presa facil.";
    else if ( diff <=   1 ) msg = "$N es tu combate ideal!";
    else if ( diff <=   4 ) msg = "$N te dice 'Hoy es tu dia de suerte'.";
    else if ( diff <=   9 ) msg = "$N se rie descaradamente de ti.";
    else                    msg = "La muerte agradecera tu sacrificio.";
    act( AT_CONSIDER, msg, ch, NULL, victim, TO_CHAR );

    if (( IS_NPC(victim) && xIS_SET(victim->act, ACT_AUTOMOB)))
    {
    if(ch->level <= 15)
           diff = (int) (((21 * ch->level) + (10 * victim->dificultad)) - ch->max_hit) / 6;
         if(ch->level <= 45)
           diff = (int) (((45 * ch->level) + (15 * victim->dificultad)) - ch->max_hit) / 6;
         if(ch->level <= 65)
           diff = (int) (((65 * ch->level) + (23 * victim->dificultad)) - ch->max_hit) / 6;
         if(ch->level <= (LEVEL_HERO -1))
           diff = (int) (((203 * ch->level) + (500 * victim->dificultad)) - ch->max_hit) / 6;
         if(ch->level >= LEVEL_HERO)
         {
           if(victim->dificultad > 1)
           diff = (int) ((ch->max_hit * (victim->dificultad/2)) - ch->max_hit) / 6;

           if(victim->dificultad <= 1)
           diff = (int) ((ch->max_hit * (victim->dificultad + number_range(40, 400))) - ch->max_hit) / 6;
         }
   }
   else
    diff = (int) (victim->max_hit - ch->max_hit) / 6;

	 if ( diff <= -200) msg = "Eres mucho mas fuerte que $N.";
    else if ( diff <= -150) msg = "Eres mucho mas fuerte que $N.";
    else if ( diff <= -100) msg = "$N no te dara ningun problema.";
    else if ( diff <=  -50) msg = "Crees que puedes con $N.";
    else if ( diff <=    0) msg = "$N parece tu igual.";
    else if ( diff <=   50) msg = "$N parece algo mas fuerte como tu.";
    else if ( diff <=  100) msg = "Necesitaras un poco de suerte...";
    else if ( diff <=  150) msg = "Necesitaras mucha suerte, y equipo!";
    else if ( diff <=  200) msg = "Porque no te cavas tu mismo la tumba antes?";
    else                    msg = "$N parece un PANZER!";
    act( AT_CONSIDER, msg, ch, NULL, victim, TO_CHAR );
    /*
     * Al considerar tambien influye el damroll y el AC SiGo
     * VampiroMud 2000 - 2001
     */

    diff = (int) (victim->damroll - ch->damroll);

    if ( diff <= -200) msg = "Podrias desmembrar a $N sin represalia alguna.";
    else if ( diff <= -150) msg = "Despues de ANIQUILAR a $N podrias probrar con su familia.";
    else if ( diff <= -100) msg = "$N deberia de inyectarse muchos esteroides para ganar contra ti.";
    else if ( diff <=  -50) msg = "Eres bastante mas potente que $N.";
    else if ( diff <=    0) msg = "$N es igual de potente que tu.";
    else if ( diff <=   50) msg = "$N es bastante mas potente que tu.";
    else if ( diff <=  100) msg = "Ese es mucho mas potente que tu...";
    else if ( diff <=  150) msg = "Yo de ti no le haria enfadar!";
    else if ( diff <=  200) msg = "Todo tu damroll es una miseria a lado del suyo.";
    else                    msg = "$N es DIOS!";
    act( AT_CONSIDER, msg, ch, NULL, victim, TO_CHAR );

    diff = (int) (victim->hitroll - ch->hitroll);

    if ( diff <= 200) msg = "$N suenya con tener tu misma habilidad.";
    else if ( diff <=  150) msg = "Su habilidad es una mierda comparada con la tuya.";
    else if ( diff <=  100) msg = "$N tiene un hitroll bastante pesima.";
    else if ( diff <=   50) msg = "Tienes mejor hitroll que $N.";
    else if ( diff <=    0) msg = "$N tiene tu misma habilidad.";
    else if ( diff <=   50) msg = "$N tiene mejor hitroll que tu.";
    else if ( diff <= -100) msg = "Tu habilidad no es mucho para $N...";
    else if ( diff <= -150) msg = "Toda tu habilidad es una mierda al lado de la de $N!";
    else if ( diff <= -200) msg = "Suenyas con tener algun dia una habilidad como la de $N.";
    else                    msg = "$N es casi INMORTAL!";
    act( AT_CONSIDER, msg, ch, NULL, victim, TO_CHAR );

    return;
}



/*
 * Place any skill types you don't want them to be able to practice
 * normally in this list.  Separate each with a space.
 * (Uses an is_name check). -- Altrag
 */
#define CANT_PRAC "Idioma"

void do_practice( CHAR_DATA *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    int sn;

    if ( IS_NPC(ch) )
	return;


    if ( ch->level < 2 )
    {
	send_to_char(
	"Debes ser nivel 2 para poder practicar.\n\r",
	    ch );
	return;
    }

    if ( argument[0] == '\0' )
    {
	int	col;
                   int              valor;
	sh_int	lasttype, cnt;

	col = cnt = 0;	lasttype = SKILL_SPELL;
	set_pager_color( AT_MAGIC, ch );
	for ( sn = 0; sn < top_sn; sn++ )
	{
	    if ( !skill_table[sn]->name )
		break;

       if ( strcmp(skill_table[sn]->name, "reserved") == 0
	    && ( IS_IMMORTAL(ch) ) )
	    {
		if ( col % 3 != 0 )
		    send_to_pager( "\n\r", ch );
	      set_pager_color( AT_MAGIC, ch );
	      send_to_pager_color(
" ----------------------------------[&CHechizos&B]----------------------------------\n\r", ch);
		col = 0;
	    }
	    if ( skill_table[sn]->type != lasttype )
	    {
		if ( !cnt )
		    send_to_pager( "                                   (ninguno)\n\r", ch );
		else
		if ( col % 3 != 0 )
		    send_to_pager( "\n\r", ch );
		set_pager_color( AT_MAGIC, ch );
		pager_printf_color( ch,
" ----------------------------------&C%ss&B----------------------------------\n\r",
			 skill_tname[skill_table[sn]->type]);
		col = cnt = 0;
                        }
	    lasttype = skill_table[sn]->type;

	    if (!IS_IMMORTAL(ch)
	    && ( skill_table[sn]->guild != CLASS_NONE
	       && ( !IS_GUILDED(ch)
		  || (ch->pcdata->clan->class != skill_table[sn]->guild) ) ) )
		continue;


                       if ( ch->level < skill_table[sn]->skill_level[ch->class]
	    || (!IS_IMMORTAL(ch) && skill_table[sn]->skill_level[ch->class] == 0) )
 	        continue;

                        if ( ch->pcdata->learned[sn] <= 0
	    &&   SPELL_FLAG(skill_table[sn], SF_SECRETSKILL) )
		continue;

	    ++cnt;
	    set_pager_color( AT_MAGIC, ch );
	    pager_printf( ch, "%20.20s", skill_table[sn]->name );
	    if ( ch->pcdata->learned[sn] > 0 )
		set_pager_color( AT_SCORE, ch );
	    pager_printf( ch, " %3d%% ", ch->pcdata->learned[sn] );
	    if ( ++col % 3 == 0 )
		send_to_pager( "\n\r", ch );
	}

	if ( col % 3 != 0 )
	    send_to_pager( "\n\r", ch );
        set_pager_color( AT_MAGIC, ch );
	pager_printf( ch, "Tienes %d practicas.\n\r",
	    ch->practice );
    }
    else
    {
	CHAR_DATA *mob;
	int adept;
	bool can_prac = TRUE;

	if ( !IS_AWAKE(ch) )
	{
	    send_to_char( "En tus suenyos, o que?\n\r", ch );
	    return;
	}

	for ( mob = ch->in_room->first_person; mob; mob = mob->next_in_room )
	    if ( IS_NPC(mob) && xIS_SET(mob->act, ACT_PRACTICE) )
		break;

	if ( !mob )
	{
	    send_to_char( "No puedes hacer eso aqui.\n\r", ch );
	    return;
	}

	if ( ch->practice <= 0 )
	{
	    act( AT_TELL, "$n te dice telepaticamente 'Debes tener mas practicas.'",
		mob, NULL, ch, TO_VICT );
	    return;
	}

	sn = skill_lookup( argument );

	if ( can_prac
          && ( ( sn == -1 )
       	       || ( !IS_NPC(ch)
	            &&  ch->level < skill_table[sn]->skill_level[ch->class]
/* OUT FOR THIS PORT -SHADDAI
                    &&  ch->level < skill_table[sn]->race_level[ch->race]
*/
                  )
             )
        )
	{
	    act( AT_TELL, "$n te dice telepaticamente 'No estas preparado para aprender eso aun...'",
		mob, NULL, ch, TO_VICT );
	    return;
	}

	if ( is_name( skill_tname[skill_table[sn]->type], CANT_PRAC ) )
	{
	    act( AT_TELL, "$n te dice telepaticamente 'No puedo ensenyarte eso.'",
		  mob, NULL, ch, TO_VICT );
	    return;
	}

	/*
	 * Skill requires a special teacher
	 */
	if ( skill_table[sn]->teachers && skill_table[sn]->teachers[0] != '\0' )
	{
	    sprintf( buf, "%d", mob->pIndexData->vnum );
	    if ( !is_name( buf, skill_table[sn]->teachers ) )
	    {
		act( AT_TELL, "$n te dice telepaticamente 'No se como ensenyarte eso.'",
		    mob, NULL, ch, TO_VICT );
		return;
	    }
	}

/*
 * Guild checks - right now, cant practice guild skills - done on
 * induct/outcast
 */
/*
	if ( !IS_NPC(ch) && !IS_GUILDED(ch)
	&&    skill_table[sn]->guild != CLASS_NONE)
	{
	    act( AT_TELL, "$n te dice telepaticamente 'Solo miembros del gremio pueden usarlo..'"
		mob, NULL, ch, TO_VICT );
	    return;
	}

	if ( !IS_NPC(ch) && skill_table[sn]->guild != CLASS_NONE
	     && ch->pcdata->clan->class != skill_table[sn]->guild )
	{
	    act( AT_TELL, "$n te dice telepaticamente 'Eso no puede ser usado por tu gremio.'"
		mob, NULL, ch, TO_VICT );
	    return;
	}
*/
	if ( !IS_NPC(ch) && skill_table[sn]->guild != CLASS_NONE)
	{
	    act( AT_TELL, "$n te dice telepaticamente 'Solo es para miembros del gremio...'",
		mob, NULL, ch, TO_VICT );
	    return;
	}

	/*
	 * Disabled for now
	if ( mob->level < skill_table[sn]->skill_level[ch->class]
	||   mob->level < skill_table[sn]->skill_level[mob->class] )
	{
	    act( AT_TELL, "$n te dice telepaticamente 'Debes buscar a otros que te ensenyen...'",
		mob, NULL, ch, TO_VICT );
	    return;
	}
	 */

	adept = class_table[ch->class]->skill_adept * 0.2;

	if ( ch->pcdata->learned[sn] >= adept )
	{
	    sprintf( buf, "$n te dice telepaticamente 'Te he ensenyado todo lo que podias aprender sobre %s.'",
		skill_table[sn]->name );
	    act( AT_TELL, buf, mob, NULL, ch, TO_VICT );
	    act( AT_TELL, "$n te dice telepaticamente 'Ahora debes practicarlo por ti mismo...'",
		mob, NULL, ch, TO_VICT );
	}
	else
	{
	    ch->practice--;
	    ch->pcdata->learned[sn] += int_app[get_curr_int(ch)].learn;
	    act( AT_ACTION, "Practicas $T.",
		    ch, NULL, skill_table[sn]->name, TO_CHAR );
	    act( AT_ACTION, "$n practica $T.",
		    ch, NULL, skill_table[sn]->name, TO_ROOM );
	    if ( ch->pcdata->learned[sn] >= adept )
	    {
		ch->pcdata->learned[sn] = adept;
		act( AT_TELL,
		 "$n te dice telepaticamente 'Ahora deberas practicarlo por ti mismo...'",
		 mob, NULL, ch, TO_VICT );
	    }
	}
    }
    return;
}

void do_asimilar( CHAR_DATA *ch, char *argument )
{
      char buf[MAX_STRING_LENGTH];
      CHAR_DATA *mob;
      int loop;
      int cuenta = 0;
      int i = 0;
      int total = 0;

    for ( mob = ch->in_room->first_person; mob; mob = mob->next_in_room )
    {
        if ( IS_NPC(mob) && xIS_SET(mob->act, ACT_TRAIN) )
            break;
    }

    if ( mob == NULL )
    {
        send_to_char( "No puedes hacerlo aqui.\n\r", ch );
        return;
    }

    if( argument[0] != '\0' )
      {
         send_to_char( "Este comando funciona sin argumentos.\n\r", ch );
         return;
      }


    if ( argument[0] == '\0' )
    {

    if (xIS_SET(ch->act, PLR_ABRAZADO)
    && !IS_VAMPIRE(ch) )
    {
        do_decision_mortales( ch );
        return;
     }

   if( IS_VAMPIRE(ch))
   {
    if (ch->pcdata->disci_adquirir == -1)
            {
                send_to_char("No estas adquiriendo ninguna disciplina.\n\r", ch);
                return;
            }

      for ( loop = 1; loop < MAX_DISCIPLINAS ; loop++ )
      {
      cuenta = 1;
        if ( !str_prefix(argument, disciplina[loop])
            && ch->pcdata->habilidades[loop] > -1 )
            {

	  if (IS_IMMORTAL( ch ))
	  	ch->pcdata->disci_puntos = 999;

          if (ch->pcdata->disci_puntos < 999 )
            {
                send_to_char("Aun no has terminado de adquirir los conocimientos requeridos.\n\r", ch);
                return;
            }

            if (( cuenta >= MAX_DISCIPLINAS -1
                  && loop != ch->pcdata->disci_adquirir))
            {
               send_to_char("No has adquirido el conocimiento para esa disciplina.\n\r", ch);
                return;
            }



         if((ch->pcdata->disci_puntos >= 999
             && loop == ch->pcdata->disci_adquirir) )
         {
           if( ch->pcdata->habilidades[loop] == 0)
           {
             for ( i = 1; i < MAX_DISCIPLINAS; i++)
             {
             if(ch->pcdata->habilidades[i] > 0)
             total++;
             }

               if(total != ( 11 + ch->pcdata->renacido ))
               {
               ch_printf( ch, "Adquieres el conocimiento de la disciplina %s!\n\r", disciplina[loop] );
               ch->pcdata->habilidades[loop]+=1;
               ch->pcdata->disci_adquirir = -1;
               ch->pcdata->disci_puntos = 0;
               total = 0;
               break;
               }
               else
               {
               ch_printf( ch, "Conoces ya un total de %d disciplinas que son tus maximas en este remort.\n\r", (10 + ch->pcdata->renacido));
               send_to_char( "Deberias de adquirir los niveles que te falten de las demas.\n\r", ch );
               ch->pcdata->disci_adquirir = -1;
               ch->pcdata->disci_puntos = 0;
               total = 0;
               break;
               }
           }
            send_to_char( "El nivel de tu disciplina ", ch );
            send_to_char( disciplina[loop], ch );
            send_to_char(  " aumenta!\n\r", ch );

            ch->pcdata->habilidades[loop]+=1;
            ch->pcdata->disci_adquirir = -1;
            ch->pcdata->disci_puntos = 0;
            break;
         }
       }
      }
   } /* fin de if (IS_VAMPIRE(ch)) */
   else
   {
   if(( ch->class == 1 || ch->class == 0))
   {
   if (ch->pcdata->disci_adquirir == -1)
            {
                send_to_char("No estas aprendiendo el conocimiento de ninguna esfera.\n\r", ch);
                return;
            }

      for ( loop = 1; loop < MAX_ESFERAS ; loop++ )
      {
      cuenta = 1;
        if ( !str_prefix(argument, esferas[loop])
            && ch->pcdata->habilidades[loop] > -1 )
            {

	  if (IS_IMMORTAL( ch ))
	  	ch->pcdata->disci_puntos = 999;

          if (ch->pcdata->disci_puntos < 999 )
            {
                send_to_char("Aun no has terminado de aprender los conocimientos requeridos.\n\r", ch);
                return;
            }

            if (( cuenta >= MAX_ESFERAS -1
                  && loop != ch->pcdata->disci_adquirir))
            {
               send_to_char("No has aprendido el conocimiento para esa esfera.\n\r", ch);
                return;
            }
         if((ch->pcdata->disci_puntos >= 999
             && loop == ch->pcdata->disci_adquirir) )
         {
         if( ch->pcdata->habilidades[loop] == 0)
           {
             for ( i = 1; i < MAX_ESFERAS; i++)
             {
             if(ch->pcdata->habilidades[i] > 0)
             total++;
             }

               if(total != ( 11 + ch->pcdata->renacido ))
               {
               int esfera = loop;
               if(esfera == 0)
               xSET_BIT(ch->esferas, ESF_CARDINAL);
               if(esfera == 1)
               xSET_BIT(ch->esferas, ESF_CORRESPONDENCIA);
               if(esfera == 2)
               xSET_BIT(ch->esferas, ESF_ENTROPIA);
               if(esfera == 3)
               xSET_BIT(ch->esferas, ESF_ESPIRITU);
               if(esfera == 4)
               xSET_BIT(ch->esferas, ESF_FUERZAS);
               if(esfera == 5)
               xSET_BIT(ch->esferas, ESF_MATERIA);
               if(esfera == 6)
               xSET_BIT(ch->esferas, ESF_MENTE);
               if(esfera == 7)
               xSET_BIT(ch->esferas, ESF_TIEMPO);
               if(esfera == 8)
               xSET_BIT(ch->esferas, ESF_VIDA);

               ch_printf( ch, "Adquieres el conocimiento de la esfera %s!\n\r", esferas[loop] );
               ch->pcdata->habilidades[loop]+=1;
               ch->pcdata->disci_adquirir = -1;
               ch->pcdata->disci_puntos = 0;
               total = 0;
               break;
               }
               else
               {
               ch_printf( ch, "Conoces ya un total de %d esferas que son tus maximas en este remort.\n\r", (10 + ch->pcdata->renacido));
               send_to_char( "Deberias de adquirir los niveles que te falten de las demas.\n\r", ch );
               ch->pcdata->disci_adquirir = -1;
               ch->pcdata->disci_puntos = 0;
               total = 0;
               break;
               }
           }
            send_to_char( "El nivel de tu esfera ", ch );
            send_to_char( esferas[loop], ch );
            send_to_char(  " aumenta!\n\r", ch );

            ch->pcdata->habilidades[loop]+=1;
            ch->pcdata->disci_adquirir = -1;
            ch->pcdata->disci_puntos = 0;
            break;
         }
       }
      }
   }
   }
   }
   return;
   }
/*****************************************************************\
* This is do_train ported over from Merc 2.1 to Smaug1.4          *
* by Joe Fabiano. If you have any questions about this snippet,   *
* email them to:  rinthos@yahoo.com.  Enjoy. :)  --Joe            *
*******************************************************************
*   Adaptado para VampiroMud por SiGo y SaNgUi 20xx               *
*   Modulo de ganancia de stats y genepks segun practicas         *
\*****************************************************************/

void do_train( CHAR_DATA *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    CHAR_DATA *mob;
    int proxima_generacion = 0;
    int hp_gain = 0;
    int mana_gain = 0;
    int genepk_gain = 0;
    int practicas_gain = 0;             /* Para avatares */
    int move_gain = 0; /* added for v1.2 */
    sh_int *pAbility;
    char *pOutput;
    int cost;    /*  the cost is in the form of practices (not gold).  -Joe */
    int genepkills;
    int exp_acumulada;
    int loop;

    if ( IS_NPC(ch) )
        return;

    /*
     * Check for trainer.
     */
        for ( mob = ch->in_room->first_person; mob; mob = mob->next_in_room )
    {
        if ( IS_NPC(mob) && xIS_SET(mob->act, ACT_TRAIN) )
            break;
    }

    if ( mob == NULL )
    {
        send_to_char( "No puedes hacerlo aqui.\n\r", ch );
        return;
    }

    if ( argument[0] == '\0' )
    {
        sprintf( buf, "Tienes %d sesiones de practicas.\n\r", ch->practice );
        argument = "foo";
    }

    cost = 5;   /* the number of practices it costs to train an attribute that is not your prime attribute.
                        * Hp and Mana costs for training aren't affected by this setting.  -Joe
                        */

    if ( !str_cmp( argument, "fue" ) )
    {
        if ( class_table[ch->class]->attr_prime == APPLY_STR )
            cost    = 3;     /* the cost to train strength if it is the prime attribute of your class -Joe*/
        pAbility    = &ch->perm_str;
        pOutput     = "fuerza";
    }

    else if ( !str_cmp( argument, "int" ) )
    {
        if ( class_table[ch->class]->attr_prime == APPLY_INT )
            cost    = 3;    /* the cost to train intelligence if it is the prime attribute of your class -Joe*/
        pAbility    = &ch->perm_int;
        pOutput     = "inteligencia";
    }

    else if ( !str_cmp( argument, "sab" ) )
    {
        if ( class_table[ch->class]->attr_prime == APPLY_WIS )
            cost    = 3;   /* the cost to train wisdom if it is the prime attribute of your class -Joe*/
        pAbility    = &ch->perm_wis;
        pOutput     = "sabiduria";
    }

    else if ( !str_cmp( argument, "des" ) )
    {
        if ( class_table[ch->class]->attr_prime == APPLY_DEX )
            cost    = 3;  /* the cost to train dexterity if it is the prime attribute of your class -Joe*/
        pAbility    = &ch->perm_dex;
        pOutput     = "destreza";
    }

    else if ( !str_cmp( argument, "con" ) )
    {
        if ( class_table[ch->class]->attr_prime == APPLY_CON )
            cost    = 3;  /* the cost to train constitution if it is the prime attribute of your class -Joe*/
        pAbility    = &ch->perm_con;
        pOutput     = "constitucion";
    }

    else if ( !str_cmp( argument, "car" ) )
    {
        if ( class_table[ch->class]->attr_prime == APPLY_CHA )
            cost    = 3;  /* the cost to train charisma if it is the prime attribute of your class -Joe */
        pAbility    = &ch->perm_cha;
        pOutput     = "carisma";
    }

    else if ( !str_cmp( argument, "sue" ) )
    {
        if ( class_table[ch->class]->attr_prime == APPLY_LCK )
            cost    = 3;  /* the cost to train luck if it is the prime attribute of your class -Joe*/
        pAbility    = &ch->perm_lck;
        pOutput     = "suerte";
    }

    else if ( !str_cmp( argument, "hp" ) )
      {
      	if ( ( ch->max_hit >= 15000 ) && ( !IS_IMMORTAL( ch ) ) )
        {
        	send_to_char("No Puedes entrenar tanta vida!\n\r",ch);

        	return;
        }
        pAbility = &ch->max_hit;
        pOutput = "vida";
    if ( ch->max_hit <= 3999 )
      cost = 3;
    if ( ch->max_hit >= 4000 )
      cost = 4;
    if ( ch->max_hit >= 5000 )
      cost = 5;
    if ( ch->max_hit >= 6000 )
      cost = 6;
    if ( ch->max_hit >= 7000 )
      cost = 7;
    if ( ch->max_hit >= 8000 )
      cost = 8;
    if ( ch->max_hit >= 9000 )
      cost = 9;
    if ( ch->max_hit >= 10000 )
      cost = 10;
    if ( ch->max_hit >= 15000 )
      cost = 15;
    if ( ch->max_hit >= 20000 )
      cost = 20;
    if ( ch->max_hit >= 25000 )
      cost = 30;
      /*  cost = 3; */   /* this is cost to train hp once -Joe*/
        hp_gain = 10; /* this is hp gained by training hp once -Joe*/
      }
/* new in v1.2 */
    else if ( !str_cmp( argument, "move" ) )
      {
       pAbility = &ch->max_move;
       pOutput = "movimiento";
    if ( ch->max_move <= 3999 )
      cost = 3;
    if ( ch->max_move >= 4000 )
      cost = 4;
    if ( ch->max_move >= 5000 )
      cost = 5;
    if ( ch->max_move >= 6000 )
      cost = 6;
    if ( ch->max_move >= 7000 )
      cost = 7;
    if ( ch->max_move >= 8000 )
      cost = 8;
    if ( ch->max_move >= 9000 )
      cost = 9;
    if ( ch->max_move >= 10000 )
      cost = 10;
    if ( ch->max_move >= 15000 )
      cost = 15;
    if ( ch->max_move >= 20000 )
      cost = 20;
    if ( ch->max_move >= 25000 )
      cost = 30;

    /*   cost = 3;  */
       move_gain = 10;
      }

    else if ( !str_cmp( argument, "mana"  ) )
      {
      if ( ( ch->max_mana >= 15000 ) && ( !IS_IMMORTAL( ch ) ) )
      	{
        	send_to_char("No Puedes entrenar tanto mana!\n\r",ch);
                return;
         }

        pAbility = &ch->max_mana;
        pOutput = "mana";
    if ( ch->max_mana <= 3999 )
      cost = 3;
    if ( ch->max_mana >= 4000 )
      cost = 4;
    if ( ch->max_mana >= 5000 )
      cost = 5;
    if ( ch->max_mana >= 6000 )
      cost = 6;
    if ( ch->max_mana >= 7000 )
      cost = 7;
    if ( ch->max_mana >= 8000 )
      cost = 8;
    if ( ch->max_mana >= 9000 )
      cost = 9;
    if ( ch->max_mana >= 10000 )
      cost = 10;
    if ( ch->max_mana >= 15000 )
      cost = 15;
    if ( ch->max_mana >= 20000 )
      cost = 20;
    if ( ch->max_mana >= 25000 )
      cost = 30;

     /*   cost =3;  */ /* this is the cost to train mana once -Joe*/
        mana_gain = 10;   /* this is the mana gained by training mana once -Joe*/
      }
     else if ( !str_cmp( argument, "practicas"  ) )
      {
        pAbility = ch->practice;
        pOutput = "practicas";
        cost = 1000;
        practicas_gain = 5;
       }


    else if ( !str_cmp( argument, "genepk" ) )
      {
        pAbility = &ch->pcdata->genepkills;
        pOutput = "genepk";
        cost = 200;
        genepk_gain = 1;
      }

    else
    {

/* added move here for v1.2 */
   strcpy( buf, "Puedes entrenar: genepk" );
        if ( ch->level >= LEVEL_AVATAR ) strcat( buf, " practicas" );
        if ( ch->max_hit  <= 32000 ) strcat( buf, " hp" );
        if ( ch->max_mana  <= 32000 ) strcat( buf, " mana" );
        if ( ch->max_move  <= 32000 ) strcat( buf, " move" );
        if ( ch->perm_str < 18 ) strcat( buf, " fue" );
        if ( ch->perm_int < 18 ) strcat( buf, " int" );
        if ( ch->perm_wis < 18 ) strcat( buf, " sab" );
        if ( ch->perm_dex < 18 ) strcat( buf, " des" );
        if ( ch->perm_con < 18 ) strcat( buf, " con" );
        if ( ch->perm_cha < 18 ) strcat( buf, " car" );
        if ( ch->perm_lck < 18 ) strcat( buf, " sue" );

            strcat( buf, ".\n\r" );
            send_to_char( buf, ch );


        return;
    }

    if ( !str_cmp( argument, "practicas" ) )
      {
       if ( ch->level < LEVEL_AVATAR )
        {
          send_to_char( "Debes ser Heroe para poder entrenar practicas.\n\r", ch );
          return;
        }
       if( ch->level >= LEVEL_AVATAR )
         {
       if ( cost > ch->exp_acumulada )
         {
           send_to_char( "No tienes suficiente experiencia.\n\r", ch );
           return;
         }

       pOutput = "practicas";

            ch->exp_acumulada    -= 1000;
            ch->practice                 += 5;
                                 act(AT_RED, "Tus $T se elevan!", ch, NULL, pOutput, TO_CHAR );
                                 act(AT_RED, "Las $T de $n se elevan!", ch, NULL, pOutput, TO_ROOM );
     return;
     }
       return;
        }

    if ( !str_cmp( argument, "genepk" ) )
      {

        if ( cost > ch->practice )
          {
            send_to_char( "No tienes suficientes practicas.\n\r", ch );
            return;
          }

             ch->practice        -= cost;
             *pAbility            += genepk_gain;
                                 act(AT_RED, "Tus $T se eleva!", ch, NULL, pOutput, TO_CHAR );
                                 act(AT_RED, "Los $T de $n se elevan!", ch, NULL, pOutput, TO_ROOM );

      switch ( ch->generacion )
     {
      case 13 : proxima_generacion =  10; break;
      case 12 : proxima_generacion =  20; break;
      case 11 : proxima_generacion =  30; break;
      case 10 : proxima_generacion =  40; break;
      case  9 : proxima_generacion =  50; break;
      case  8 : proxima_generacion =  65; break;
      case  7 : proxima_generacion =  80; break;
      case  6 : proxima_generacion =  95; break;
      case  5 : proxima_generacion = 105; break;
     }


      if ( ch->pcdata->genepkills >= proxima_generacion )
    {
      if ( ch->generacion == GENERACION_MATUSALEN || ch->generacion == GENERACION_ANTEDILUVIANO || ch->generacion == GENERACION_SEGUNDA || ch->generacion == GENERACION_CAIN )
      {
      /*
       * Si el personaje tiene generacion matusalen (4) o menos no ganara generacion
       * pero sus puntos de Pk seguiran aumentando. Ver progenie
       */
         send_to_char("Ya no puedes mejorar mas tu generacion pero acumulando puntos Pk podras\n\r", ch );
         send_to_char("abrazar a Mortales y crear tu progenie. Ayuda Progenie.\n\r", ch );

         return;
      }
      advance_generacion( ch );
     /* ch->pcdata->genepkills = ch->pcdata->genepkills++;*/ /* Se devuelve el valor 0 a las variables *//* SiGo */
      /*ch->pcdata->genepdeaths = 0;*/
      return;
    }

      return;
      }

    if ( !str_cmp( argument, "hp" ) )
      {
        if ( ch->max_hit >= 28000 )
        {
        send_to_char( "&RTen cuidado con lo que te vistas, si sobrepasas 32700 hp tu vida\n\r", ch );
        send_to_char( "se pondria en negativo y estarias muerto.\n\r", ch );
        }
        if ( ch->max_hit >= 31000 )
        {
         send_to_char( "Tio eres una maquina ya no se puede tener mas vida. :D\n\r", ch );
         return;
        }
        if ( cost > ch->practice )
          {
            send_to_char( "No tienes suficientes practicas.\n\r", ch );
            return;
          }

             ch->practice        -= cost;
             *pAbility           += hp_gain;
                                 act(AT_RED, "Tu $T se eleva!", ch, NULL, pOutput, TO_CHAR );
                                 act(AT_RED, "La $T de $n se eleva!", ch, NULL, pOutput, TO_ROOM );
                                 return;
      }
/* added this for v1.2 */
if ( !str_cmp( argument, "move" ) )
      {
        if ( ch->max_move >= 28000 )
        {
        send_to_char( "&RTen cuidado con lo que te vistas, si sobrepasas 32700 puntos de move\n\r", ch );
        send_to_char( "se pondria en negativo y estarias cansado.\n\r", ch );
        }
        if ( ch->max_move >= 31000 )
        {
         send_to_char( "Tio eres una maquina ya no se puede tener mas move. :D\n\r", ch );
         return;
        }

        if ( cost > ch->practice )
          {
            send_to_char( "No tienes suficientes practicas.\n\r", ch );
            return;
          }

             ch->practice        -= cost;
             *pAbility           += move_gain;
                                 act(AT_RED, "Tu $T incrementa!", ch, NULL, pOutput, TO_CHAR );
                                 act(AT_RED, "El $T de $n mejora!", ch, NULL, pOutput, TO_ROOM );
                                 return;
      }

if ( !str_cmp( argument, "mana" ) )
  {
        if ( ch->max_mana >= 28000 )
        {
        send_to_char( "&RTen cuidado con lo que te vistas, si sobrepasas 32700 puntos de mana\n\r", ch );
        send_to_char( "se pondria en negativo y nunca tendrias mana.\n\r", ch );
        }
        if ( ch->max_mana >= 31000 )
        {
         send_to_char( "Tio eres una maquina ya no se puede tener mas mana. :D\n\r", ch );
         return;
        }

        if ( cost > ch->practice )
          {
            send_to_char( "No tienes suficientes practicas.\n\r", ch );
            return;
          }

             ch->practice        -= cost;
                                 *pAbility           += mana_gain;
                                 act(AT_RED, "Tu $T incrementa!", ch, NULL, pOutput, TO_CHAR );
                                 act(AT_RED, "El $T de $n mejora!", ch, NULL, pOutput, TO_ROOM );
             return;
      }

    if ( *pAbility >= 20 )  /* 18 is the max you can train something to unless you change it here  -Joe */
   {
        act(AT_RED, "Tu $T esta ya al maximo nene.", ch, NULL, pOutput, TO_CHAR );
        return;
    }

    if ( cost > ch->practice )
    {
        send_to_char( "No tienes suficientes practicas.\n\r", ch );
        return;
    }

    ch->practice        -= cost;
    *pAbility           += 1;
         act(AT_RED, "Tu $T incrementa!", ch, NULL, pOutput, TO_CHAR );
         act(AT_RED, "La $T de $n mejora !", ch, NULL, pOutput, TO_ROOM );
         return;
}

void do_wimpy( CHAR_DATA *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    int wimpy;

    set_char_color( AT_YELLOW, ch );
    one_argument( argument, arg );
    if ( !str_cmp( arg, "max" ) )
    {
      if ( IS_PKILL( ch ) )
	wimpy = (int) ch->max_hit / 2.25;
      else
	wimpy = (int) ch->max_hit / 1.2;
    }
    else
    if ( arg[0] == '\0' )
      wimpy = (int) ch->max_hit / 5;
    else
      wimpy = atoi( arg );

    if ( wimpy < 0 ) {
	send_to_char( "No seas tan valiente.\n\r", ch );
	return;
    }
    if ( IS_PKILL( ch ) && wimpy > (int) ch->max_hit / 2.25 )
    {
	send_to_char( "No seas tan cobarde!\n\r", ch );
	return;
    }
    else if ( wimpy > (int) ch->max_hit / 1.2 )
    {
	send_to_char( "No seas tan cobarde!\n\r", ch );
	return;
    }
    ch->wimpy	= wimpy;
    ch_printf( ch, "Wimpy puesto a %d puntos de vida.\n\r", wimpy );
    return;
}



void do_password( CHAR_DATA *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    char log_buf[MAX_STRING_LENGTH];
    char *pArg;
    char *pwdnew;
    char *p;
    char cEnd;

    if ( IS_NPC(ch) )
	return;

    /*
     * Can't use one_argument here because it smashes case.
     * So we just steal all its code.  Bleagh.
     */
    pArg = arg1;
    while ( isspace(*argument) )
	argument++;

    cEnd = ' ';
    if ( *argument == '\'' || *argument == '"' )
	cEnd = *argument++;

    while ( *argument != '\0' )
    {
	if ( *argument == cEnd )
	{
	    argument++;
	    break;
	}
	*pArg++ = *argument++;
    }
    *pArg = '\0';

    pArg = arg2;
    while ( isspace(*argument) )
	argument++;

    cEnd = ' ';
    if ( *argument == '\'' || *argument == '"' )
	cEnd = *argument++;

    while ( *argument != '\0' )
    {
	if ( *argument == cEnd )
	{
	    argument++;
	    break;
	}
	*pArg++ = *argument++;
    }
    *pArg = '\0';

    if ( arg1[0] == '\0' || arg2[0] == '\0' )
    {
	send_to_char( "Sintaxis: password <viejo> <nuevo>.\n\r", ch );
	return;
    }


    if ( strcmp( crypt( arg1, ch->pcdata->pwd ), ch->pcdata->pwd ) )
    {
	WAIT_STATE( ch, 40 );
	send_to_char( "Password erroneo.\n\r", ch );
	return;
    }


/* This should stop all the mistyped password problems --Shaddai */
/*    if ( strcmp( arg1, arg2 ))
    {
	send_to_char("Los passwords no coinciden, intentalo de nuevo.\n\r", ch );
	return;
    }*/
    if ( strlen(arg2) < 5 )
    {
	send_to_char(
	    "El nuevo password debe tener al menos 5 caracteres.\n\r", ch );
	return;
    }

    /*
     * No tilde allowed because of player file format.
     */
    pwdnew = crypt( arg2, ch->name );
    for ( p = pwdnew; *p != '\0'; p++ )
    {
	if ( *p == '~' )
	{
	    send_to_char(
		"El nuevo password no es aceptable, intentalo de nuevo.\n\r", ch );
	    return;
	}
    }

    DISPOSE( ch->pcdata->pwd );
    ch->pcdata->pwd = str_dup( pwdnew );
    if ( IS_SET(sysdata.save_flags, SV_PASSCHG) )
	save_char_obj( ch );
    if ( ch->desc && ch->desc->host[0]  != '\0' )
       sprintf(log_buf, "%s cambiando password desde %s\n", ch->name,
       		ch->desc->host );
    else
       sprintf(log_buf, "%s esta cambiando su password sin descriptor!", ch->name);
    log_string( log_buf );
    send_to_char( "Ok.\n\r", ch );
    return;
}



void do_socials( CHAR_DATA *ch, char *argument )
{
    int iHash;
    int col = 0;
    SOCIALTYPE *social;

    set_pager_color( AT_PLAIN, ch );
    for ( iHash = 0; iHash < 27; iHash++ )
	for ( social = social_index[iHash]; social; social = social->next )
	{
	    pager_printf( ch, "%-12s", social->name );
	    if ( ++col % 6 == 0 )
		send_to_pager( "\n\r", ch );
	}

    if ( col % 6 != 0 )
	send_to_pager( "\n\r", ch );
    return;
}


void do_commands( CHAR_DATA *ch, char *argument )
{
    int col;
    bool found;
    int hash;
    CMDTYPE *command;

    col = 0;
    set_pager_color( AT_PLAIN, ch );
    if ( argument[0] == '\0' )
    {
	for ( hash = 0; hash < MAX_COMANDOS; hash++ )
	    for ( command = command_hash[hash]; command; command = command->next )
                                   if ( command->level <  LEVEL_HERO
		&&   command->level <= get_trust( ch )
		&&  (command->name[0] != 'm'
		||   command->name[1] != 'p') )
		{
		    pager_printf( ch, "%-12s", command->name );
		    if ( ++col % 6 == 0 )
			send_to_pager( "\n\r", ch );
		}
	if ( col % 6 != 0 )
	    send_to_pager( "\n\r", ch );
    }
    else
    {
	found = FALSE;
	for ( hash = 0; hash < MAX_COMANDOS; hash++ )
	    for ( command = command_hash[hash]; command; command = command->next )
		if ( command->level <  LEVEL_HERO
		&&   command->level <= get_trust( ch )
		&&  !str_prefix(argument, command->name)
		&&  (command->name[0] != 'm'
		||   command->name[1] != 'p') )
		{
		    pager_printf( ch, "%-12s", command->name );
		    found = TRUE;
		    if ( ++col % 6 == 0 )
			send_to_pager( "\n\r", ch );
		}

	if ( col % 6 != 0 )
	    send_to_pager( "\n\r", ch );
	if ( !found )
	    ch_printf( ch, "Comando no encontrado bajo %s.\n\r", argument);
    }
    return;
}

void do_channels( CHAR_DATA *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    one_argument( argument, arg );

    if ( IS_NPC( ch ) )
	return;

    if ( arg[0] == '\0' )
    {
        if ( !IS_NPC(ch) && xIS_SET(ch->act, PLR_SILENCE) )
        {
	    set_char_color( AT_GREEN, ch );
            send_to_char( "Estas silenciado!\n\r", ch );
            return;
        }

	/* Channels everyone sees regardless of affiliation --Blodkai */
        send_to_char_color( "\n\r &gCanales publicos (No abuses de su uso)&G:\n\r  ", ch );
	ch_printf_color( ch, "%s",   !IS_SET( ch->deaf, CHANNEL_RACETALK )?
						" &G+RACETALK" :
						" &g-racetalk" );
        ch_printf_color( ch, "%s",   !IS_SET( ch->deaf, CHANNEL_CHAT )    ?
				                " &G+CHARLA" 	          :
						" &g-charla" );
        if ( get_trust( ch ) > 2 && !NOT_AUTHED( ch ) )
          ch_printf_color( ch, "%s", !IS_SET( ch->deaf, CHANNEL_AUCTION ) ?
				                " &G+SUBASTA" 	          :
						" &g-subasta" );
	ch_printf_color( ch, "%s",   !IS_SET( ch->deaf, CHANNEL_TRAFFIC ) ?
						" &G+TRAFFIC"		  :
						" &g-traffic" );
        ch_printf_color( ch, "%s",   !IS_SET( ch->deaf, CHANNEL_QUEST )   ?
				                " &G+AVENTURA" 	          :
						" &g-aventura" );
        ch_printf_color( ch, "%s",   !IS_SET( ch->deaf, CHANNEL_WARTALK ) ?
				                " &G+WARTALK" 	          :
						" &g-wartalk" );
        if ( IS_HERO( ch ) )
          ch_printf_color( ch, "%s", !IS_SET( ch->deaf, CHANNEL_AVTALK )  ?
				                " &G+AVATAR"	          :
						" &g-avatar" );
        ch_printf_color( ch, "%s",   !IS_SET( ch->deaf, CHANNEL_MUSIC )   ?
				                " &G+MUSIC" 	          :
						" &g-music" );
        ch_printf_color( ch, "%s",   !IS_SET( ch->deaf, CHANNEL_ASK )     ?
					        " &G+PREGUNTAR"                 :
						" &g-preguntar" );
        ch_printf_color( ch, "%s",   !IS_SET( ch->deaf, CHANNEL_SHOUT )   ?
						" &G+GRITAR"	          :
						" &g-gritar" );
        ch_printf_color( ch, "%s",   !IS_SET( ch->deaf, CHANNEL_YELL )    ?
				                " &G+VOCEAR"	          :
						" &g-vocear" );

	/* For organization channels (orders, clans, guilds, councils) */
        send_to_char_color( "\n\r &gCanales Privados (Se penalizara su mal uso)&G:\n\r ", ch );
        ch_printf_color( ch, "%s",   !IS_SET( ch->deaf, CHANNEL_TELLS )   ?
                                                " &G+TELLS"               :
                                                " &g-tells" );
        ch_printf_color( ch, "%s", !IS_SET( ch->deaf, CHANNEL_WHISPER )   ?
						" &G+SUSURRAR"		  :
						" &g-susurrar" );
        if ( !IS_NPC( ch ) && ch->pcdata->clan )
        {
          if ( ch->pcdata->clan->clan_type == CLAN_ORDER )
	    send_to_char_color( !IS_SET( ch->deaf, CHANNEL_ORDER ) ?
		" &G+ORDEN"	:	" &g-orden", ch );

          else if ( ch->pcdata->clan->clan_type == CLAN_GUILD )
	    send_to_char_color( !IS_SET( ch->deaf, CHANNEL_GUILD ) ?
		" &G+GREMIO"	:	" &g-gremio", ch );
          else
	    send_to_char_color( !IS_SET( ch->deaf, CHANNEL_CLAN )  ?
		" &G+CLAN"	:	" &g-clan", ch );
        }
        if ( IS_IMMORTAL(ch) || ( ch->pcdata->council
	&&   !str_cmp( ch->pcdata->council->name, "Newbie Council" ) ) )
          ch_printf_color( ch, "%s",   !IS_SET( ch->deaf, CHANNEL_NEWBIE) ?
    				 	        " &G+NEWBIE"	     	  :
						" &g-newbie" );
        if ( !IS_NPC( ch ) && ch->pcdata->council )
          ch_printf_color( ch, "%s",   !IS_SET( ch->deaf, CHANNEL_COUNCIL)?
				                " &G+CONSEJO"	     	  :
						" &g-consejo" );

	/* Immortal channels */
        if ( IS_IMMORTAL( ch ) )
        {
            send_to_char_color( "\n\r &gCanales de Inmortal&G:\n\r  ", ch );
            send_to_char_color( !IS_SET( ch->deaf, CHANNEL_IMMTALK )    ?
		" &G+IMMTALK"	:	" &g-immtalk", ch );
/*          send_to_char_color( !IS_SET( ch->deaf, CHANNEL_PRAY )       ?
		" &G+REZAR"	:	" &g-rezar", ch ); */
            if ( get_trust( ch ) >= sysdata.muse_level )
              send_to_char_color( !IS_SET( ch->deaf, CHANNEL_HIGHGOD )  ?
		" &G+REFLEXIONAR"	:	" &g-reflexionar", ch );
            send_to_char_color( !IS_SET( ch->deaf, CHANNEL_MONITOR )    ?
		" &G+MONITOR"	:	" &g-monitor", ch );
	    send_to_char_color( !IS_SET( ch->deaf, CHANNEL_AUTH )	?
	       " &G+AUTH"	:	" &g-auth", ch );
        }
        if ( get_trust( ch ) >= sysdata.log_level )
        {
            send_to_char_color( !IS_SET( ch->deaf, CHANNEL_LOG ) 	?
		" &G+LOG"	:	" &g-log", ch);
            send_to_char_color( !IS_SET( ch->deaf, CHANNEL_BUILD)       ?
		" &G+BUILD"	:	" &g-build", ch );
            send_to_char_color( !IS_SET( ch->deaf, CHANNEL_COMM ) 	?
		" &G+COMM"	:	" &g-comm", ch );
            send_to_char_color( !IS_SET (ch->deaf, CHANNEL_WARN)
                        ? " &G+WARN" : " &g-warn", ch);
            if ( get_trust( ch ) >= sysdata.think_level )
              send_to_char_color( !IS_SET( ch->deaf, CHANNEL_HIGH ) 	?
		" &G+HIGH"	:	" &g-high", ch );
        }
        send_to_char( "\n\r", ch );
    }
    else
    {
	bool fClear;
	bool ClearAll;
	int bit;

        bit=0;
        ClearAll = FALSE;

	     if ( arg[0] == '+' ) fClear = TRUE;
	else if ( arg[0] == '-' ) fClear = FALSE;
	else
	{
	    send_to_char( "Canales -canal o +canal?\n\r", ch );
	    return;
	}

	     if ( !str_cmp( arg+1, "subasta"  ) ) bit = CHANNEL_AUCTION;
	else if ( !str_cmp( arg+1, "traffic"  ) ) bit = CHANNEL_TRAFFIC;
	else if ( !str_cmp( arg+1, "charla"     ) ) bit = CHANNEL_CHAT;
	else if ( !str_cmp( arg+1, "clan"     ) ) bit = CHANNEL_CLAN;
	else if ( !str_cmp( arg+1, "consejo"  ) ) bit = CHANNEL_COUNCIL;
        else if ( !str_cmp( arg+1, "gremio"    ) ) bit = CHANNEL_GUILD;
	else if ( !str_cmp( arg+1, "aventura"  ) ) bit = CHANNEL_QUEST;
	else if ( !str_cmp( arg+1, "tells"    ) ) bit = CHANNEL_TELLS;
	else if ( !str_cmp( arg+1, "immtalk"  ) ) bit = CHANNEL_IMMTALK;
	else if ( !str_cmp( arg+1, "log"      ) ) bit = CHANNEL_LOG;
	else if ( !str_cmp( arg+1, "build"    ) ) bit = CHANNEL_BUILD;
	else if ( !str_cmp( arg+1, "high"     ) ) bit = CHANNEL_HIGH;
	else if ( !str_cmp( arg+1, "rezar"     ) ) bit = CHANNEL_PRAY;
	else if ( !str_cmp( arg+1, "avatar"   ) ) bit = CHANNEL_AVTALK;
	else if ( !str_cmp( arg+1, "monitor"  ) ) bit = CHANNEL_MONITOR;
	else if ( !str_cmp( arg+1, "auth"     ) ) bit = CHANNEL_AUTH;
	else if ( !str_cmp( arg+1, "newbie"   ) ) bit = CHANNEL_NEWBIE;
	else if ( !str_cmp( arg+1, "music"    ) ) bit = CHANNEL_MUSIC;
	else if ( !str_cmp( arg+1, "reflexionar"     ) ) bit = CHANNEL_HIGHGOD;
	else if ( !str_cmp( arg+1, "preguntar"      ) ) bit = CHANNEL_ASK;
	else if ( !str_cmp( arg+1, "gritar"    ) ) bit = CHANNEL_SHOUT;
	else if ( !str_cmp( arg+1, "vocear"     ) ) bit = CHANNEL_YELL;
	else if ( !str_cmp( arg+1, "comm"     ) ) bit = CHANNEL_COMM;
        else if ( !str_cmp (arg+1, "warn"     ) ) bit = CHANNEL_WARN;
	else if ( !str_cmp( arg+1, "orden"    ) ) bit = CHANNEL_ORDER;
        else if ( !str_cmp( arg+1, "wartalk"  ) ) bit = CHANNEL_WARTALK;
	else if ( !str_cmp( arg+1, "susurrar"  ) ) bit = CHANNEL_WHISPER;
	else if ( !str_cmp( arg+1, "racetalk" ) ) bit = CHANNEL_RACETALK;
	else if ( !str_cmp( arg+1, "todos"      ) ) ClearAll = TRUE;
	else
	{
	    send_to_char( "Poner o quitar que canal?\n\r", ch );
	    return;
	}

	if (( fClear ) && ( ClearAll ))
	{
	    REMOVE_BIT (ch->deaf, CHANNEL_RACETALK);
            REMOVE_BIT (ch->deaf, CHANNEL_AUCTION);
            REMOVE_BIT (ch->deaf, CHANNEL_CHAT);
            REMOVE_BIT (ch->deaf, CHANNEL_QUEST);
            REMOVE_BIT (ch->deaf, CHANNEL_WARTALK);
            REMOVE_BIT (ch->deaf, CHANNEL_PRAY);
	    REMOVE_BIT (ch->deaf, CHANNEL_TRAFFIC);
            REMOVE_BIT (ch->deaf, CHANNEL_MUSIC);
            REMOVE_BIT (ch->deaf, CHANNEL_ASK);
            REMOVE_BIT (ch->deaf, CHANNEL_SHOUT);
            REMOVE_BIT (ch->deaf, CHANNEL_YELL);

       /*     if (ch->pcdata->clan)
              REMOVE_BIT (ch->deaf, CHANNEL_CLAN);

	    if (ch->pcdata->council)
	      REMOVE_BIT (ch->deaf, CHANNEL_COUNCIL);

            if (ch->pcdata->guild)
              REMOVE_BIT (ch->deaf, CHANNEL_GUILD);
       */
            if (ch->level >= LEVEL_IMMORTAL)
              REMOVE_BIT (ch->deaf, CHANNEL_AVTALK);

	    /*
	    if (ch->level >= sysdata.log_level )
	      REMOVE_BIT (ch->deaf, CHANNEL_COMM);
	    */

        } else if ((!fClear) && (ClearAll))
        {
	    SET_BIT (ch->deaf, CHANNEL_RACETALK);
            SET_BIT (ch->deaf, CHANNEL_AUCTION);
	    SET_BIT (ch->deaf, CHANNEL_TRAFFIC);
            SET_BIT (ch->deaf, CHANNEL_CHAT);
            SET_BIT (ch->deaf, CHANNEL_QUEST);
            SET_BIT (ch->deaf, CHANNEL_PRAY);
            SET_BIT (ch->deaf, CHANNEL_MUSIC);
            SET_BIT (ch->deaf, CHANNEL_ASK);
            SET_BIT (ch->deaf, CHANNEL_SHOUT);
	    SET_BIT (ch->deaf, CHANNEL_WARTALK);
            SET_BIT (ch->deaf, CHANNEL_YELL);

       /*     if (ch->pcdata->clan)
              SET_BIT (ch->deaf, CHANNEL_CLAN);

	    if (ch->pcdata->council)
	      SET_BIT (ch->deaf, CHANNEL_COUNCIL);

            if ( IS_GUILDED(ch) )
              SET_BIT (ch->deaf, CHANNEL_GUILD);
       */
            if (ch->level >= LEVEL_IMMORTAL)
              SET_BIT (ch->deaf, CHANNEL_AVTALK);

	    /*
	    if (ch->level >= sysdata.log_level)
	      SET_BIT (ch->deaf, CHANNEL_COMM);
	    */

         } else if (fClear)
         {
	    REMOVE_BIT (ch->deaf, bit);
         } else
         {
	    SET_BIT    (ch->deaf, bit);
         }

	  send_to_char( "Ok.\n\r", ch );
    }

    return;
}


/*
 * display WIZLIST file						-Thoric
 */
void do_wizlist( CHAR_DATA *ch, char *argument )
{
    set_pager_color( AT_IMMORT, ch );
    show_file( ch, WIZLIST_FILE );
}

/*
 * Contributed by Grodyn.
 * Display completely overhauled, 2/97 -- Blodkai
 */
void do_config( CHAR_DATA *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];

    if ( IS_NPC(ch) )
        return;

    one_argument( argument, arg );

    set_char_color( AT_GREEN, ch );

    if ( arg[0] == '\0' )
    {
      set_char_color( AT_DGREEN, ch );
      send_to_char( "\n\rConfiguraciones ", ch );
      set_char_color( AT_GREEN, ch );
      send_to_char( "(usa 'config +/-<palabra>' para cambiarlas, mira tambien 'help config')\n\r\n\r", ch );
      set_char_color( AT_DGREEN, ch );
      send_to_char( "De muestra:", ch );
      set_char_color( AT_GREY, ch );
      ch_printf( ch, "%-12s   %-12s   %-12s   %-12s\n\r           %-12s   %-12s   %-12s   %-12s",
        IS_SET( ch->pcdata->flags, PCFLAG_PAGERON ) 	? "[+] PAGER"
                                                    	: "[-] pager",
        IS_SET( ch->pcdata->flags, PCFLAG_GAG )     	? "[+] GAG"
                                                    	: "[-] gag",
        xIS_SET(ch->act, PLR_BRIEF )                	? "[+] BRIEF"
                                                    	: "[-] brief",
        xIS_SET(ch->act, PLR_COMBINE )              	? "[+] COMBINE"
                                                    	: "[-] combine",
        xIS_SET(ch->act, PLR_BLANK )                	? "[+] BLANK"
                                                    	: "[-] blank",
        xIS_SET(ch->act, PLR_PROMPT )               	? "[+] PROMPT"
                                                    	: "[-] prompt",
        xIS_SET(ch->act, PLR_ANSI )                 	? "[+] ANSI"
                                                    	: "[-] ansi",
        xIS_SET(ch->act, PLR_RIP )                  	? "[+] RIP"
                                                    	: "[-] rip" );
      set_char_color( AT_DGREEN, ch );
      send_to_char( "\n\r\n\rAuto:      ", ch );
      set_char_color( AT_GREY, ch );
      ch_printf( ch, "%-12s   %-12s   %-12s   %-12s   %-12s",
        xIS_SET(ch->act, PLR_AUTOSAC  )             	? "[+] AUTOSAC"
                                                    	: "[-] autosac",
        xIS_SET(ch->act, PLR_AUTOGOLD )             	? "[+] AUTOGOLD"
                                                    	: "[-] autogold",
        xIS_SET(ch->act, PLR_AUTOLOOT )             	? "[+] AUTOLOOT"
                                                    	: "[-] autoloot",
/*
 * Esto sirve ( en principio ) para ver el danyo que le causas al enemigo
 * y el que te causa el a ti, pero no sabemos si ira :P
 * SiGo y SaNgUi  VampiroMud 2000 -2001
 */
        xIS_SET(ch->act, PLR_AUTODANYO )              ? "[+] AUTODANYO"
                                                      : "[-] autodanyo",
        xIS_SET(ch->act, PLR_AUTOEXIT )             	? "\n\r           [+] AUTOEXIT"
                                                    	: "\n\r           [-] autoexit" );

      set_char_color( AT_DGREEN, ch );
      send_to_char( "\n\r\n\rSeguridad: ", ch );
      set_char_color( AT_GREY, ch );
      ch_printf( ch, "%-12s   %-12s",
        IS_SET( ch->pcdata->flags, PCFLAG_NORECALL ) 	? "[+] NORECALL"
                                                     	: "[-] norecall",
        IS_SET( ch->pcdata->flags, PCFLAG_NOSUMMON ) 	? "[+] NOSUMMON"
                                                     	: "[-] nosummon" );

      if ( !IS_SET( ch->pcdata->flags, PCFLAG_DEADLY ) )
        ch_printf( ch, "   %-12s   %-12s",
           xIS_SET(ch->act, PLR_SHOVEDRAG )             ? "[+] DRAG"
                                                        : "[-] drag",
           xIS_SET(ch->act, PLR_NICE )               	? "[+] NICE"
                                                     	: "[-] nice" );

      set_char_color( AT_DGREEN, ch );
      send_to_char( "\n\r\n\rMiscelanea:", ch );
      set_char_color( AT_GREY, ch );
      ch_printf( ch, "%-12s   %-12s   %-12s",
	   xIS_SET(ch->act, PLR_TELNET_GA )		? "[+] TELNETGA"
                                                        : "[-] telnetga",
           IS_SET( ch->pcdata->flags, PCFLAG_GROUPWHO ) ? "[+] GROUPWHO"
                                                        : "[-] groupwho",
           IS_SET( ch->pcdata->flags, PCFLAG_NOINTRO )  ? "[+] NOINTRO"
                                                        : "[-] nointro" );

      set_char_color( AT_DGREEN, ch );
      send_to_char( "\n\r\n\rAsignados:  ", ch );
      set_char_color( AT_GREY, ch );
      ch_printf_color( ch, "Longitud de la pagina (%d)    Wimpy (&W%d&w)",
							ch->pcdata->pagerlen,
						        ch->wimpy );

      if ( IS_IMMORTAL( ch ) )
      {
	set_char_color( AT_DGREEN, ch );
        send_to_char( "\n\r\n\rImmortal:  ", ch );
        set_char_color( AT_GREY, ch );
        ch_printf( ch, "Roomvnum [%s]    Automap [%s]",
	  xIS_SET(ch->act, PLR_ROOMVNUM ) 		? "+"
							: " ",
          xIS_SET(ch->act, PLR_AUTOMAP  ) 		? "+"
							: " " );
      }

      set_char_color( AT_DGREEN, ch );
      send_to_char( "\n\r\n\rSentencias que te han sido impuestas (si hay):", ch );
      set_char_color( AT_YELLOW, ch );
      ch_printf( ch, "\n\r%s%s%s%s%s%s",
          xIS_SET(ch->act, PLR_SILENCE )  ?
            " Has sido silenciado por los dioses  ahora vas y lo kaskas xD.\n\r" : "",
          xIS_SET(ch->act, PLR_NO_EMOTE ) ?
            " Los dioses te han quitado los emotes.\n\r"                      : "",
          xIS_SET(ch->act, PLR_NO_TELL )  ?
            " Se te ha denegado el uso de enviar 'tels'.\n\r"        : "",
          xIS_SET(ch->act, PLR_LITTERBUG )?
            " Por ensuciar la via publica, no puedes dejar nada.\n\r"       : "",
          xIS_SET(ch->act, PLR_THIEF )    ?
            " Ahora eres un ladron, seras perseguido por las autoridades.\n\r"  : "",
          xIS_SET(ch->act, PLR_KILLER )   ?
            " Por el crimen de asesinato eres sentenciado a muerte...\n\r"   : "" );
    }
    else
    {
	bool fSet;
	int bit = 0;

	     if ( arg[0] == '+' ) fSet = TRUE;
	else if ( arg[0] == '-' ) fSet = FALSE;
	else
	{
	    send_to_char( "Configurar -opcion o +opcion?\n\r", ch );
	    return;
	}

	     if ( !str_prefix( arg+1, "autoexit" ) ) bit = PLR_AUTOEXIT;
	else if ( !str_prefix( arg+1, "autoloot" ) ) bit = PLR_AUTOLOOT;
	else if ( !str_prefix( arg+1, "autosac"  ) ) bit = PLR_AUTOSAC;
	else if ( !str_prefix( arg+1, "autogold" ) ) bit = PLR_AUTOGOLD;
   else if ( !str_prefix( arg+1, "autodanyo" ) ) bit = PLR_AUTODANYO;  /* SiGo y SaNgUi */
	else if ( !str_prefix( arg+1, "blank"    ) ) bit = PLR_BLANK;
	else if ( !str_prefix( arg+1, "brief"    ) ) bit = PLR_BRIEF;
	else if ( !str_prefix( arg+1, "combine"  ) ) bit = PLR_COMBINE;
	else if ( !str_prefix( arg+1, "prompt"   ) ) bit = PLR_PROMPT;
	else if ( !str_prefix( arg+1, "telnetga" ) ) bit = PLR_TELNET_GA;
	else if ( !str_prefix( arg+1, "ansi"     ) ) bit = PLR_ANSI;
	else if ( !str_prefix( arg+1, "rip"      ) ) bit = PLR_RIP;
/*	else if ( !str_prefix( arg+1, "flee"     ) ) bit = PLR_FLEE; */
	else if ( !str_prefix( arg+1, "nice"     ) ) bit = PLR_NICE;
	else if ( !str_prefix( arg+1, "drag"     ) ) bit = PLR_SHOVEDRAG;
	else if ( IS_IMMORTAL( ch )
	     &&   !str_prefix( arg+1, "vnum"     ) ) bit = PLR_ROOMVNUM;
	else if ( IS_IMMORTAL( ch )
	     &&   !str_prefix( arg+1, "map"      ) ) bit = PLR_AUTOMAP;     /* maps */

	if (bit)
        {
  	  if ( (bit == PLR_FLEE || bit == PLR_NICE || bit == PLR_SHOVEDRAG)
	  &&  IS_SET( ch->pcdata->flags, PCFLAG_DEADLY ) )
          {
	    send_to_char( "Los jugadores PK no pueden configurar esa opcion.\n\r", ch );
	    return;
          }

	  if ( fSet )
	    xSET_BIT   (ch->act, bit);
	  else
	    xREMOVE_BIT(ch->act, bit);
	  send_to_char( "Ok.\n\r", ch );
          return;
        }
        else
        {
	       if ( !str_prefix( arg+1, "norecall" ) ) bit = PCFLAG_NORECALL;
	  else if ( !str_prefix( arg+1, "nointro"  ) ) bit = PCFLAG_NOINTRO;
	  else if ( !str_prefix( arg+1, "nosummon" ) ) bit = PCFLAG_NOSUMMON;
          else if ( !str_prefix( arg+1, "gag"      ) ) bit = PCFLAG_GAG;
          else if ( !str_prefix( arg+1, "pager"    ) ) bit = PCFLAG_PAGERON;
          else if ( !str_prefix( arg+1, "groupwho" ) ) bit = PCFLAG_GROUPWHO;
	  else if ( !str_prefix( arg+1, "@hgflag_" ) ) bit = PCFLAG_HIGHGAG;
          else
	  {
	    send_to_char( "Configurar que opcion?\n\r", ch );
	    return;
    	  }

          if ( fSet )
	    SET_BIT    (ch->pcdata->flags, bit);
	  else
	    REMOVE_BIT (ch->pcdata->flags, bit);

	  send_to_char( "Ok.\n\r", ch );
          return;
        }
    }

    return;
}


void do_credits( CHAR_DATA *ch, char *argument )
{
  do_help( ch, "credits" );
}


extern int top_area;

/*
 * New do_areas
 , written by Fireblade, last modified - 4/27/97
 *
 *   Syntax: area            ->      lists areas in alphanumeric order
 *           area <a>        ->      lists areas with soft max less than
 *                                                    parameter a
 *           area <a> <b>    ->      lists areas with soft max bewteen
 *                                                    numbers a and b
 *           area old        ->      list areas in order loaded
 *
 */

int fam1, fam2, fam3, fam4, fam5, fam6;

void do_areas( CHAR_DATA *ch, char *argument )
{
    CLAN_DATA *clan;
    CON_DATA *conquista;
    int cnt;

    char *header_string1 = "\n\r&w Autor     &g| &wArea                                 &g| &wNiveles &g| &wPropietario\n\r";
    char *header_string2 = "&g-------------------------------&w"
                                    "&g--------------------------&w"
                                    "&g-----------------------&w\n\r";
    char *print_string = "&w%-10s &g| &w%-36s &g| &w%3d&g-&w%-3d&g | &w%s\n\r";
    char *print_string2 = "&w%-10s &g| &c%-36s &g| &w%3d&g-&w%-3d&g | &w%s\n\r";

    AREA_DATA *pArea;
    int lower_bound = 0;
    int upper_bound = MAX_LEVEL + 1;
    /* make sure is to init. > max area level */
    char arg[MAX_STRING_LENGTH];

    argument = one_argument(argument,arg);

    if(arg[0] != '\0')
    {
      if(!is_number(arg))
      {
        if(!strcmp(arg,"old"))
        ;
        else
        {
          send_to_char("&BArea solo puede ser seguido por &Rnumeros&B, o por '&Wold&B'.\n\r", ch);
          return;
        }
      }

      upper_bound = atoi(arg);
      lower_bound = upper_bound;

      argument = one_argument(argument,arg);

      if(arg[0] != '\0')
      {
        if(!is_number(arg))
        {
          send_to_char("Area solo puede ser seguido por numeros.\n\r", ch);
          return;
        }

        upper_bound = atoi(arg);

        argument = one_argument(argument,arg);
        if(arg[0] != '\0')
        {
          send_to_char("Solo estan permitidos dos numeros de nivel.\n\r",ch);
          return;
        }
      }
    }


    if(lower_bound > upper_bound)
    {
      int swap = lower_bound;
      lower_bound = upper_bound;
      upper_bound = swap;
    }

    set_pager_color( AT_PLAIN, ch );
    send_to_pager(header_string1, ch);
    send_to_pager(header_string2, ch);

    for (pArea = first_area_name; pArea; pArea = pArea->next_sort_name)
    {
      conquista = get_conquista( pArea->name );

      if ((pArea->hi_soft_range >= lower_bound
      &&  pArea->low_soft_range <= upper_bound))
      {
       if(!IS_SET(pArea->flags, AFLAG_AUTOAREA))
        pager_printf(ch, print_string,
          pArea->author, pArea->name,
          pArea->low_soft_range,
          pArea->hi_soft_range,
          conquista->propietario );
       else
       pager_printf(ch, print_string2,
          pArea->author, pArea->name,
          pArea->low_soft_range,
          pArea->hi_soft_range,
          conquista->propietario );
      }
    }

    send_to_pager(header_string2, ch);

    for ( pArea = first_area; pArea; pArea = pArea->next )
    {
        conquista = get_conquista( pArea->name );

        if( !str_cmp(conquista->propietario, "ARaSHeMiaH"))
        fam1++;
        if( !str_cmp(conquista->propietario, "WyRMCLaW"))
        fam2++;
        if( !str_cmp(conquista->propietario, "BeYTHoR"))
        fam3++;
        if( !str_cmp(conquista->propietario, "DRaKeNDoR"))
        fam4++;
        if(( !str_cmp(conquista->propietario, "Territorio Virgen")
         && pArea->conquistable != 1))
        fam5++;
        if(( !str_cmp(conquista->propietario, "Inconquistable")
         && pArea->conquistable != 0))
        fam6++;
    }

    ch_printf( ch, "&gFamilia ARaSHeMiaH :&w%-3.3d &gAreas    &gFamilia WyRMCLaW  :&w%-3.3d &gAreas\n\r",fam1,fam2 );
    ch_printf( ch, "&gFamilia BeYTHoR    :&w%-3.3d &gAreas    &gFamilia DRaKeNDoR :&w%-3.3d &gAreas\n\r",fam3,fam4 );
    ch_printf( ch, "&gAreas Virgenes     :&w%-3.3d &gAreas    &gInconquistables   :&w%-3.3d &gAreas\n\r", fam5, fam6 );

    fam1 = 0;
    fam2 = 0;
    fam3 = 0;
    fam4 = 0;
    fam5 = 0;
    fam6 = 0;


    return;
}

void do_afk( CHAR_DATA *ch, char *argument )
{
     if ( IS_NPC(ch) )
     return;

     if xIS_SET(ch->act, PLR_AFK)
     {
    	xREMOVE_BIT(ch->act, PLR_AFK);
	send_to_char( "Dejas de estar EMPANAO.\n\r", ch );
/*	act(AT_GREY,"$n vuelve a relacionarse con la gente.", ch, NULL, NULL, TO_ROOM);*/
	act(AT_GREY,"$n se DESEMPANA.", ch, NULL, NULL, TO_CANSEE);
     }
     else
     {
	xSET_BIT(ch->act, PLR_AFK);
	send_to_char( "Te pones EMPANAO.\n\r", ch );
/*	act(AT_GREY,"$n ahora no tiene amigos.", ch, NULL, NULL, TO_ROOM);*/
	act(AT_GREY,"$n se ha EMPANAO.", ch, NULL, NULL, TO_CANSEE);
	return;
     }

}

void do_slist( CHAR_DATA *ch, char *argument )
{
   int sn, i, lFound;
   char skn[MAX_INPUT_LENGTH];
   char buf[MAX_INPUT_LENGTH];
   char arg1[MAX_INPUT_LENGTH];
   char arg2[MAX_INPUT_LENGTH];
   int lowlev, hilev;
   sh_int lasttype = SKILL_SPELL;

   if ( IS_NPC(ch) )
     return;

   argument = one_argument( argument, arg1 );
   argument = one_argument( argument, arg2 );

   lowlev=1;
   hilev=241;

   if (arg1[0]!='\0')
      lowlev=atoi(arg1);

   if ((lowlev<1) || (lowlev>LEVEL_IMMORTAL))
      lowlev=1;

   if (arg2[0]!='\0')
      hilev=atoi(arg2);

   if ((hilev<0) || (hilev>=LEVEL_IMMORTAL))
      hilev=LEVEL_HERO;

   if(lowlev>hilev)
      lowlev=hilev;

   set_pager_color( AT_MAGIC, ch );
   send_to_pager("LISTA DE HECHIZOS Y HABILIDADES POR NIVEL\n\r",ch);
   send_to_pager("-----------------------------------------\n\r\n\r",ch);

   for (i=lowlev; i <= hilev; i++)
   {
	lFound= 0;
	sprintf(skn,"Hechizos");
	for ( sn = 0; sn < top_sn; sn++ )
	{
	    if ( !skill_table[sn]->name )
		break;

	    if ( skill_table[sn]->type != lasttype )
	    {
		lasttype = skill_table[sn]->type;
		strcpy( skn, skill_tname[lasttype] );
	    }

	    if ( ch->pcdata->learned[sn] <= 0
	    &&   SPELL_FLAG(skill_table[sn], SF_SECRETSKILL) )
		continue;

	    if(i==skill_table[sn]->skill_level[ch->class]  )
	    {
		if( !lFound )
		{
		    lFound=1;
		    pager_printf( ch, "&w&w&wNivel %d&b\n\r", i );
		}
                switch (skill_table[sn]->minimum_position)
                {
                    case POS_DEAD:
                            sprintf(buf, "ninguno");
                            break;
                    case POS_MORTAL:
                            sprintf(buf, "muriendo");
                            break;
                    case POS_INCAP:
                            sprintf(buf, "incapacitado");
                            break;
                    case POS_STUNNED:
                            sprintf(buf, "aturdido");
                            break;
                    case POS_SLEEPING:
                            sprintf(buf, "durmiendo");
                            break;
                    case POS_RESTING:
                            sprintf(buf, "descansando");
                            break;
                    case POS_STANDING:
                            sprintf(buf, "de pie");
                            break;
                    case POS_FIGHTING:
                            sprintf(buf, "luchando");
                            break;
                    case POS_EVASIVE:
                            sprintf(buf, "luchando (E)");   /* Fighting style support -haus */
                            break;
                    case POS_DEFENSIVE:
                            sprintf(buf, "luchando (D)");
                            break;
                    case POS_AGGRESSIVE:
                            sprintf(buf, "luchando (A)");
                            break;
                    case POS_BERSERK:
                            sprintf(buf, "luchando (B)");
                            break;
                    case POS_MOUNTED:
                            sprintf(buf, "montado");
                            break;
                    case POS_SITTING:
                            sprintf(buf, "sentado");
                            break;
		    case POS_PREDECAP:
		    	    sprintf(buf, "predecapitado");
			    break;
                }

		pager_printf(ch, "%7s:&w %20.20s&b \t Actual:&w %-3d&b Max:&w %-3d&b  MinPos:&w %s &b\n\r",
                        skn, skill_table[sn]->name,
                        ch->pcdata->learned[sn],
                        skill_table[sn]->skill_adept[ch->class],
			buf );
	    }
	}
   }
   return;
}

void do_whois( CHAR_DATA *ch, char *argument)
{
  CHAR_DATA *victim;
  char buf[MAX_STRING_LENGTH];
  char buf2[MAX_STRING_LENGTH];

  buf[0] = '\0';

  if(IS_NPC(ch))
    return;

  if(argument[0] == '\0')
  {
    send_to_pager("Debes poner el nombre del jugador.\n\r", ch);
    return;
  }

  strcat(buf, "0.");
  strcat(buf, argument);
  if( ( ( victim = get_char_world(ch, buf) ) == NULL ))
  {
    send_to_pager("Jugador no encontrado.\n\r", ch);
    return;
  }

  if(IS_NPC(victim))
  {
    send_to_pager("Eso no es un jugador!\n\r", ch);
    return;
  }

  set_pager_color( AT_GREY, ch );
  do_last (victim, victim->name);
  pager_printf(ch, " %s%s .\n\r %s es un %s nivel %d generacion %d %s %s, Con %d anyos.\n\r",
	victim->name,
	victim->pcdata->title,
        victim->sex == SEX_MALE ? "El" :
        victim->sex == SEX_FEMALE ? "Ella" : "Eso",
	victim->sex == SEX_MALE ? "hombre" :
	victim->sex == SEX_FEMALE ? "mujer" : "neutral",
	victim->level,
   victim->generacion,
	capitalize(race_table[victim->race]->race_name),
	class_table[victim->class]->who_name,
	get_age(victim) );

  pager_printf(ch, " %s es %sPK",
	victim->sex == SEX_MALE ? "El" :
	victim->sex == SEX_FEMALE ? "Ella" : "Eso",
	IS_SET(victim->pcdata->flags, PCFLAG_DEADLY) ? "" : "no-");

  if ( victim->pcdata->clan )
  {
	if ( victim->pcdata->clan->clan_type == CLAN_ORDER )
	   send_to_pager( ", y pertenece a la Orden ", ch );
	else
	if ( victim->pcdata->clan->clan_type == CLAN_GUILD )
	   send_to_pager( ", y pertenece al Gremio", ch );
	else
	   send_to_pager( ", y pertenece al Clan ", ch );
	send_to_pager( victim->pcdata->clan->name, ch );
  }
  if ( IS_VAMPIRE(victim) )
  {
  send_to_pager( " \n\r Su SiRe es ", ch );
  send_to_pager( victim->sire_ch, ch );
  }
  send_to_pager( ".\n\r", ch );

  if(victim->pcdata->council)
    pager_printf(ch, " %s esta sentado en:  %s\n\r",
        victim->sex == SEX_MALE ? "El" :
        victim->sex == SEX_FEMALE ? "Ella" : "Eso",
	victim->pcdata->council->name );

  if(victim->pcdata->deity)
    pager_printf(ch, " %s adora a la deidad %s.\n\r",
        victim->sex == SEX_MALE ? "El" :
        victim->sex == SEX_FEMALE ? "Ella" : "Eso",
	victim->pcdata->deity->name);

  if(victim->pcdata->homepage && victim->pcdata->homepage[0] != '\0')
    pager_printf(ch, " %s no tiene pagina web en %s\n\r",
        victim->sex == SEX_MALE ? "El" :
        victim->sex == SEX_FEMALE ? "Ella" : "Eso",
	show_tilde( victim->pcdata->homepage ) );

  if(victim->pcdata->bio && victim->pcdata->bio[0] != '\0')
    pager_printf(ch, " Bio personal de %s:\n\r%s",
	victim->name,
	victim->pcdata->bio);
  else
    pager_printf(ch, " %s todavia no ha creado una bio.\n\r",
	victim->name );

  if(IS_IMMORTAL(ch))
  {
    send_to_pager("----------------------------\n\r", ch);
    send_to_pager("Informacion para Inmortales:\n\r", ch);

    if ( victim->pcdata->authed_by && victim->pcdata->authed_by[0] != '\0' )
	pager_printf(ch, "%s fue autorizado por %s.\n\r",
		victim->name, victim->pcdata->authed_by );

    pager_printf(ch, "%s ha matado %d mobs, y ha sido asesinado por un mob %d veces.\n\r",
		victim->name, victim->pcdata->mkills, victim->pcdata->mdeaths );
    if ( victim->pcdata->pkills || victim->pcdata->pdeaths )
	pager_printf(ch, "%s ha matado %d jugadores, y ha sido asesinado por un jugador %d veces.\n\r",
		victim->name, victim->pcdata->pkills, victim->pcdata->pdeaths );
    if ( victim->pcdata->illegal_pk )
	pager_printf(ch, "%s ha cometido %d PKs ilegales.\n\r",
		victim->name, victim->pcdata->illegal_pk );

    pager_printf(ch, "%s %sesta conectado en estos momentos.\n\r",
	victim->name,
	(victim->pcdata->release_date == 0) ? "no " : "");

    if (victim->pcdata->nuisance )
    {
      pager_printf_color( ch, "&RMolestia   &cEtapa: (&R%d&c/%d)  Poder:  &w%d  &cTime:  &w%s.\n\r", victim->pcdata->nuisance->flags,
                  MAX_NUISANCE_STAGE, victim->pcdata->nuisance->power,
		              ctime(&victim->pcdata->nuisance->time));
    }
    if(victim->pcdata->release_date != 0)
      pager_printf(ch, "%s fue mandado al infierno por %s, y permanecio %24.24s.\n\r",
	victim->sex == SEX_MALE ? "El" :
	victim->sex == SEX_FEMALE ? "Ella" : "Eso",
        victim->pcdata->helled_by,
	ctime(&victim->pcdata->release_date));

    if(get_trust(victim) < get_trust(ch))
    {
      sprintf(buf2, "lista %s", buf);
      do_comment(ch, buf2);
    }

    if(xIS_SET(victim->act, PLR_SILENCE) || xIS_SET(victim->act, PLR_NO_EMOTE)
    || xIS_SET(victim->act, PLR_NO_TELL) || xIS_SET(victim->act, PLR_THIEF)
    || xIS_SET(victim->act, PLR_KILLER) )
    {
      sprintf(buf2, "Este player tiene los flags siguientes:");
      if(xIS_SET(victim->act, PLR_SILENCE))
        strcat(buf2, " silenciado");
      if(xIS_SET(victim->act, PLR_NO_EMOTE))
        strcat(buf2, " noemote");
      if(xIS_SET(victim->act, PLR_NO_TELL) )
        strcat(buf2, " notell");
      if(xIS_SET(victim->act, PLR_THIEF) )
        strcat(buf2, " ladron");
      if(xIS_SET(victim->act, PLR_KILLER) )
        strcat(buf2, " asesino");
      strcat(buf2, ".\n\r");
      send_to_pager(buf2, ch);
    }
  if ( victim->desc && victim->desc->host[0]!='\0' )   /* added by Gorog */
     {
     sprintf (buf2, "La IP de %s: %s ", victim->name, victim->desc->host);
     if (get_trust(ch) >= LEVEL_GOD)
        strcat (buf2, victim->desc->user);
     strcat (buf2, "\n\r");
     send_to_pager(buf2, ch);
     }
  }
}

void do_pager( CHAR_DATA *ch, char *argument )
{
  char arg[MAX_INPUT_LENGTH];

  if ( IS_NPC(ch) )
    return;
  set_char_color( AT_NOTE, ch );
  argument = one_argument(argument, arg);
  if ( !*arg )
  {
    if ( IS_SET(ch->pcdata->flags, PCFLAG_PAGERON) )
    {
        send_to_char( "Longitud de pagina no disponible.\n\r", ch );
        do_config(ch, "-pager");
    } else {
        ch_printf( ch, "Longitud de pagina disponible a %d lineas.\n\r", ch->pcdata->pagerlen );
        do_config(ch, "+pager");
    }
    return;
  }
  if ( !is_number(arg) )
  {
    send_to_char( "A cuantas lineas quieres la pausa de pagina?\n\r", ch );
    return;
  }
  ch->pcdata->pagerlen = atoi(arg);
  if ( ch->pcdata->pagerlen < 5 )
    ch->pcdata->pagerlen = 5;
  ch_printf( ch, "Pausa de pagina fijado a %d lineas.\n\r", ch->pcdata->pagerlen );
  return;
}

/*
 * The ignore command allows players to ignore up to MAX_IGN
 * other players. Players may ignore other characters whether
 * they are online or not. This is to prevent people from
 * spamming someone and then logging off quickly to evade
 * being ignored.
 * Syntax:
 *	ignore		-	lists players currently ignored
 *	ignore none	-	sets it so no players are ignored
 *	ignore <player>	-	start ignoring player if not already
 *				ignored otherwise stop ignoring player
 *	ignore reply	-	start ignoring last player to send a
 *				tell to ch, to deal with invis spammers
 * Last Modified: June 26, 1997
 * - Fireblade
 */
void do_ignore(CHAR_DATA *ch, char *argument)
{
	char arg[MAX_INPUT_LENGTH];
	IGNORE_DATA *temp, *next;
	char fname[1024];
	struct stat fst;
	CHAR_DATA *victim;

	if(IS_NPC(ch))
		return;

	argument = one_argument(argument, arg);

	sprintf(fname, "%s%c/%s", PLAYER_DIR,
		tolower(arg[0]), capitalize(arg));

	victim = NULL;

	/* If no arguements, then list players currently ignored */
	if(arg[0] == '\0')
	{
		set_char_color(AT_DIVIDER, ch);
		ch_printf(ch, "\n\r----------------------------------------\n\r");
		set_char_color(AT_DGREEN, ch);
		ch_printf(ch, "Ahora estas ignorando a:\n\r");
		set_char_color(AT_DIVIDER, ch);
		ch_printf(ch, "----------------------------------------\n\r");
		set_char_color(AT_IGNORE, ch);

		if(!ch->pcdata->first_ignored)
		{
			ch_printf(ch, "\t    nadie\n\r");
			return;
		}

		for(temp = ch->pcdata->first_ignored; temp;
				temp = temp->next)
		{
			ch_printf(ch,"\t  - %s\n\r",temp->name);
		}

		return;
	}
	/* Clear players ignored if given arg "none" */
	else if(!strcmp(arg, "nadie"))
	{
		for(temp = ch->pcdata->first_ignored; temp; temp = next)
		{
			next = temp->next;
			UNLINK(temp, ch->pcdata->first_ignored,
					ch->pcdata->last_ignored,
					next, prev);
			STRFREE(temp->name);
			DISPOSE(temp);
		}

		set_char_color(AT_IGNORE, ch);
		ch_printf(ch, "Ahora no ignoras a nadie.\n\r");

		return;
	}
	/* Prevent someone from ignoring themself... */
	else if(!strcmp(arg, "yo") || nifty_is_name(arg, ch->name))
	{
		set_char_color(AT_IGNORE, ch);
		ch_printf(ch, "Has escrito algo?\n\r");
		return;
	}
	else
	{
		int i;

		/* get the name of the char who last sent tell to ch */
		if(!strcmp(arg, "reply"))
		{
			if(!ch->reply)
			{
				set_char_color(AT_IGNORE, ch);
				ch_printf(ch, "No esta aqui.\n\r");
				return;
			}
			else
			{
				strcpy(arg, ch->reply->name);
			}
		}

		/* Loop through the linked list of ignored players */
		/* 	keep track of how many are being ignored     */
		for(temp = ch->pcdata->first_ignored, i = 0; temp;
				temp = temp->next, i++)
		{
			/* If the argument matches a name in list remove it */
			if(!strcmp(temp->name, capitalize(arg)))
			{
				UNLINK(temp, ch->pcdata->first_ignored,
					ch->pcdata->last_ignored,
					next, prev);
				set_char_color(AT_IGNORE, ch);
				ch_printf(ch,"Ya no ignorar a %s.\n\r",
					temp->name);
				STRFREE(temp->name);
				DISPOSE(temp);
				return;
			}
		}

		/* if there wasn't a match check to see if the name   */
		/* is valid. This if-statement may seem like overkill */
		/* but it is intended to prevent people from doing the*/
		/* spam and log thing while still allowing ya to      */
		/* ignore new chars without pfiles yet...             */
		if( stat(fname, &fst) == -1 &&
			(!(victim = get_char_world(ch, arg)) ||
			IS_NPC(victim) ||
			strcmp(capitalize(arg),victim->name) != 0))
		{
			set_char_color(AT_IGNORE, ch);
			ch_printf(ch,"No existen jugadores con ese"
				" nombre.\n\r");
			return;
		}

		if(victim)
		{
			strcpy(capitalize(arg),victim->name);
		}

		/* If its valid and the list size limit has not been */
		/* reached create a node and at it to the list	     */
		if(i < MAX_IGN)
		{
			IGNORE_DATA *new;
			CREATE(new, IGNORE_DATA, 1);
			new->name = STRALLOC(capitalize(arg));
			new->next = NULL;
			new->prev = NULL;
			LINK(new, ch->pcdata->first_ignored,
				ch->pcdata->last_ignored, next, prev);
			set_char_color(AT_IGNORE, ch);
			ch_printf(ch,"Ahora ignorar a %s.\n\r", new->name);
			return;
		}
		else
		{
			set_char_color(AT_IGNORE, ch);
			ch_printf(ch,"Solo puedes ignorar a %d jugadores.\n\r",
				MAX_IGN);
			return;
		}
	}
}

/*
 * This function simply checks to see if ch is ignoring ign_ch.
 * Last Modified: October 10, 1997
 * - Fireblade
 */
bool is_ignoring(CHAR_DATA *ch, CHAR_DATA *ign_ch)
{
	IGNORE_DATA *temp;

	if(IS_NPC(ch) || IS_NPC(ign_ch))
		return FALSE;

	for(temp = ch->pcdata->first_ignored; temp; temp = temp->next)
	{
		if(nifty_is_name(temp->name, ign_ch->name))
			return TRUE;
	}

	return FALSE;
}

/* Version info -- Scryn */

void do_version(CHAR_DATA* ch, char* argument)
{
	if(IS_NPC(ch))
	  return;

	set_char_color(AT_YELLOW, ch);
   ch_printf(ch, "VAMPIRO %s.%s\n\r", VAMPIRO_VERSION_MAJOR, VAMPIRO_VERSION_MINOR);
   ch_printf(ch, "Programado por Colicotron la Bebida de los Locos\n\r" );

	if(IS_IMMORTAL(ch))
	  ch_printf(ch, "Compilado en %s a %s.\n\r", __DATE__, __TIME__);

	return;
}

void do_infoarea( CHAR_DATA *ch, char *argument )
{
        AREA_DATA *area;
	CON_DATA *conquista;

	conquista = get_conquista( ch->in_room->area->name );

        if( !IS_CLANNED( ch ) && !IS_IMMORTAL( ch ))
        {
                send_to_char( "No estas en ninguna familia, no puedes usar el infoarea.\n\r", ch );
                return;
        }

        if( ch->level < 10 )
        {
                send_to_char( "Pero si aun no te interesa!, espera a nivel 10...\n\r", ch );
                return;
        }

        ch_printf( ch, "&gPuntos en &w%s&g.\n\r", ch->in_room->area->name );
        ch_printf( ch, "&g-----------------------------------------------------------------\n\r" );
        ch_printf( ch, "&gFamilia ARaSHeMiaH ----------------> &c(&w%d&c)&g puntos.\n\r", conquista->puntos[0] );
	ch_printf( ch, "&gFamilia WyRMCLaW   ----------------> &c(&w%d&c)&g puntos.\n\r", conquista->puntos[1] );
        ch_printf( ch, "&gFamilia BeYTHoR    ----------------> &c(&w%d&c)&g puntos.\n\r", conquista->puntos [2] );
        ch_printf( ch, "&gFamilia DRaKeNDoR  ----------------> &c(&w%d&c)&g puntos.\n\r\n\r", conquista->puntos[3] );
 /*     ch_printf( ch, "&gFamilia            ----------------> &c(&w%d&c)&g puntos.\n\r", conquista->puntos[4] );
        ch_printf( ch, "&gFamilia            ----------------> &c(&w%d&c)&g puntos.\n\r", conquista->puntos[5] );
*/ /* Total si no hay familias comento esto hasta que esten hechas. Kayser 2004 */
return;
}



